import os
from sys import exit
from abaqus import *
from odbAccess import *
from abaqusConstants import *
import visualization


def ContactForce(stepNumber, stepName, connectionNum):
    odbPath = currentPath + '\\outputSR\\i%s_Sub_CON%s-Job.odb' % (stepNumber, connectionNum)
    o1 = session.openOdb(odbPath)
    session.viewports['Viewport: 1'].setValues(displayedObject=o1)
    odb = session.odbs[odbPath]
    session.XYDataFromHistory(name='XYData-1', odb=odb,
                              outputVariableName='CFT1: CFT1     ASSEMBLY_CP-2-SCREW-1/ASSEMBLY_CP-2-PLATE-1-1',
                              steps=(stepName,), )
    session.XYDataFromHistory(name='XYData-2', odb=odb,
                              outputVariableName='CFT2: CFT2     ASSEMBLY_SCREW-THREAD-SURF_CNS_/ASSEMBLY_PLATE-INNER-SURF',
                              steps=(stepName,), )
    session.XYDataFromHistory(name='XYData-3', odb=odb,
                              outputVariableName='CFT3: CFT3     ASSEMBLY_CP-2-SCREW-1/ASSEMBLY_CP-2-PLATE-1-1',
                              steps=(stepName,), )
    session.XYDataFromHistory(name='XYData-4', odb=odb,
                              outputVariableName='CFTM: CFTM     ASSEMBLY_SCREW-THREAD-SURF_CNS_/ASSEMBLY_PLATE-INNER-SURF',
                              steps=(stepName,), )
    x0 = session.xyDataObjects['XYData-1'][:]
    x1 = session.xyDataObjects['XYData-2'][:]
    x2 = session.xyDataObjects['XYData-3'][:]
    x3 = session.xyDataObjects['XYData-4'][:]
    CF1_endStep = x0[-1][1]
    CF2_endStep = x1[-1][1]
    CF3_endStep = x2[-1][1]
    CF1_preStep = x0[-2][1]
    CF2_preStep = x1[-2][1]
    CF3_preStep = x2[-2][1]
    del session.xyDataObjects['XYData-1']
    del session.xyDataObjects['XYData-2']
    del session.xyDataObjects['XYData-3']
    del session.xyDataObjects['XYData-4']
    session.odbs[odbPath].close()
    return CF1_endStep, CF2_endStep, CF3_endStep, CF1_preStep, CF2_preStep, CF3_preStep, x0, x1, x2, x3


def Displacement(stepNumber, connectionNum):
    odbPath = currentPath + '\\outputSR\\i%s_Sub_CON%s-Job.odb' % (stepNumber, connectionNum)
    o1 = session.openOdb(name=odbPath)
    session.viewports['Viewport: 1'].setValues(displayedObject=o1)
    odb = session.odbs[odbPath]
    ## Displacement in the 1-direction ##
    session.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=(('U', NODAL, ((COMPONENT, 'U1'),)),),
                                nodeSets=('WIRE-2-SET-1',))
    x1_0 = session.xyDataObjects['U:U1 PI: PLATE-1-1 N: 21']
    x1_1 = session.xyDataObjects['U:U1 PI: PLATE-1-1 N: 27']
    x1_2 = session.xyDataObjects['U:U1 PI: PLATE-2-1 N: 19']
    x1_3 = session.xyDataObjects['U:U1 PI: PLATE-2-1 N: 24']
    x1_endStep_average = ((x1_3[-1][1] - x1_1[-1][1]) + (x1_2[-1][1] - x1_0[-1][1]))/2
    x1_previousStep_average = ((x1_3[-2][1] - x1_1[-2][1]) + (x1_2[-2][1] - x1_0[-2][1])) / 2
    x1 = -(x1_endStep_average - x1_previousStep_average)
    ## Displacement in the 2-direction ##
    session.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=(('U', NODAL, ((COMPONENT, 'U2'),)),),
                                nodeSets=('WIRE-1-SET-1',))
    x2_0 = session.xyDataObjects['U:U2 PI: SCREW-1 N: 2']
    x2_1 = session.xyDataObjects['U:U2 PI: SCREW-1 N: 3']
    x2_2 = session.xyDataObjects['U:U2 PI: SCREW-1 N: 7']
    x2_3 = session.xyDataObjects['U:U2 PI: SCREW-1 N: 9']
    x2_4 = session.xyDataObjects['U:U2 PI: SCREW-1 N: 13']
    x2_5 = session.xyDataObjects['U:U2 PI: SCREW-1 N: 15']
    x2_6 = session.xyDataObjects['U:U2 PI: SCREW-1 N: 17']
    x2_7 = session.xyDataObjects['U:U2 PI: SCREW-1 N: 19']
    x2_endStep_average = ((x2_4[-1][1] - x2_0[-1][1]) + (x2_5[-1][1] - x2_1[-1][1]) +
          (x2_6[-1][1] - x2_2[-1][1]) + (x2_7[-1][1] - x2_3[-1][1])) / 4
    x2_previousStep_average = ((x2_4[-2][1] - x2_0[-2][1]) + (x2_5[-2][1] - x2_1[-2][1]) +
          (x2_6[-2][1] - x2_2[-2][1]) + (x2_7[-2][1] - x2_3[-2][1])) / 4
    x2 = -(x2_endStep_average - x2_previousStep_average)
    ## Displacement in the 3-direction ##
    session.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=(('U', NODAL, ((COMPONENT, 'U3'),)),),
                                nodeSets=('WIRE-3-SET-1',))
    x3_0 = session.xyDataObjects['U:U3 PI: PLATE-1-1 N: 18']
    x3_1 = session.xyDataObjects['U:U3 PI: PLATE-1-1 N: 35']
    x3_2 = session.xyDataObjects['U:U3 PI: PLATE-2-1 N: 12']
    x3_3 = session.xyDataObjects['U:U3 PI: PLATE-2-1 N: 34']
    x3_endStep_average = ((x3_3[-1][1] - x3_1[-1][1]) + (x3_2[-1][1] - x3_0[-1][1]))/2
    x3_previousStep_average = ((x3_3[-2][1] - x3_1[-2][1]) + (x3_2[-2][1] - x3_0[-2][1])) / 2
    x3 = -(x3_endStep_average - x3_previousStep_average)

    del session.xyDataObjects['U:U1 PI: PLATE-1-1 N: 21']
    del session.xyDataObjects['U:U1 PI: PLATE-1-1 N: 27']
    del session.xyDataObjects['U:U1 PI: PLATE-2-1 N: 19']
    del session.xyDataObjects['U:U1 PI: PLATE-2-1 N: 24']
    del session.xyDataObjects['U:U2 PI: SCREW-1 N: 2']
    del session.xyDataObjects['U:U2 PI: SCREW-1 N: 3']
    del session.xyDataObjects['U:U2 PI: SCREW-1 N: 7']
    del session.xyDataObjects['U:U2 PI: SCREW-1 N: 9']
    del session.xyDataObjects['U:U2 PI: SCREW-1 N: 13']
    del session.xyDataObjects['U:U2 PI: SCREW-1 N: 15']
    del session.xyDataObjects['U:U2 PI: SCREW-1 N: 17']
    del session.xyDataObjects['U:U2 PI: SCREW-1 N: 19']
    del session.xyDataObjects['U:U3 PI: PLATE-1-1 N: 18']
    del session.xyDataObjects['U:U3 PI: PLATE-1-1 N: 35']
    del session.xyDataObjects['U:U3 PI: PLATE-2-1 N: 12']
    del session.xyDataObjects['U:U3 PI: PLATE-2-1 N: 34']
    session.odbs[odbPath].close()
    return x1, x2, x3


def Monitor(stepNumber, connectionNum):
    odbPath = currentPath + '\\outputSR\\i%s_Sub_CON%s-Job.odb' % (stepNumber, connectionNum)
    odb = openOdb(odbPath)
    ### Find last step and last frame ###
    last_step = odb.steps.values()[-1]
    last_frame = last_step.frames[-1]
    ## Check the element status ##
    status = last_frame.fieldOutputs['STATUS']
    frameTime = last_frame.frameValue
    totalTime = float(stepNumber) + float(frameTime)
    element_sets = odb.rootAssembly.elementSets
    bolt_region = element_sets['SET-BOLT_EDGE_ELEMENTS']
    plate1_region = element_sets['SET-PLATE1_EDGE_ELEMENTS']
    plate2_region = element_sets['SET-PLATE2_EDGE_ELEMENTS']
    ## check the bolt failed or not ##
    bolt_status = status.getSubset(region=bolt_region).values
    bolt_failed_element_number = 0
    for i in range(len(bolt_status)):
        if bolt_status[i].data == 0.0:
            bolt_failed_element_number += 1
        else:
            pass
    ## check plate1 failed or not ##
    plate1_status = status.getSubset(region=plate1_region).values
    plate1_failed_element_number = 0
    for i in range(len(plate1_status)):
        if plate1_status[i].data == 0:
            plate1_failed_element_number += 1
        else:
            pass
    ## check plate2 failed or not ##
    plate2_status = status.getSubset(region=plate2_region).values
    plate2_failed_element_number = 0
    for i in range(len(plate2_status)):
        if plate2_status[i].data == 0:
            plate2_failed_element_number += 1
        else:
            pass
    # output element status, '1' for not failed, '0' for failed ##
    element_monitor = open('Element_Monitor_Con_%s.txt'%connectionNum, 'w')
    if bolt_failed_element_number or plate1_failed_element_number or plate2_failed_element_number == 0:
        element_monitor.writelines('1\n')
        element_monitor.writelines('Still going strong')
    else:
        element_monitor.writelines('0\n')
        element_monitor.writelines('Connection failed at %s seconds!!' % totalTime)
        dict = {'bolt_failed': bolt_failed_element_number,
                'plate1_failed': plate1_failed_element_number,
                'plate2_failed': plate2_failed_element_number}
        # first make keys and values in the dictionary as two lists, then using index to find the keys #
        for a in range(len(dict.values())):
            if list(dict.values())[a] != 0:
                failed_part = list(dict.keys())[a]
        element_monitor.writelines(failed_part)
    element_monitor.close()
    # close odb file and exit the code #
    odb.close()


def StiffnessOutput(stepNumber, stepName, connectionNum):
    odbPath = currentPath + '\\outputSR\\i%s_Sub_CON%s-Job.odb'%(stepNumber, connectionNum)
    ### Monitor for element deletion ###
    if os.path.exists(currentPath + '/Element_Monitor_Con_%s.txt'%connectionNum):
        Element_monitor = open('Element_Monitor_Con_%s.txt'%connectionNum, 'r')
        Element_status = Element_monitor.readlines()
        Element_monitor.close()
        Element_status_switch = Element_status[0].split()
        # Make it float #
        Element_status_switch = float(Element_status_switch[0])
    else:
        Element_status_switch = 1
    ##### If element not deleted in this step, then calculate the stiffness ####
    if Element_status_switch == 1:
        CF1_endStep, CF2_endStep, CF3_endStep, CF1_preStep, CF2_preStep, CF3_preStep, RF1, RF2, RF3, RF_SUM = \
            ContactForce(stepNumber, stepName, connectionNum)
        length1, length2, length3 = Displacement(stepNumber, connectionNum)
        ### Write output to .csv files ###
        # RF1 #
        RF1_file = open(currentPath + '\\outputSR\\Connection_%s-RF1.csv'%(connectionNum), 'a')
        for data in RF1:
            RF1_file.write(str(data)[1:-1]+"\n")
        RF1_file.close()
        # RF2 #
        RF2_file = open(currentPath + '\\outputSR\\Connection_%s-RF2.csv'%(connectionNum), 'a')
        for data in RF2:
            RF2_file.write(str(data)[1:-1] + "\n")
        RF2_file.close()
        # RF3 #
        RF3_file = open(currentPath + '\\outputSR\\Connection_%s-RF3.csv'%(connectionNum), 'a')
        for data in RF3:
            RF3_file.write(str(data)[1:-1] + "\n")
        RF3_file.close()
        # RF_SUM #
        RF_SUM_file = open(currentPath + '\\outputSR\\Connection_%s-RF4.csv' % (connectionNum), 'a')
        for data in RF_SUM:
            RF_SUM_file.write(str(data)[1:-1] + "\n")
        RF_SUM_file.close()
        ## Check the previous force and displacement ##
        ## Initial stiffness ##
        if not os.path.exists(currentPath + '/stiffness_%s.log' % connectionNum):
            Old_stiff1 = [(0.0, 0.0), (1000.0, 1e-5)]
            Old_stiff2 = [(0.0, 0.0), (5000.0, 1e-5)]
            Old_stiff3 = [(0.0, 0.0), (1000.0, 1e-5)]
        ## Check previous stiffness ##
        else:
            Old_stiffness_file = open('stiffness_%s.log'%connectionNum, 'r')
            Old_stiffness_file_lines = Old_stiffness_file.readlines()
            First_line = Old_stiffness_file_lines[0].split()
            Second_line = Old_stiffness_file_lines[1].split()
            Third_line = Old_stiffness_file_lines[2].split()
            Fourth_line = Old_stiffness_file_lines[3].split()
            CF1_old_P1 = First_line[0]
            CF2_old_P1 = First_line[1]
            CF3_old_P1 = First_line[2]
            Length1_old_P1 = Second_line[0]
            Length2_old_P1 = Second_line[1]
            Length3_old_P1 = Second_line[2]
            CF1_old_P2 = Third_line[0]
            CF2_old_P2 = Third_line[1]
            CF3_old_P2 = Third_line[2]
            Length1_old_P2 = Fourth_line[0]
            Length2_old_P2 = Fourth_line[1]
            Length3_old_P2 = Fourth_line[2]
            Old_stiffness_file.close()
            ## Put data into a list ##
            Old_stiff1 = [(float(CF1_old_P1), float(Length1_old_P1)), (float(CF1_old_P2), float(Length1_old_P2))]
            Old_stiff2 = [(float(CF2_old_P1), float(Length2_old_P1)), (float(CF2_old_P2), float(Length2_old_P2))]
            Old_stiff3 = [(float(CF3_old_P1), float(Length3_old_P1)), (float(CF3_old_P2), float(Length3_old_P2))]
        ## When the force or displacement is extremely small, the stiffness could be unpropotional nonsense ##
        small_scal_stiffness_1 = -(CF1_endStep - CF1_preStep) / length1
        small_scal_stiffness_2 = -(CF2_endStep - CF2_preStep) / length2
        small_scal_stiffness_3 = -(CF3_endStep - CF3_preStep) / length3
        ## Then here calculate the second point for spring definition in Abaqus ##
        RF1_start = CF1_endStep
        RF2_start = CF2_endStep
        RF3_start = CF3_endStep
        RF1_end = RF1_start + (1e-6) * abs(small_scal_stiffness_1)
        RF2_end = RF2_start + (1e-6) * abs(small_scal_stiffness_2) ## Should avoid negative tension stiffness ##
        RF3_end = RF3_start + (1e-6) * abs(small_scal_stiffness_3)
        New_stiff1 = [(RF1_start, 0), (RF1_end, 1e-6)]
        New_stiff2 = [(RF2_start, 0), (RF2_end, 1e-6)]
        New_stiff3 = [(RF3_start, 0), (RF3_end, 1e-6)]
        Stiff1 = []
        Stiff2 = []
        Stiff3 = []
        if abs(CF1_endStep) < 50:
            Stiff1 = Old_stiff1
        else:
            Stiff1 = New_stiff1
        if abs(CF2_endStep) < 10:
            Stiff2 = Old_stiff2
        else:
            Stiff2 = New_stiff2
        if abs(CF3_endStep) < 50:
            Stiff3 = Old_stiff3
        else:
            Stiff3 = New_stiff3
        ## The data must be sorted before import to Abaqus ##
        list1sorted = sorted(Stiff1, key=lambda element: element[1])
        list2sorted = sorted(Stiff2, key=lambda element: element[1])
        list3sorted = sorted(Stiff3, key=lambda element: element[1])
        CF1_NEW_P1 = list1sorted[0][0]
        CF2_NEW_P1 = list2sorted[0][0]
        CF3_NEW_P1 = list3sorted[0][0]
        Length1_NEW_P1 = list1sorted[0][1]
        Length2_NEW_P1 = list2sorted[0][1]
        Length3_NEW_P1 = list3sorted[0][1]
        CF1_NEW_P2 = list1sorted[1][0]
        CF2_NEW_P2 = list2sorted[1][0]
        CF3_NEW_P2 = list3sorted[1][0]
        Length1_NEW_P2 = list1sorted[1][1]
        Length2_NEW_P2 = list2sorted[1][1]
        Length3_NEW_P2 = list3sorted[1][1]
    ##### If element deleted in this step, then:
    else:
        CF1_NEW_P1 = CF2_NEW_P1 = CF3_NEW_P1 = 1
        Length1_NEW_P1 = Length2_NEW_P1 = Length3_NEW_P1 = 0
        CF1_NEW_P2 = CF2_NEW_P2 = CF3_NEW_P2 = 1
        Length1_NEW_P2 = Length2_NEW_P2 = Length3_NEW_P2 = 1
    #############################################################
    # Write output #
    outputfile = open('stiffness_%s.log'%connectionNum, 'w')
    stiffness_data = '%s %s %s\n %s %s %s\n %s %s %s\n %s %s %s\n' % (CF1_NEW_P1, CF2_NEW_P1, CF3_NEW_P1,
        Length1_NEW_P1, Length2_NEW_P1, Length3_NEW_P1, CF1_NEW_P2, CF2_NEW_P2, CF3_NEW_P2,
        Length1_NEW_P2, Length2_NEW_P2, Length3_NEW_P2)
    outputfile.writelines(stiffness_data)
    outputfile.close()
    return RF1, RF2, RF3


### Open Odb file ###
currentPath=os.getcwd()
iterationFile = open('_iteration.log', 'r')
stepNumber = iterationFile.readlines()[1].split()[0]
iterationFile.close()
## Set step name ##
stepName = 'i%s_Sub_step'%stepNumber
## Stiffness calculation for connection-1 ##
connection_count = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
for connectionNum in connection_count:
    StiffnessOutput(stepNumber, stepName, connectionNum)
    Monitor(stepNumber, connectionNum)
exit(0)