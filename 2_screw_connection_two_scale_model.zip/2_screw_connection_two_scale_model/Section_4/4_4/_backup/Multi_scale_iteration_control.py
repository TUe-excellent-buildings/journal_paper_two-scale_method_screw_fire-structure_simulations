########################################################################################################
##### This script controlling iteration of the multi-scale couplling of the connection model,     ######
##### Input: Step number, Basic models of the HT, SR, and Sub.                                    ######
##### Output: .odb files of every steps.                                                          ######
##### By: Qingfeng Xu (Aiden)                                                   2019.09.13        ######
########################################################################################################
import os, shutil
import glob
import pandas as pd
from subprocess import run
from sys import exit
import Multi_scale_functions as MSF


## Find current Path ##
currentPath = os.getcwd()
## Initial the SegmentNumber ##
SegmentNumber = 0
SegmentSize = 1
stepTime = 2
## For each Segment, there are four steps multi-scale coupling ##
stepNumber = 0
stepSize = 4
## Initial the convergence, the first step should converge ##
convergence = True
### Record the segment and step number ###
all_step_Number = stepSize * SegmentSize
while stepNumber < 8:
    ## Write current segment and step size ##
    MSF.Step_Number_Control(SegmentNumber, stepNumber)
    ## Update heat transfer model ##
    MSF.HTupdate(stepNumber, stepTime)
    print('Heat transfer analysis running...')
    run("call abaqus cae noGUI=HT_Script_execute.py", shell=True)
    ## Update structural response model ##
    MSF.SRupdate(currentPath, stepNumber, stepTime)
    print('Structural analysis running...')
    run("call abaqus cae noGUI=SR_Script_execute.py", shell=True)
    ## Update small-scale model ##
    connectionNum = [1, 2, 3, 4]
    for CN in connectionNum:
        ## If connection model is not converge, or failed, the simulation should not continue ##
        convergence = MSF.Convergence_checking(currentPath, stepNumber, CN, convergence)
        if convergence == True:
            print("Now running submodel to measure spring stiffness-%s ..."%CN)
            MSF.Subupdate(stepNumber, CN, stepTime)
            run("call abaqus cae noGUI=Sub_Script_execute.py", shell=True)
        else:
        ## If failed, do not run small-scale model, set stiffness as constant value ##
            MSF.Stiffness_after_failure(CN)
    ## Find all the stiffness from submodel ##
    print("Calculating the spring stiffness.")
    run("call abaqus cae noGUI=_outputRequest.py", shell=True)
    stepNumber += 1
print("Multi-scale coupling for Segment-%s has been finished. "%SegmentNumber)
exit(0)
