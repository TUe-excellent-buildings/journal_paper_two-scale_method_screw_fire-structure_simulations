import os
from sys import exit
from abaqus import *
from odbAccess import *
from abaqusConstants import *
import visualization


def ContactForce(stepNumber, stepName, connectionNum):
    odbPath = currentPath + '\\outputSR\\i%s_Sub_CON%s-Job.odb' % (stepNumber, connectionNum)
    o1 = session.openOdb(odbPath)
    session.viewports['Viewport: 1'].setValues(displayedObject=o1)
    odb = session.odbs[odbPath]
    session.XYDataFromHistory(name='XYData-1', odb=odb,
                              outputVariableName='CFT1: CFT1     ASSEMBLY_CP-2-SCREW-1/ASSEMBLY_CP-2-PLATE-1-1',
                              steps=(stepName,), )
    session.XYDataFromHistory(name='XYData-2', odb=odb,
                              outputVariableName='CFT2: CFT2     ASSEMBLY_SCREW-THREAD-SURF_CNS_/ASSEMBLY_PLATE-INNER-SURF',
                              steps=(stepName,), )
    session.XYDataFromHistory(name='XYData-3', odb=odb,
                              outputVariableName='CFT3: CFT3     ASSEMBLY_CP-2-SCREW-1/ASSEMBLY_CP-2-PLATE-1-1',
                              steps=(stepName,), )
    session.XYDataFromHistory(name='XYData-4', odb=odb,
                              outputVariableName='CFTM: CFTM     ASSEMBLY_SCREW-THREAD-SURF_CNS_/ASSEMBLY_PLATE-INNER-SURF',
                              steps=(stepName,), )
    RF1 = session.xyDataObjects['XYData-1'][2:]
    RF2 = session.xyDataObjects['XYData-2'][2:]
    RF3 = session.xyDataObjects['XYData-3'][2:]
    RF_SUM = session.xyDataObjects['XYData-4'][2:]
    session.odbs[odbPath].close()
    # RF1 #
    RF1_file = open(currentPath + '\\outputSR\\_Connection_%s-RF1.csv' % (connectionNum), 'a')
    for data in RF1:
        RF1_file.write(str(data)[1:-1] + "\n")
    RF1_file.close()
    # RF2 #
    RF2_file = open(currentPath + '\\outputSR\\_Connection_%s-RF2.csv' % (connectionNum), 'a')
    for data in RF2:
        RF2_file.write(str(data)[1:-1] + "\n")
    RF2_file.close()
    # RF3 #
    RF3_file = open(currentPath + '\\outputSR\\_Connection_%s-RF3.csv' % (connectionNum), 'a')
    for data in RF3:
        RF3_file.write(str(data)[1:-1] + "\n")
    RF3_file.close()
    # RF_SUM #
    RF_SUM_file = open(currentPath + '\\outputSR\\_Connection_%s-RF4.csv' % (connectionNum), 'a')
    for data in RF_SUM:
        RF_SUM_file.write(str(data)[1:-1] + "\n")
    RF_SUM_file.close()
    del session.xyDataObjects['XYData-1']
    del session.xyDataObjects['XYData-2']
    del session.xyDataObjects['XYData-3']
    del session.xyDataObjects['XYData-4']


def SpringForce(stepNumber, ConnectionNum):
    odbPath = currentPath + '\\outputSR\\i%s_SR-Job.odb' % (stepNumber)
    o1 = session.openOdb(odbPath)
    session.viewports['Viewport: 1'].setValues(displayedObject=o1)
    odb = session.odbs[odbPath]
    RF1_Spring_name = 'Connector element total force: CTF1 PI: rootAssembly Element %s in ELSET WIRE-%s-SET-1'%(ConnectionNum, ConnectionNum)
    RF2_Spring_name = 'Connector element total force: CTF2 PI: rootAssembly Element %s in ELSET WIRE-%s-SET-1'%(ConnectionNum, ConnectionNum)
    RF3_Spring_name = 'Connector element total force: CTF3 PI: rootAssembly Element %s in ELSET WIRE-%s-SET-1'%(ConnectionNum, ConnectionNum)
    connection_RF_1 = 'connection%s_RF_1'%ConnectionNum
    connection_RF_2 = 'connection%s_RF_2'%ConnectionNum
    connection_RF_3 = 'connection%s_RF_3'%ConnectionNum
    session.XYDataFromHistory(name=connection_RF_1, odb=odb, outputVariableName=RF1_Spring_name,
                              steps=('i0_SR-Step',), )
    session.XYDataFromHistory(name=connection_RF_2, odb=odb, outputVariableName=RF2_Spring_name,
                              steps=('i0_SR-Step',), )
    session.XYDataFromHistory(name=connection_RF_3, odb=odb, outputVariableName=RF3_Spring_name,
                              steps=('i0_SR-Step',), )
    RF1 = session.xyDataObjects[connection_RF_1][1:]
    RF2 = session.xyDataObjects[connection_RF_2][1:]
    RF3 = session.xyDataObjects[connection_RF_3][1:]
    session.odbs[odbPath].close()
    # RF1 #
    RF1_file = open(currentPath + '\\outputSR\\_Spring_%s-RF1.csv' % (connectionNum), 'a')
    for data in RF1:
        RF1_file.write(str(data)[1:-1] + "\n")
    RF1_file.close()
    # RF2 #
    RF2_file = open(currentPath + '\\outputSR\\_Spring_%s-RF2.csv' % (connectionNum), 'a')
    for data in RF2:
        RF2_file.write(str(data)[1:-1] + "\n")
    RF2_file.close()
    # RF3 #
    RF3_file = open(currentPath + '\\outputSR\\_Spring_%s-RF3.csv' % (connectionNum), 'a')
    for data in RF3:
        RF3_file.write(str(data)[1:-1] + "\n")
    RF3_file.close()
    del session.xyDataObjects[connection_RF_1]
    del session.xyDataObjects[connection_RF_2]
    del session.xyDataObjects[connection_RF_3]


### Open Odb file ###
currentPath=os.getcwd()
## Stiffness calculation for connection-1 ##
connection_count = [1, 2, 3, 4]
interation_num = 8
for stepNumber in range(interation_num):
    stepName = 'i%s_Sub_step' % stepNumber
    for connectionNum in connection_count:
        try:
            SpringForce(stepNumber, connectionNum)
        except:
            print('Odb file for SR-%s is not exist.' % stepNumber)
        try:
            ContactForce(stepNumber, stepName, connectionNum)
        except:
            print('Odb file for connection-%s is not exist.'%stepNumber)
exit(0)