## Temp Data Processing, output _temp.py ###
from abaqus import *
from odbAccess import *
from abaqusConstants import *
import os, shutil, sys


def TemperatureOutput(stepNumber, Point1_Name, Point2_Name, ConnectionNum):
    set_Name = 'TEMP_REF-%s'%ConnectionNum
    session.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=(('NT11', NODAL),), nodeSets=(set_Name,))
    NT1data = session.xyDataObjects[Point1_Name]
    NT2data = session.xyDataObjects[Point2_Name]
    averagelist = []
    timelist = []
    for i in range(len(NT1data)):
        averagelist.append((NT1data[i][1] + NT2data[i][1]) / 2)  ## calculate the average temperature in a list##
        timelist.append(NT1data[i][0])  ## put time into a list ##
        temptuple = tuple(zip(timelist, averagelist))  ## zip two list into a tuple, abaqus formate ##
    _tempfile = open('i%s_Connection%s_temp.py' % (stepNumber, ConnectionNum), 'w')  ## create file to store data
    content1 = "mod.TabularAmplitude(timeSpan=TOTAL, name='i" + str(stepNumber) + "_Temp', data=("
    _tempfile.write(content1)  ## create necessary words for Amplitude data
    a = str(temptuple)[1:-1] + ",), smooth=SOLVER_DEFAULT)"  ## again, necessary words for Amplitude data formate
    _tempfile.write(a)
    _tempfile.close()

### Change work directory to find _iteration.log and output temp.py for submodel ###
currentPath=os.getcwd()
stepNumber=0
stepNumber=open('_iteration.log', 'r').readlines()[1].split()[0]
### Copy .odb file in order not to influence the following step ###
oldOdb=currentPath+'\\outputSR\\i'+str(stepNumber)+'_SR-Job.odb'
newOdb=currentPath+'\\outputSR\\i'+str(stepNumber)+'_SR-Job_copy.odb'
shutil.copyfile(oldOdb, newOdb)
## Switch case ##
Connection1_point1 = 'NT11 PI: FRAME-2 N: 29'
Connection1_point2 = 'NT11 PI: INNER_PLATE-1 N: 68'
Connection2_point1 = 'NT11 PI: FRAME-1 N: 42'
Connection2_point2 = 'NT11 PI: INNER_PLATE-1 N: 104'
Connection3_point1 = 'NT11 PI: FRAME-2 N: 7'
Connection3_point2 = 'NT11 PI: INNER_PLATE-1 N: 105'
Connection4_point1 = 'NT11 PI: FRAME-1 N: 53'
Connection4_point2 = 'NT11 PI: INNER_PLATE-1 N: 80'
### Import iterationNum ###
o2 = session.openOdb(name=newOdb)
odb = session.odbs[newOdb]
session.viewports['Viewport: 1'].setValues(displayedObject=o2)
TemperatureOutput(stepNumber, Connection1_point1, Connection1_point2, 1)
TemperatureOutput(stepNumber, Connection2_point1, Connection2_point2, 2)
TemperatureOutput(stepNumber, Connection3_point1, Connection3_point2, 3)
TemperatureOutput(stepNumber, Connection4_point1, Connection4_point2, 4)
session.odbs[newOdb].close()
sys.exit()
# Stiffness()