# Iteration Number: 0, IterationSize: 10s.
# IterationTimeSlot: 0-10s, TotalSimulationDuration: 100s.
# 1 panel, 48 partition(s).
###########################################################################
## Name:        HT_basicModel.py 									 	 ##
##																		 ##
## Description: Basic Heat Transfer (HT) Model for a self supporting     ##
## 				sandwich panel facade system, including main structure,  ##
##				framework and connections. This model can be used in 	 ##
##				a two-way coupled thermo-mechanical CFD-FEM Analysis.	 ##
##						 												 ##
## Additional	This script is INCOMPLETE additional python code is      ##
## Info:		appended by geometric update program upGeomHT based on   ##
##				the current iteration in the coupling analysis.          ##
##				The complete coupling procedure is managed by 			 ##
## 				Master Program FDS-2-Abaqus.							 ##
## 																		 ##
## Input :		AST_Amp_Data.py											 ##
##				(code running this script is appende by upGeomHT)        ##
##																		 ##
## Output:      Requires a \\_outputHT\\ folder to store *.odb output    ##
##																		 ##
###########################################################################
## Version 3.0                                       by Qingfeng Xu      ##
## August 2020                                         q.xuq@tue.nl      ##
###########################################################################

############################## Begin Script ###############################
# -*- coding: mbcs -*-
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from abaqusConstants import *
cliCommand("""session.journalOptions.setValues(replayGeometry=COORDINATE,
	recoverGeometry=COORDINATE)""")
### use this lines for use in FDS-2-Abaqus (relative path)
currentPath = os.getcwd()
# if not os.path.exists(currentPath + '\\outputSR\\'):
#     os.makedirs(currentPath + '\\outputSR\\')
### Set directory to outputHT, if not exists, create the folder ##
os.chdir(currentPath + '\\outputHT\\')
### Initial Code Definitions ###
mod = mdb.models['Model-1']
modRa = mod.rootAssembly
## Specify-Attributes ##
mod.setValues(absoluteZero=-273.15, stefanBoltzmann=5.67e-08)
### CREATE PARTS ###
## Plate ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    2.7, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.45, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.45, 0.0),
    ))
mod.Part(dimensionality=THREE_D, name='Inner_plate', type=
    DEFORMABLE_BODY)
mod.parts['Inner_plate'].BaseShellExtrude(depth=3.6, sketch=
    mod.sketches['__profile__'])
## Partition plate ###
# YZ Plane
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    0.45, principalPlane=YZPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    0.9, principalPlane=YZPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.35, principalPlane=YZPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.8, principalPlane=YZPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    2.25, principalPlane=YZPLANE)
# XY plane
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    0.45, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    0.9, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.35, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.8, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    2.25, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    2.7, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    3.15, principalPlane=XYPLANE)
# Create partition #
mod.parts['Inner_plate'].PartitionFaceByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[2], faces=
    mod.parts['Inner_plate'].faces.findAt(((1.8, 0.0, 2.4),
    )))
mod.parts['Inner_plate'].PartitionFaceByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[3], faces=
    mod.parts['Inner_plate'].faces.findAt(((1.2, 0.0, 1.2),
    )))
mod.parts['Inner_plate'].PartitionFaceByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[4], faces=
    mod.parts['Inner_plate'].faces.findAt(((1.5, 0.0, 1.2),
    )))
mod.parts['Inner_plate'].PartitionFaceByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[5], faces=
    mod.parts['Inner_plate'].faces.findAt(((1.8, 0.0, 1.2),
    )))
mod.parts['Inner_plate'].PartitionFaceByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[6], faces=
    mod.parts['Inner_plate'].faces.findAt(((2.1, 0.0, 1.2),
    )))
mod.parts['Inner_plate'].PartitionFaceByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[7], faces=
    mod.parts['Inner_plate'].faces.findAt(((2.1, 0.0, 2.4),
    ), ((1.65, 0.0, 2.4), ), ((1.2, 0.0, 2.4), ), ((0.75, 0.0, 2.4), ), ((0.3,
    0.0, 2.4), ), ((2.4, 0.0, 1.2), ), ))
mod.parts['Inner_plate'].PartitionFaceByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[8], faces=
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 1.5),
    ), ((0.6, 0.0, 1.5), ), ((1.05, 0.0, 1.5), ), ((1.5, 0.0, 1.5), ), ((1.95,
    0.0, 1.5), ), ((2.4, 0.0, 1.5), ), ))
mod.parts['Inner_plate'].PartitionFaceByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[9], faces=
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 1.8),
    ), ((0.6, 0.0, 1.8), ), ((1.05, 0.0, 1.8), ), ((1.5, 0.0, 1.8), ), ((1.95,
    0.0, 1.8), ), ((2.4, 0.0, 1.8), ), ))
mod.parts['Inner_plate'].PartitionFaceByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[10], faces=
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 2.1),
    ), ((0.6, 0.0, 2.1), ), ((1.05, 0.0, 2.1), ), ((1.5, 0.0, 2.1), ), ((1.95,
    0.0, 2.1), ), ((2.4, 0.0, 2.1), ), ))
mod.parts['Inner_plate'].PartitionFaceByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[11], faces=
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 2.4),
    ), ((0.6, 0.0, 2.4), ), ((1.05, 0.0, 2.4), ), ((1.5, 0.0, 2.4), ), ((1.95,
    0.0, 2.4), ), ((2.4, 0.0, 2.4), ), ))
mod.parts['Inner_plate'].PartitionFaceByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[12], faces=
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 2.7),
    ), ((0.6, 0.0, 2.7), ), ((1.05, 0.0, 2.7), ), ((1.5, 0.0, 2.7), ), ((1.95,
    0.0, 2.7), ), ((2.4, 0.0, 2.7), ), ))
mod.parts['Inner_plate'].PartitionFaceByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[13], faces=
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 3.0),
    ), ((0.6, 0.0, 3.0), ), ((1.05, 0.0, 3.0), ), ((1.5, 0.0, 3.0), ), ((1.95,
    0.0, 3.0), ), ((2.4, 0.0, 3.0), ), ))
## Outer_plate ##
mod.Part(name='Outer_plate', objectToCopy=
    mod.parts['Inner_plate'])
# Drilling hole for Inner plates #
mod.ConstrainedSketch(gridSpacing=0.22, name='__profile__',
    sheetSize=8.99, transform=
    mod.parts['Inner_plate'].MakeSketchTransform(
    sketchPlane=mod.parts['Inner_plate'].faces.findAt((1.8,
    0.0, 2.4), (0.0, -1.0, 0.0)), sketchPlaneSide=SIDE1,
    sketchUpEdge=mod.parts['Inner_plate'].edges.findAt((
    0.675, 0.0, 0.0), ), sketchOrientation=RIGHT, origin=(1.35, 0.0, 1.8)))
mod.parts['Inner_plate'].projectReferencesOntoSketch(filter=
    COPLANAR_EDGES, sketch=mod.sketches['__profile__'])
mod.sketches['__profile__'].CircleByCenterPerimeter(center=(
    -1.725, -1.275), point1=(-1.725, -1.27))
mod.sketches['__profile__'].CircleByCenterPerimeter(center=(
    1.725, -1.275), point1=(1.725, -1.27))
mod.sketches['__profile__'].CircleByCenterPerimeter(center=(
    -1.725, 1.275), point1=(-1.725, 1.27))
mod.sketches['__profile__'].CircleByCenterPerimeter(center=(
    1.725, 1.275), point1=(1.725, 1.27))
mod.sketches['__profile__'].geometry.findAt((-1.725, -1.28))
mod.sketches['__profile__'].RadialDimension(curve=
    mod.sketches['__profile__'].geometry.findAt((-1.725,
    -1.28), ), radius=0.0025, textPoint=(-1.68158407211304, -1.27378103733063))
mod.sketches['__profile__'].geometry.findAt((-1.725, 1.28))
mod.sketches['__profile__'].RadialDimension(curve=
    mod.sketches['__profile__'].geometry.findAt((-1.725,
    1.28), ), radius=0.0025, textPoint=(-1.70474786758423, 1.26730313301086))
mod.sketches['__profile__'].geometry.findAt((1.725, 1.28))
mod.sketches['__profile__'].RadialDimension(curve=
    mod.sketches['__profile__'].geometry.findAt((1.725,
    1.28), ), radius=0.0025, textPoint=(1.75285963267088, 1.26730098724365))
mod.sketches['__profile__'].geometry.findAt((1.725, -1.28))
mod.sketches['__profile__'].RadialDimension(curve=
    mod.sketches['__profile__'].geometry.findAt((1.725,
    -1.28), ), radius=0.0025, textPoint=(1.74953700900078, -1.28469412624836))
mod.parts['Inner_plate'].CutExtrude(flipExtrudeDirection=OFF,
    sketch=mod.sketches['__profile__'], sketchOrientation=
    RIGHT, sketchPlane=mod.parts['Inner_plate'].faces.findAt(
    (1.8, 0.0, 2.4), (0.0, -1.0, 0.0)), sketchPlaneSide=SIDE1, sketchUpEdge=
    mod.parts['Inner_plate'].edges.findAt((0.675, 0.0, 0.0),
    ))
del mod.sketches['__profile__']
## Frame ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].Line(point1=(0.0, 0.15), point2=(
    0.0, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.075))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.075),
    ))
mod.sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    0.15, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.075, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.075, 0.0),
    ))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.075))
mod.sketches['__profile__'].geometry.findAt((0.075, 0.0))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.075),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    0.075, 0.0), ))
mod.sketches['__profile__'].Line(point1=(0.15, 0.0), point2=(
    0.15, 0.15))
mod.sketches['__profile__'].geometry.findAt((0.15, 0.075))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.15,
    0.075), ))
mod.sketches['__profile__'].geometry.findAt((0.075, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.15, 0.075))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((0.075, 0.0),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    0.15, 0.075), ))
mod.Part(dimensionality=THREE_D, name='Frame', type=
    DEFORMABLE_BODY)
mod.parts['Frame'].BaseShellExtrude(depth=2.7, sketch=
    mod.sketches['__profile__'])
del mod.sketches['__profile__']
# drilling hole for frame #
mod.ConstrainedSketch(gridSpacing=0.13, name='__profile__',
    sheetSize=5.41, transform=
    mod.parts['Frame'].MakeSketchTransform(
    sketchPlane=mod.parts['Frame'].faces.findAt((0.15, 0.1,
    1.8), (1.0, 0.0, 0.0)), sketchPlaneSide=SIDE1,
    sketchUpEdge=mod.parts['Frame'].edges.findAt((0.15,
    0.0375, 0.0), ), sketchOrientation=RIGHT, origin=(0.15, 0.075, 1.35)))
mod.parts['Frame'].projectReferencesOntoSketch(filter=
    COPLANAR_EDGES, sketch=mod.sketches['__profile__'])
mod.sketches['__profile__'].CircleByCenterPerimeter(center=(
    -1.3, 0.0), point1=(-1.2675, 0.0))
mod.sketches['__profile__'].CircleByCenterPerimeter(center=(
    1.3, 0.0), point1=(1.235, 0.0))
mod.sketches['__profile__'].vertices.findAt((-1.3, 0.0))
mod.sketches['__profile__'].geometry.findAt((1.215, -0.075))
mod.sketches['__profile__'].DistanceDimension(entity1=
    mod.sketches['__profile__'].vertices.findAt((-1.3, 0.0),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    1.215, -0.075), ), textPoint=(-1.16483964920044, -0.0473221510648727),
    value=0.075)
mod.sketches['__profile__'].vertices.findAt((-1.3, 0.0))
mod.sketches['__profile__'].geometry.findAt((-1.35, 0.0))
mod.sketches['__profile__'].DistanceDimension(entity1=
    mod.sketches['__profile__'].vertices.findAt((-1.3, 0.0),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    -1.35, 0.0), ), textPoint=(-1.32832565307617, -0.0621682971715927), value=
    0.075)
mod.sketches['__profile__'].geometry.findAt((-1.3075, 0.0))
mod.sketches['__profile__'].RadialDimension(curve=
    mod.sketches['__profile__'].geometry.findAt((-1.3075,
    0.0), ), radius=0.0025, textPoint=(-1.20013751983643, -0.0380432575941086))
mod.sketches['__profile__'].vertices.findAt((1.3, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.075))
mod.sketches['__profile__'].DistanceDimension(entity1=
    mod.sketches['__profile__'].vertices.findAt((1.3, 0.0), )
    , entity2=mod.sketches['__profile__'].geometry.findAt((
    0.0, 0.075), ), textPoint=(1.10039865076542, 0.0624770104885101), value=
    0.075)
mod.sketches['__profile__'].vertices.findAt((1.3, 0.0))
mod.sketches['__profile__'].geometry.findAt((1.35, 0.0))
mod.sketches['__profile__'].DistanceDimension(entity1=
    mod.sketches['__profile__'].vertices.findAt((1.3, 0.0), )
    , entity2=mod.sketches['__profile__'].geometry.findAt((
    1.35, 0.0), ), textPoint=(1.33528863862157, 0.0545768916606903), value=
    0.075)
mod.sketches['__profile__'].geometry.findAt((1.34, 0.0))
mod.sketches['__profile__'].RadialDimension(curve=
    mod.sketches['__profile__'].geometry.findAt((1.34, 0.0),
    ), radius=0.0025, textPoint=(1.17315917313099, 0.049836802482605))
mod.parts['Frame'].CutExtrude(flipExtrudeDirection=OFF,
    sketch=mod.sketches['__profile__'], sketchOrientation=
    RIGHT, sketchPlane=mod.parts['Frame'].faces.findAt((0.15,
    0.1, 1.8), (1.0, 0.0, 0.0)), sketchPlaneSide=SIDE1, sketchUpEdge=
    mod.parts['Frame'].edges.findAt((0.15, 0.0375, 0.0), ))
del mod.sketches['__profile__']
# Partition frame #
mod.parts['Frame'].DatumPlaneByPrincipalPlane(offset=0.15,
    principalPlane=XYPLANE)
mod.parts['Frame'].DatumPlaneByPrincipalPlane(offset=2.55,
    principalPlane=XYPLANE)
mod.parts['Frame'].PartitionFaceByDatumPlane(datumPlane=
    mod.parts['Frame'].datums[3], faces=
    mod.parts['Frame'].faces.findAt(((0.15, 0.049152,
    2.651414), ), ((0.0, 0.100848, 2.651414), ), ((0.1, 0.0, 1.8), ), ))
mod.parts['Frame'].PartitionFaceByDatumPlane(datumPlane=
    mod.parts['Frame'].datums[4], faces=
    mod.parts['Frame'].faces.findAt(((0.15, 0.100705,
    1.89851), ), ((0.0, 0.049295, 1.89851), ), ((0.05, 0.0, 1.2), ), ))
## Insulation ##
mod.ConstrainedSketch(name='__profile__', sheetSize=20.0)
mod.sketches['__profile__'].rectangle(point1=(0.0, 0.0),
    point2=(2.7, 0.08))
mod.Part(dimensionality=THREE_D, name='Insulation', type=
    DEFORMABLE_BODY)
mod.parts['Insulation'].BaseSolidExtrude(depth=3.6, sketch=
    mod.sketches['__profile__'])
del mod.sketches['__profile__']
### CREATE MATERIAL PROPERTIES ###
## Steel properties ## including temperature dependant properties ##
mod.Material(name='Steel_S355')
mod.materials['Steel_S355'].Elastic(table=((210000000000.0, 0.3,
    0), (210000000000.0, 0.3, 20), (210000000000.0, 0.3, 100), (
    126000000000.0, 0.3, 500), (63000000000.0, 0.3, 600), (31000000000.0,
    0.3, 700), (10000000000.0, 0.3, 1000)), temperatureDependency=ON)
mod.materials['Steel_S355'].Density(table=((7850.0, ), ))
mod.materials['Steel_S355'].Expansion(table=((1.51e-05, 20.0), (
    1.51e-05, 750.0), (1.31e-05, 760.0), (1.31e-05, 860.0), (1.51e-05, 870.0),
    (1.51e-05, 1200.0)), temperatureDependency=ON)
mod.materials['Steel_S355'].SpecificHeat(table=((440.0, 20.0), (
    760.0, 600.0), (5000.0, 735.0), (650.4, 900.0), (650.0, 1200.0)),
    temperatureDependency=ON)
mod.materials['Steel_S355'].Conductivity(table=((53.3, 20.0), (
    27.4, 800.0), (27.3, 1200.0)), temperatureDependency=ON)
mod.materials['Steel_S355'].Plastic(table=(
	(355000000.0, 0.0, 0), (510000000.0, 0.0084, 0),
	(355000000.0, 0.0, 400), (510000000.0, 0.0076, 400),
	(177000000.0, 0.0, 600), (255000000.0, 0.0072, 600),
	(88800000.0, 0.0, 700), (128000000.0, 0.0071, 700),
	(35500000.0, 0.0, 800), (51000000.0, 0.0083, 800),
	(17800000.0, 0.0, 1000), (25500000.0, 0.0082, 1000)), temperatureDependency=ON)
## Insulation properties ##
mod.Material(name='PIR_PUR')
mod.materials['PIR_PUR'].Elastic(table=((20000000, 0.20), ))
mod.materials['PIR_PUR'].Density(table=((45, ), ))
mod.materials['PIR_PUR'].Conductivity(table=((0.023, ), ))
mod.materials['PIR_PUR'].SpecificHeat(table=((1400.0, ), ))
mod.materials['PIR_PUR'].Expansion(table=((5e-5, ), ))
### CREATE & ASSIGN SECTION ###
## Inner plate ##
mod.HomogeneousShellSection(idealization=NO_IDEALIZATION,
    integrationRule=SIMPSON, material='Steel_S355', name='Inner_steel_plate',
    numIntPts=5, poissonDefinition=DEFAULT, preIntegrate=OFF, temperature=
    GRADIENT, thickness=0.001, thicknessField='', thicknessModulus=None,
    thicknessType=UNIFORM, useDensity=OFF)
mod.parts['Inner_plate'].SectionAssignment(offset=0.0,
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['Inner_plate'].faces.findAt(((2.1, 0.0,
    0.3), (0.0, -1.0, 0.0)), ((2.1, 0.0, 0.75), (0.0, -1.0, 0.0)), ((2.1, 0.0,
    1.2), (0.0, -1.0, 0.0)), ((2.1, 0.0, 1.65), (0.0, -1.0, 0.0)), ((2.1, 0.0,
    2.1), (0.0, -1.0, 0.0)), ((2.1, 0.0, 2.55), (0.0, -1.0, 0.0)), ((2.1, 0.0,
    3.0), (0.0, -1.0, 0.0)), ((2.1, 0.0, 3.45), (0.0, -1.0, 0.0)), ((1.65, 0.0,
    0.3), (0.0, -1.0, 0.0)), ((1.65, 0.0, 0.75), (0.0, -1.0, 0.0)), ((1.65,
    0.0, 1.2), (0.0, -1.0, 0.0)), ((1.65, 0.0, 1.65), (0.0, -1.0, 0.0)), ((
    1.65, 0.0, 2.1), (0.0, -1.0, 0.0)), ((1.65, 0.0, 2.55), (0.0, -1.0, 0.0)),
    ((1.65, 0.0, 3.0), (0.0, -1.0, 0.0)), ((1.65, 0.0, 3.45), (0.0, -1.0,
    0.0)), ((1.2, 0.0, 0.3), (0.0, -1.0, 0.0)), ((1.2, 0.0, 0.75), (0.0, -1.0,
    0.0)), ((1.2, 0.0, 1.2), (0.0, -1.0, 0.0)), ((1.2, 0.0, 1.65), (0.0, -1.0,
    0.0)), ((1.2, 0.0, 2.1), (0.0, -1.0, 0.0)), ((1.2, 0.0, 2.55), (0.0, -1.0,
    0.0)), ((1.2, 0.0, 3.0), (0.0, -1.0, 0.0)), ((1.2, 0.0, 3.45), (0.0, -1.0,
    0.0)), ((0.75, 0.0, 0.3), (0.0, -1.0, 0.0)), ((0.75, 0.0, 0.75), (0.0,
    -1.0, 0.0)), ((0.75, 0.0, 1.2), (0.0, -1.0, 0.0)), ((0.75, 0.0, 1.65), (
    0.0, -1.0, 0.0)), ((0.75, 0.0, 2.1), (0.0, -1.0, 0.0)), ((0.75, 0.0, 2.55),
    (0.0, -1.0, 0.0)), ((0.75, 0.0, 3.0), (0.0, -1.0, 0.0)), ((0.75, 0.0,
    3.45), (0.0, -1.0, 0.0)), ((0.3, 0.0, 0.3), (0.0, -1.0, 0.0)), ((0.3, 0.0,
    0.75), (0.0, -1.0, 0.0)), ((0.3, 0.0, 1.2), (0.0, -1.0, 0.0)), ((0.3, 0.0,
    1.65), (0.0, -1.0, 0.0)), ((0.3, 0.0, 2.1), (0.0, -1.0, 0.0)), ((0.3, 0.0,
    2.55), (0.0, -1.0, 0.0)), ((0.3, 0.0, 3.0), (0.0, -1.0, 0.0)), ((0.3, 0.0,
    3.45), (0.0, -1.0, 0.0)), ((2.4, 0.0, 2.85), (0.0, -1.0, 0.0)), ((2.4, 0.0,
    2.4), (0.0, -1.0, 0.0)), ((2.4, 0.0, 1.95), (0.0, -1.0, 0.0)), ((2.4, 0.0,
    1.5), (0.0, -1.0, 0.0)), ((2.4, 0.0, 1.05), (0.0, -1.0, 0.0)), ((2.4, 0.0,
    0.6), (0.0, -1.0, 0.0)), ((2.4, 0.0, 0.15), (0.0, -1.0, 0.0)), ((2.4, 0.0,
    3.3), (0.0, -1.0, 0.0)), )), sectionName='Inner_steel_plate',
    thicknessAssignment=FROM_SECTION)
## Outer plate ##
mod.parts['Outer_plate'].SectionAssignment(offset=0.0,
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['Outer_plate'].faces.findAt(((2.55, 0.0,
    3.0), (0.0, -1.0, 0.0)), ((2.1, 0.0, 3.0), (0.0, -1.0, 0.0)), ((1.65, 0.0,
    3.0), (0.0, -1.0, 0.0)), ((1.2, 0.0, 3.0), (0.0, -1.0, 0.0)), ((0.75, 0.0,
    3.0), (0.0, -1.0, 0.0)), ((0.3, 0.0, 3.0), (0.0, -1.0, 0.0)), ((2.55, 0.0,
    2.55), (0.0, -1.0, 0.0)), ((2.1, 0.0, 2.55), (0.0, -1.0, 0.0)), ((1.65,
    0.0, 2.55), (0.0, -1.0, 0.0)), ((1.2, 0.0, 2.55), (0.0, -1.0, 0.0)), ((
    0.75, 0.0, 2.55), (0.0, -1.0, 0.0)), ((0.3, 0.0, 2.55), (0.0, -1.0, 0.0)),
    ((2.55, 0.0, 2.1), (0.0, -1.0, 0.0)), ((2.1, 0.0, 2.1), (0.0, -1.0, 0.0)),
    ((1.65, 0.0, 2.1), (0.0, -1.0, 0.0)), ((1.2, 0.0, 2.1), (0.0, -1.0, 0.0)),
    ((0.75, 0.0, 2.1), (0.0, -1.0, 0.0)), ((0.3, 0.0, 2.1), (0.0, -1.0, 0.0)),
    ((2.55, 0.0, 1.65), (0.0, -1.0, 0.0)), ((2.1, 0.0, 1.65), (0.0, -1.0,
    0.0)), ((1.65, 0.0, 1.65), (0.0, -1.0, 0.0)), ((1.2, 0.0, 1.65), (0.0,
    -1.0, 0.0)), ((0.75, 0.0, 1.65), (0.0, -1.0, 0.0)), ((0.3, 0.0, 1.65), (
    0.0, -1.0, 0.0)), ((2.55, 0.0, 1.2), (0.0, -1.0, 0.0)), ((2.1, 0.0, 1.2), (
    0.0, -1.0, 0.0)), ((1.65, 0.0, 1.2), (0.0, -1.0, 0.0)), ((1.2, 0.0, 1.2), (
    0.0, -1.0, 0.0)), ((0.75, 0.0, 1.2), (0.0, -1.0, 0.0)), ((0.3, 0.0, 1.2), (
    0.0, -1.0, 0.0)), ((2.55, 0.0, 0.75), (0.0, -1.0, 0.0)), ((2.1, 0.0, 0.75),
    (0.0, -1.0, 0.0)), ((1.65, 0.0, 0.75), (0.0, -1.0, 0.0)), ((1.2, 0.0,
    0.75), (0.0, -1.0, 0.0)), ((0.75, 0.0, 0.75), (0.0, -1.0, 0.0)), ((0.3,
    0.0, 0.75), (0.0, -1.0, 0.0)), ((0.15, 0.0, 3.3), (0.0, -1.0, 0.0)), ((0.6,
    0.0, 3.3), (0.0, -1.0, 0.0)), ((1.05, 0.0, 3.3), (0.0, -1.0, 0.0)), ((2.55,
    0.0, 0.3), (0.0, -1.0, 0.0)), ((1.5, 0.0, 3.3), (0.0, -1.0, 0.0)), ((2.1,
    0.0, 0.3), (0.0, -1.0, 0.0)), ((1.95, 0.0, 3.3), (0.0, -1.0, 0.0)), ((1.65,
    0.0, 0.3), (0.0, -1.0, 0.0)), ((1.2, 0.0, 0.3), (0.0, -1.0, 0.0)), ((0.75,
    0.0, 0.3), (0.0, -1.0, 0.0)), ((0.3, 0.0, 0.3), (0.0, -1.0, 0.0)), ((2.4,
    0.0, 3.3), (0.0, -1.0, 0.0)), )), sectionName='Inner_steel_plate',
    thicknessAssignment=FROM_SECTION)
## Frame ##
mod.HomogeneousShellSection(idealization=NO_IDEALIZATION,
    integrationRule=SIMPSON, material='Steel_S355', name='Steel_frame', numIntPts=5,
    poissonDefinition=DEFAULT, preIntegrate=OFF, temperature=GRADIENT,
    thickness=0.003, thicknessField='', thicknessModulus=None, thicknessType=
    UNIFORM, useDensity=OFF)
mod.parts['Frame'].SectionAssignment(offset=0.0, offsetField=
    '', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['Frame'].faces.findAt(((0.0,
    0.048362, 0.074784), (-1.0, 0.0, 0.0)), ((0.0, 0.048362, 0.075216), (-1.0,
    0.0, 0.0)), ((0.0, 0.074784, 0.048362), (-1.0, 0.0, 0.0)), ((0.0, 0.074784,
    0.101638), (-1.0, 0.0, 0.0)), ((0.0, 0.075216, 0.048362), (-1.0, 0.0,
    0.0)), ((0.0, 0.075216, 0.101638), (-1.0, 0.0, 0.0)), ((0.0, 0.101638,
    0.074784), (-1.0, 0.0, 0.0)), ((0.0, 0.074784, 2.651638), (-1.0, 0.0,
    0.0)), ((0.0, 0.048362, 2.625216), (-1.0, 0.0, 0.0)), ((0.0, 0.100589,
    2.675589), (-1.0, 0.0, 0.0)), ((0.0, 0.024411, 2.599411), (-1.0, 0.0,
    0.0)), ((0.0, 0.101638, 2.625216), (-1.0, 0.0, 0.0)), ((0.0, 0.074784,
    2.598362), (-1.0, 0.0, 0.0)), ((0.0, 0.125589, 2.599411), (-1.0, 0.0,
    0.0)), ((0.15, 0.048362, 2.625216), (1.0, 0.0, 0.0)), ((0.15, 0.048362,
    2.624784), (1.0, 0.0, 0.0)), ((0.15, 0.074784, 2.651638), (1.0, 0.0, 0.0)),
    ((0.15, 0.074784, 2.598362), (1.0, 0.0, 0.0)), ((0.15, 0.075216, 2.651638),
    (1.0, 0.0, 0.0)), ((0.15, 0.075216, 2.598362), (1.0, 0.0, 0.0)), ((0.15,
    0.101638, 2.625216), (1.0, 0.0, 0.0)), ((0.15, 0.101638, 0.074784), (1.0,
    0.0, 0.0)), ((0.15, 0.075216, 0.048362), (1.0, 0.0, 0.0)), ((0.15,
    0.125589, 0.100589), (1.0, 0.0, 0.0)), ((0.15, 0.049411, 0.024411), (1.0,
    0.0, 0.0)), ((0.15, 0.075216, 0.101638), (1.0, 0.0, 0.0)), ((0.15,
    0.048362, 0.074784), (1.0, 0.0, 0.0)), ((0.15, 0.049411, 0.125589), (1.0,
    0.0, 0.0)), ((0.15, 0.1, 1.75), (1.0, 0.0, 0.0)), ((0.1, 0.0, 1.75), (0.0,
    -1.0, 0.0)), ((0.0, 0.05, 1.75), (-1.0, 0.0, 0.0)), ((0.15, 0.024411,
    0.100589), (1.0, 0.0, 0.0)), ((0.1, 0.0, 0.1), (0.0, -1.0, 0.0)), ((0.0,
    0.101638, 0.075216), (-1.0, 0.0, 0.0)), ((0.15, 0.101638, 2.624784), (1.0,
    0.0, 0.0)), ((0.0, 0.100589, 2.574411), (-1.0, 0.0, 0.0)), ((0.05, 0.0,
    2.6), (0.0, -1.0, 0.0)), )),
    sectionName='Steel_frame', thicknessAssignment=FROM_SECTION)
## Insulation ##
mod.HomogeneousSolidSection(material='PIR_PUR', name=
    'Insulation', thickness=None)
mod.parts['Insulation'].SectionAssignment(offset=0.0,
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    cells=mod.parts['Insulation'].cells.findAt(((2.7,
    0.053333, 2.4), ), )), sectionName='Insulation', thicknessAssignment=
    FROM_SECTION)
### ASSEMBLY Structure ###
## Create steel frame ##
# Create instance # frame #
modRa.DatumCsysByDefault(CARTESIAN)
modRa.Instance(dependent=ON, name='Frame-1', part=
    mod.parts['Frame'])
modRa.instances['Frame-1'].translate(vector=(
    2.7252, 0.0, 0.0))
# Positioning frame #
modRa.rotate(angle=90.0, axisDirection=(0.0, 0.15,
    0.0), axisPoint=(2.7252, 0.0, 0.0), instanceList=('Frame-1', ))
modRa.rotate(angle=180.0, axisDirection=(2.71,
    0.0, 0.0), axisPoint=(2.7252, 0.15, 0.0), instanceList=('Frame-1', ))
modRa.translate(instanceList=('Frame-1', ),
    vector=(-2.7252, -0.3, 0.0))
modRa.rotate(angle=90.0, axisDirection=(-2.7, 0.0,
    0.0), axisPoint=(2.7, -0.075, 0.15), instanceList=('Frame-1', ))
modRa.translate(instanceList=('Frame-1', ),
    vector=(0.0, 0.075, -0.075))
# Create instance # frame #
modRa.Instance(dependent=ON, name='Frame-2', part=
    mod.parts['Frame'])
modRa.instances['Frame-2'].translate(vector=(
    2.7252, 0.0, 0.0))
# Positioning frame #
modRa.rotate(angle=90.0, axisDirection=(0.0, 0.15,
    0.0), axisPoint=(2.7252, 0.0, 0.0), instanceList=('Frame-2', ))
modRa.rotate(angle=180.0, axisDirection=(2.71,
    0.0, 0.0), axisPoint=(2.7252, 0.15, 0.0), instanceList=('Frame-2', ))
modRa.translate(instanceList=('Frame-2', ),
    vector=(-2.7252, -0.3, 3.45))
modRa.rotate(angle=-90.0, axisDirection=(-2.7,
    0.0, 0.0), axisPoint=(2.7, -0.075, 3.6), instanceList=('Frame-2', ))
modRa.translate(instanceList=('Frame-2', ),
    vector=(0.0, -0.075, -0.075))
# Create inner plate #
modRa.Instance(dependent=ON, name='Inner_plate-1',
    part=mod.parts['Inner_plate'])
# Adjust Inner plate #
modRa.translate(instanceList=('Inner_plate-1', ),
    vector=(0.0, 0.002, 0.0))
# Create insulation, and adjust it #
modRa.Instance(dependent=ON, name='Insulation-1',
    part=mod.parts['Insulation'])
modRa.instances['Insulation-1'].translate(vector=(
    0, 0.0, 0.0))
modRa.translate(instanceList=('Insulation-1', ),
    vector=(0, 0.002, 0.0))
modRa.translate(instanceList=('Insulation-1', ),
    vector=(0.0, 0.0005, 0.0))
# Create outer plate #
modRa.Instance(dependent=ON, name='Outer_plate-1',
    part=mod.parts['Outer_plate'])
modRa.instances['Outer_plate-1'].translate(vector=
    (0, 0.0, 0.0))
modRa.translate(instanceList=('Outer_plate-1', ),
    vector=(0, 0.0825, 0.0))
modRa.translate(instanceList=('Outer_plate-1', ),
    vector=(0.0, 0.0005, 0.0))
### MESH ###
## Frame ##
mod.parts['Frame'].seedPart(deviationFactor=0.1,
    minSizeFactor=0.1, size=0.05)
# Parition for meshing #
mod.ConstrainedSketch(gridSpacing=0.12, name='__profile__',
    sheetSize=4.8, transform=
    mod.parts['Frame'].MakeSketchTransform(
    sketchPlane=mod.parts['Frame'].faces.findAt((0.15, 0.1,
    1.75), (1.0, 0.0, 0.0)), sketchPlaneSide=SIDE1,
    sketchUpEdge=mod.parts['Frame'].edges.findAt((0.15,
    0.0375, 0.0), ), sketchOrientation=RIGHT, origin=(0.15, 0.075, 1.35)))
mod.parts['Frame'].projectReferencesOntoSketch(filter=
    COPLANAR_EDGES, sketch=mod.sketches['__profile__'])
mod.sketches['__profile__'].Line(point1=(-1.2, 0.075),
    point2=(-1.35, -0.075))
mod.sketches['__profile__'].Line(point1=(-1.35, 0.075),
    point2=(-1.2, -0.075))
mod.sketches['__profile__'].Line(point1=(-1.35, 0.0), point2=
    (-1.2, 0.0))
mod.sketches['__profile__'].geometry.findAt((-1.3425, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((-1.3425,
    0.0), ))
mod.sketches['__profile__'].geometry.findAt((-1.35, 0.0675))
mod.sketches['__profile__'].geometry.findAt((-1.3425, 0.0))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((-1.35,
    0.0675), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((-1.3425,
    0.0), ))
mod.sketches['__profile__'].vertices.findAt((-1.35, 0.0))
mod.sketches['__profile__'].geometry.findAt((-1.35, 0.0675))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((-1.35, 0.0),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    -1.35, 0.0675), ))
mod.sketches['__profile__'].vertices.findAt((-1.35, 0.075))
mod.sketches['__profile__'].vertices.findAt((-1.35, -0.075))
mod.sketches['__profile__'].vertices.findAt((-1.35, 0.0))
mod.sketches['__profile__'].EqualDistanceConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((-1.35,
    0.075), ), entity2=
    mod.sketches['__profile__'].vertices.findAt((-1.35,
    -0.075), ), midpoint=
    mod.sketches['__profile__'].vertices.findAt((-1.35, 0.0),
    ))
mod.sketches['__profile__'].vertices.findAt((-1.2, 0.0))
mod.sketches['__profile__'].geometry.findAt((-1.2, -0.0675))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((-1.2, 0.0),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    -1.2, -0.0675), ))
mod.sketches['__profile__'].vertices.findAt((-1.2, 0.075))
mod.sketches['__profile__'].vertices.findAt((-1.2, -0.075))
mod.sketches['__profile__'].vertices.findAt((-1.2, 0.0))
mod.sketches['__profile__'].EqualDistanceConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((-1.2,
    0.075), ), entity2=
    mod.sketches['__profile__'].vertices.findAt((-1.2,
    -0.075), ), midpoint=
    mod.sketches['__profile__'].vertices.findAt((-1.2, 0.0),
    ))
mod.sketches['__profile__'].Line(point1=(-1.275, 0.075),
    point2=(-1.275, -0.0749999999767169))
mod.sketches['__profile__'].geometry.findAt((-1.275, 0.0675))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((-1.275,
    0.0675), ))
mod.sketches['__profile__'].geometry.findAt((-1.2075, 0.075))
mod.sketches['__profile__'].geometry.findAt((-1.275, 0.0675))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((-1.2075,
    0.075), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((-1.275,
    0.0675), ))
mod.sketches['__profile__'].vertices.findAt((-1.275, 0.075))
mod.sketches['__profile__'].geometry.findAt((-1.2075, 0.075))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((-1.275,
    0.075), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((-1.2075,
    0.075), ))
mod.sketches['__profile__'].vertices.findAt((-1.2, 0.075))
mod.sketches['__profile__'].vertices.findAt((-1.35, 0.075))
mod.sketches['__profile__'].vertices.findAt((-1.275, 0.075))
mod.sketches['__profile__'].EqualDistanceConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((-1.2,
    0.075), ), entity2=
    mod.sketches['__profile__'].vertices.findAt((-1.35,
    0.075), ), midpoint=
    mod.sketches['__profile__'].vertices.findAt((-1.275,
    0.075), ))
mod.sketches['__profile__'].vertices.findAt((-1.275, -0.075))
mod.sketches['__profile__'].geometry.findAt((-1.2075,
    -0.075))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((-1.275,
    -0.0749999999767169), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((-1.2075,
    -0.075), ))
mod.sketches['__profile__'].vertices.findAt((-1.35, -0.075))
mod.sketches['__profile__'].vertices.findAt((-1.2, -0.075))
mod.sketches['__profile__'].vertices.findAt((-1.275, -0.075))
mod.sketches['__profile__'].EqualDistanceConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((-1.35,
    -0.075), ), entity2=
    mod.sketches['__profile__'].vertices.findAt((-1.2,
    -0.075), ), midpoint=
    mod.sketches['__profile__'].vertices.findAt((-1.275,
    -0.0749999999767169), ))
mod.sketches['__profile__'].geometry.findAt((-1.274532,
    0.002456))
mod.sketches['__profile__'].geometry.findAt((-1.2165,
    0.0585))
mod.sketches['__profile__'].geometry.findAt((-1.3335,
    0.0585))
mod.sketches['__profile__'].geometry.findAt((-1.3335, 0.0))
mod.sketches['__profile__'].geometry.findAt((-1.275, 0.0585))
mod.sketches['__profile__'].copyMove(objectList=(
    mod.sketches['__profile__'].geometry.findAt((-1.274532,
    0.002456), ),
    mod.sketches['__profile__'].geometry.findAt((-1.2165,
    0.0585), ), mod.sketches['__profile__'].geometry.findAt((
    -1.3335, 0.0585), ),
    mod.sketches['__profile__'].geometry.findAt((-1.3335,
    0.0), ), mod.sketches['__profile__'].geometry.findAt((
    -1.275, 0.0585), )), vector=(2.55, 0.0))
mod.parts['Frame'].PartitionFaceBySketch(faces=
    mod.parts['Frame'].faces.findAt(((0.15, 0.1, 1.75), ), ((
    0.15, 0.100319, 0.101603), ), ((0.15, 0.100705, 2.59851), ), ), sketch=
    mod.sketches['__profile__'], sketchUpEdge=
    mod.parts['Frame'].edges.findAt((0.15, 0.0375, 0.0), ))
del mod.sketches['__profile__']
mod.ConstrainedSketch(gridSpacing=0.12, name='__profile__',
    sheetSize=5.11, transform=
    mod.parts['Frame'].MakeSketchTransform(
    sketchPlane=mod.parts['Frame'].faces.findAt((0.0,
    0.049681, 0.101603), (-1.0, 0.0, 0.0)), sketchPlaneSide=SIDE1,
    sketchUpEdge=mod.parts['Frame'].edges.findAt((0.0,
    0.0375, 2.7), ), sketchOrientation=RIGHT, origin=(0.0, 0.075, 0.075)))
mod.parts['Frame'].projectReferencesOntoSketch(filter=
    COPLANAR_EDGES, sketch=mod.sketches['__profile__'])
mod.sketches['__profile__'].Line(point1=(-0.075, 0.075),
    point2=(0.075, -0.075))
mod.sketches['__profile__'].Line(point1=(0.075, 0.075),
    point2=(-0.075, -0.075))
mod.sketches['__profile__'].Line(point1=(-0.075, 0.0),
    point2=(0.0749999999767169, 0.0))
mod.sketches['__profile__'].geometry.findAt((-0.0675, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((-0.0675,
    0.0), ))
mod.sketches['__profile__'].geometry.findAt((-0.075, 0.0675))
mod.sketches['__profile__'].geometry.findAt((-0.0675, 0.0))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((-0.075,
    0.0675), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((-0.0675,
    0.0), ))
mod.sketches['__profile__'].vertices.findAt((-0.075, 0.0))
mod.sketches['__profile__'].geometry.findAt((-0.075, 0.0675))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((-0.075,
    0.0), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((-0.075,
    0.0675), ))
mod.sketches['__profile__'].vertices.findAt((-0.075, 0.075))
mod.sketches['__profile__'].vertices.findAt((-0.075, -0.075))
mod.sketches['__profile__'].vertices.findAt((-0.075, 0.0))
mod.sketches['__profile__'].EqualDistanceConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((-0.075,
    0.075), ), entity2=
    mod.sketches['__profile__'].vertices.findAt((-0.075,
    -0.075), ), midpoint=
    mod.sketches['__profile__'].vertices.findAt((-0.075,
    0.0), ))
mod.sketches['__profile__'].vertices.findAt((0.075, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.075, -0.0675))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((
    0.0749999999767169, 0.0), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.075,
    -0.0675), ))
mod.sketches['__profile__'].vertices.findAt((0.075, 0.075))
mod.sketches['__profile__'].vertices.findAt((0.075, -0.075))
mod.sketches['__profile__'].vertices.findAt((0.075, 0.0))
mod.sketches['__profile__'].EqualDistanceConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.075,
    0.075), ), entity2=
    mod.sketches['__profile__'].vertices.findAt((0.075,
    -0.075), ), midpoint=
    mod.sketches['__profile__'].vertices.findAt((
    0.0749999999767169, 0.0), ))
mod.sketches['__profile__'].Line(point1=(0.0, 0.075), point2=
    (0.0, -0.0749999999767169))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.0675))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.0,
    0.0675), ))
mod.sketches['__profile__'].geometry.findAt((0.0675, 0.075))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.0675))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((0.0675,
    0.075), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.0,
    0.0675), ))
mod.sketches['__profile__'].vertices.findAt((0.0, 0.075))
mod.sketches['__profile__'].geometry.findAt((0.0675, 0.075))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.0, 0.075),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    0.0675, 0.075), ))
mod.sketches['__profile__'].vertices.findAt((0.075, 0.075))
mod.sketches['__profile__'].vertices.findAt((-0.075, 0.075))
mod.sketches['__profile__'].vertices.findAt((0.0, 0.075))
mod.sketches['__profile__'].EqualDistanceConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.075,
    0.075), ), entity2=
    mod.sketches['__profile__'].vertices.findAt((-0.075,
    0.075), ), midpoint=
    mod.sketches['__profile__'].vertices.findAt((0.0, 0.075),
    ))
mod.sketches['__profile__'].vertices.findAt((0.0, -0.075))
mod.sketches['__profile__'].geometry.findAt((-0.0675,
    -0.075))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.0,
    -0.0749999999767169), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((-0.0675,
    -0.075), ))
mod.sketches['__profile__'].vertices.findAt((0.075, -0.075))
mod.sketches['__profile__'].vertices.findAt((-0.075, -0.075))
mod.sketches['__profile__'].vertices.findAt((0.0, -0.075))
mod.sketches['__profile__'].EqualDistanceConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.075,
    -0.075), ), entity2=
    mod.sketches['__profile__'].vertices.findAt((-0.075,
    -0.075), ), midpoint=
    mod.sketches['__profile__'].vertices.findAt((0.0,
    -0.0749999999767169), ))
mod.sketches['__profile__'].geometry.findAt((0.000468,
    0.002456))
mod.sketches['__profile__'].geometry.findAt((-0.0585,
    0.0585))
mod.sketches['__profile__'].geometry.findAt((0.0585, 0.0585))
mod.sketches['__profile__'].geometry.findAt((-0.0585, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.0585))
mod.sketches['__profile__'].copyMove(objectList=(
    mod.sketches['__profile__'].geometry.findAt((0.000468,
    0.002456), ),
    mod.sketches['__profile__'].geometry.findAt((-0.0585,
    0.0585), ), mod.sketches['__profile__'].geometry.findAt((
    0.0585, 0.0585), ),
    mod.sketches['__profile__'].geometry.findAt((-0.0585,
    0.0), ), mod.sketches['__profile__'].geometry.findAt((
    0.0, 0.0585), )), vector=(2.55, 0.0))
mod.parts['Frame'].PartitionFaceBySketch(faces=
    mod.parts['Frame'].faces.findAt(((0.0, 0.049681,
    0.101603), ), ((0.0, 0.049295, 2.59851), ), ), sketch=
    mod.sketches['__profile__'], sketchUpEdge=
    mod.parts['Frame'].edges.findAt((0.0, 0.0375, 2.7), ))
del mod.sketches['__profile__']
mod.parts['Frame'].setMeshControls(elemShape=QUAD, regions=
    mod.parts['Frame'].faces.findAt(((0.0, 0.048362,
    0.074784), ), ((0.0, 0.048362, 0.075216), ), ((0.0, 0.074784, 0.048362), ),
    ((0.0, 0.074784, 0.101638), ), ((0.0, 0.075216, 0.048362), ), ((0.0,
    0.075216, 0.101638), ), ((0.0, 0.101638, 0.074784), ), ((0.0, 0.074784,
    2.651638), ), ((0.0, 0.048362, 2.625216), ), ((0.0, 0.100589, 2.675589), ),
    ((0.0, 0.024411, 2.599411), ), ((0.0, 0.101638, 2.625216), ), ((0.0,
    0.074784, 2.598362), ), ((0.0, 0.125589, 2.599411), ), ((0.15, 0.048362,
    2.625216), ), ((0.15, 0.048362, 2.624784), ), ((0.15, 0.074784, 2.651638),
    ), ((0.15, 0.074784, 2.598362), ), ((0.15, 0.075216, 2.651638), ), ((0.15,
    0.075216, 2.598362), ), ((0.15, 0.101638, 2.625216), ), ((0.15, 0.101638,
    0.074784), ), ((0.15, 0.075216, 0.048362), ), ((0.15, 0.125589, 0.100589),
    ), ((0.15, 0.049411, 0.024411), ), ((0.15, 0.075216, 0.101638), ), ((0.15,
    0.048362, 0.074784), ), ((0.15, 0.049411, 0.125589), ), ((0.15, 0.1, 1.75),
    ), ((0.1, 0.0, 1.75), ), ((0.0, 0.05, 1.75), ), ((0.15, 0.024411,
    0.100589), ), ((0.1, 0.0, 0.1), ), ((0.0, 0.101638, 0.075216), ), ((0.15,
    0.101638, 2.624784), ), ((0.0, 0.100589, 2.574411), ), ((0.05, 0.0, 2.6),
    ), ), technique=STRUCTURED)
mod.parts['Frame'].seedEdgeByBias(biasMethod=SINGLE,
    constraint=FINER, end1Edges=
    mod.parts['Frame'].edges.findAt(((0.0, 0.054375, 0.075),
    ), ((0.0, 0.054924, 0.054924), ), ((0.0, 0.054924, 0.095076), ), ((0.0,
    0.075, 0.095625), ), ((0.0, 0.075, 2.645625), ), ((0.0, 0.054924,
    2.645076), ), ((0.0, 0.054375, 2.625), ), ((0.0, 0.054924, 2.604924), ), ((
    0.15, 0.054375, 2.625), ), ((0.15, 0.054924, 2.645076), ), ((0.15,
    0.054924, 2.604924), ), ((0.15, 0.075, 2.604375), ), ((0.15, 0.075,
    0.054375), ), ((0.15, 0.054924, 0.054924), ), ((0.15, 0.054375, 0.075), ),
    ((0.15, 0.054924, 0.095076), ), ), end2Edges=
    mod.parts['Frame'].edges.findAt(((0.0, 0.075, 0.018125),
    ), ((0.0, 0.131692, 0.018308), ), ((0.0, 0.131692, 0.131692), ), ((0.0,
    0.131875, 0.075), ), ((0.0, 0.131692, 2.681692), ), ((0.0, 0.131875,
    2.625), ), ((0.0, 0.075, 2.568125), ), ((0.0, 0.131692, 2.568308), ), ((
    0.15, 0.075, 2.681875), ), ((0.15, 0.131692, 2.681692), ), ((0.15,
    0.131692, 2.568308), ), ((0.15, 0.131875, 2.625), ), ((0.15, 0.131875,
    0.075), ), ((0.15, 0.131692, 0.018308), ), ((0.15, 0.131692, 0.131692), ),
    ((0.15, 0.075, 0.131875), ), ), number=8, ratio=20.0)
mod.parts['Frame'].generateMesh()
## Panel ##
# partition for meshing #
mod.ConstrainedSketch(gridSpacing=0.11, name='__profile__',
    sheetSize=4.5, transform=
    mod.parts['Inner_plate'].MakeSketchTransform(
    sketchPlane=mod.parts['Inner_plate'].faces.findAt((
    0.050401, 0.0, 0.201599), (0.0, -1.0, 0.0)), sketchPlaneSide=SIDE1,
    sketchUpEdge=mod.parts['Inner_plate'].edges.findAt((
    2.3625, 0.0, 0.0), ), sketchOrientation=RIGHT, origin=(0.225015, 0.0,
    0.225015)))
mod.parts['Inner_plate'].projectReferencesOntoSketch(filter=
    COPLANAR_EDGES, sketch=mod.sketches['__profile__'])
mod.sketches['__profile__'].rectangle(point1=(0.225015,
    -0.225015), point2=(0.0666981493377685, -0.0629171883010864))
mod.sketches['__profile__'].vertices.findAt((0.150015,
    -0.150015))
mod.sketches['__profile__'].geometry.findAt((0.066698,
    -0.143966))
mod.sketches['__profile__'].DistanceDimension(entity1=
    mod.sketches['__profile__'].vertices.findAt((0.150015,
    -0.150015), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.066698,
    -0.143966), ), textPoint=(0.0870066141033173, -0.14056880821228), value=
    0.075)
mod.sketches['__profile__'].vertices.findAt((0.150015,
    -0.150015))
mod.sketches['__profile__'].geometry.findAt((0.150015,
    -0.062917))
mod.sketches['__profile__'].DistanceDimension(entity1=
    mod.sketches['__profile__'].vertices.findAt((0.150015,
    -0.150015), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.150015,
    -0.062917), ), textPoint=(0.132454187169075, -0.0742119406604767), value=
    0.075)
mod.sketches['__profile__'].Line(point1=(0.075015, -0.075015)
    , point2=(0.225015, -0.225015))
mod.sketches['__profile__'].Line(point1=(0.225015, -0.075015)
    , point2=(0.075015, -0.225015))
mod.sketches['__profile__'].Line(point1=(0.225015, -0.150015)
    , point2=(0.0750150000338257, -0.150015))
mod.sketches['__profile__'].geometry.findAt((0.217515,
    -0.150015))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.217515,
    -0.150015), ))
mod.sketches['__profile__'].geometry.findAt((0.225015,
    -0.082515))
mod.sketches['__profile__'].geometry.findAt((0.217515,
    -0.150015))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((0.225015,
    -0.082515), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.217515,
    -0.150015), ))
mod.sketches['__profile__'].vertices.findAt((0.225015,
    -0.150015))
mod.sketches['__profile__'].geometry.findAt((0.225015,
    -0.082515))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.225015,
    -0.150015), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.225015,
    -0.082515), ))
mod.sketches['__profile__'].vertices.findAt((0.225015,
    -0.225015))
mod.sketches['__profile__'].vertices.findAt((0.225015,
    -0.075015))
mod.sketches['__profile__'].vertices.findAt((0.225015,
    -0.150015))
mod.sketches['__profile__'].EqualDistanceConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.225015,
    -0.225015), ), entity2=
    mod.sketches['__profile__'].vertices.findAt((0.225015,
    -0.0750149999999998), ), midpoint=
    mod.sketches['__profile__'].vertices.findAt((0.225015,
    -0.150015), ))
mod.sketches['__profile__'].vertices.findAt((0.075015,
    -0.150015))
mod.sketches['__profile__'].geometry.findAt((0.075015,
    -0.082515))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((
    0.0750150000338257, -0.150015), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.075015,
    -0.082515), ))
mod.sketches['__profile__'].vertices.findAt((0.075015,
    -0.075015))
mod.sketches['__profile__'].vertices.findAt((0.075015,
    -0.225015))
mod.sketches['__profile__'].vertices.findAt((0.075015,
    -0.150015))
mod.sketches['__profile__'].EqualDistanceConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.075015,
    -0.0750149999999998), ), entity2=
    mod.sketches['__profile__'].vertices.findAt((0.075015,
    -0.225015), ), midpoint=
    mod.sketches['__profile__'].vertices.findAt((
    0.0750150000338257, -0.150015), ))
mod.sketches['__profile__'].Line(point1=(0.150015, -0.075015)
    , point2=(0.150015, -0.225014999987259))
mod.sketches['__profile__'].geometry.findAt((0.150015,
    -0.082515))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.150015,
    -0.082515), ))
mod.sketches['__profile__'].geometry.findAt((0.217515,
    -0.075015))
mod.sketches['__profile__'].geometry.findAt((0.150015,
    -0.082515))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((0.217515,
    -0.075015), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.150015,
    -0.082515), ))
mod.sketches['__profile__'].vertices.findAt((0.150015,
    -0.075015))
mod.sketches['__profile__'].geometry.findAt((0.217515,
    -0.075015))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.150015,
    -0.075015), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.217515,
    -0.075015), ))
mod.sketches['__profile__'].vertices.findAt((0.225015,
    -0.075015))
mod.sketches['__profile__'].vertices.findAt((0.075015,
    -0.075015))
mod.sketches['__profile__'].vertices.findAt((0.150015,
    -0.075015))
mod.sketches['__profile__'].EqualDistanceConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.225015,
    -0.0750149999999998), ), entity2=
    mod.sketches['__profile__'].vertices.findAt((0.075015,
    -0.0750149999999998), ), midpoint=
    mod.sketches['__profile__'].vertices.findAt((0.150015,
    -0.075015), ))
mod.sketches['__profile__'].vertices.findAt((0.150015,
    -0.225015))
mod.sketches['__profile__'].geometry.findAt((1.5e-05,
    -0.225015))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.150015,
    -0.225014999987259), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((1.5e-05,
    -0.225015), ))
mod.sketches['__profile__'].geometry.findAt((1.5e-05,
    -0.225015))
mod.sketches['__profile__'].geometry.findAt((0.225015,
    -1.5e-05))
mod.sketches['__profile__'].geometry.findAt((0.147559,
    -0.149547))
mod.sketches['__profile__'].geometry.findAt((0.225015,
    -0.076515))
mod.sketches['__profile__'].geometry.findAt((0.208515,
    -0.075015))
mod.sketches['__profile__'].geometry.findAt((0.075015,
    -0.091515))
mod.sketches['__profile__'].geometry.findAt((0.223515,
    -0.225015))
mod.sketches['__profile__'].geometry.findAt((0.091515,
    -0.091515))
mod.sketches['__profile__'].geometry.findAt((0.208515,
    -0.091515))
mod.sketches['__profile__'].geometry.findAt((0.208515,
    -0.150015))
mod.sketches['__profile__'].geometry.findAt((0.150015,
    -0.091515))
mod.sketches['__profile__'].copyMove(objectList=(
    mod.sketches['__profile__'].geometry.findAt((1.5e-05,
    -0.225015), ),
    mod.sketches['__profile__'].geometry.findAt((0.225015,
    -1.5e-05), ),
    mod.sketches['__profile__'].geometry.findAt((0.147559,
    -0.149547), ),
    mod.sketches['__profile__'].geometry.findAt((0.225015,
    -0.076515), ),
    mod.sketches['__profile__'].geometry.findAt((0.208515,
    -0.075015), ),
    mod.sketches['__profile__'].geometry.findAt((0.075015,
    -0.091515), ),
    mod.sketches['__profile__'].geometry.findAt((0.223515,
    -0.225015), ),
    mod.sketches['__profile__'].geometry.findAt((0.091515,
    -0.091515), ),
    mod.sketches['__profile__'].geometry.findAt((0.208515,
    -0.091515), ),
    mod.sketches['__profile__'].geometry.findAt((0.208515,
    -0.150015), ),
    mod.sketches['__profile__'].geometry.findAt((0.150015,
    -0.091515), )), vector=(0.0, 2.55))
mod.sketches['__profile__'].undo()
mod.sketches['__profile__'].geometry.findAt((0.147559,
    -0.149547))
mod.sketches['__profile__'].geometry.findAt((0.225015,
    -0.076515))
mod.sketches['__profile__'].geometry.findAt((0.208515,
    -0.075015))
mod.sketches['__profile__'].geometry.findAt((0.075015,
    -0.091515))
mod.sketches['__profile__'].geometry.findAt((0.223515,
    -0.225015))
mod.sketches['__profile__'].geometry.findAt((0.091515,
    -0.091515))
mod.sketches['__profile__'].geometry.findAt((0.208515,
    -0.091515))
mod.sketches['__profile__'].geometry.findAt((0.208515,
    -0.150015))
mod.sketches['__profile__'].geometry.findAt((0.150015,
    -0.091515))
mod.sketches['__profile__'].copyMove(objectList=(
    mod.sketches['__profile__'].geometry.findAt((0.147559,
    -0.149547), ),
    mod.sketches['__profile__'].geometry.findAt((0.225015,
    -0.076515), ),
    mod.sketches['__profile__'].geometry.findAt((0.208515,
    -0.075015), ),
    mod.sketches['__profile__'].geometry.findAt((0.075015,
    -0.091515), ),
    mod.sketches['__profile__'].geometry.findAt((0.223515,
    -0.225015), ),
    mod.sketches['__profile__'].geometry.findAt((0.091515,
    -0.091515), ),
    mod.sketches['__profile__'].geometry.findAt((0.208515,
    -0.091515), ),
    mod.sketches['__profile__'].geometry.findAt((0.208515,
    -0.150015), ),
    mod.sketches['__profile__'].geometry.findAt((0.150015,
    -0.091515), )), vector=(0.0, 2.55))
mod.sketches['__profile__'].geometry.findAt((0.149858,
    2.39749))
mod.sketches['__profile__'].geometry.findAt((0.150172,
    2.40248))
mod.sketches['__profile__'].geometry.findAt((0.225015,
    2.473485))
mod.sketches['__profile__'].geometry.findAt((0.076515,
    2.474985))
mod.sketches['__profile__'].geometry.findAt((0.075015,
    2.458485))
mod.sketches['__profile__'].geometry.findAt((0.091515,
    2.324985))
mod.sketches['__profile__'].geometry.findAt((0.091515,
    2.458485))
mod.sketches['__profile__'].geometry.findAt((0.208515,
    2.458485))
mod.sketches['__profile__'].geometry.findAt((0.208515,
    2.399985))
mod.sketches['__profile__'].geometry.findAt((0.150015,
    2.458485))
mod.sketches['__profile__'].copyMove(objectList=(
    mod.sketches['__profile__'].geometry.findAt((0.149858,
    2.39749), ), mod.sketches['__profile__'].geometry.findAt(
    (0.150172, 2.40248), ),
    mod.sketches['__profile__'].geometry.findAt((0.225015,
    2.473485), ),
    mod.sketches['__profile__'].geometry.findAt((0.076515,
    2.474985), ),
    mod.sketches['__profile__'].geometry.findAt((0.075015,
    2.458485), ),
    mod.sketches['__profile__'].geometry.findAt((0.091515,
    2.324985), ),
    mod.sketches['__profile__'].geometry.findAt((0.091515,
    2.458485), ),
    mod.sketches['__profile__'].geometry.findAt((0.208515,
    2.458485), ),
    mod.sketches['__profile__'].geometry.findAt((0.208515,
    2.399985), ),
    mod.sketches['__profile__'].geometry.findAt((0.150015,
    2.458485), )), vector=(-3.45, 0.0))
mod.sketches['__profile__'].geometry.findAt((-3.300142,
    2.39749))
mod.sketches['__profile__'].geometry.findAt((-3.299828,
    2.40248))
mod.sketches['__profile__'].geometry.findAt((-3.224985,
    2.341485))
mod.sketches['__profile__'].geometry.findAt((-3.373485,
    2.474985))
mod.sketches['__profile__'].geometry.findAt((-3.374985,
    2.326485))
mod.sketches['__profile__'].geometry.findAt((-3.358485,
    2.324985))
mod.sketches['__profile__'].geometry.findAt((-3.358485,
    2.458485))
mod.sketches['__profile__'].geometry.findAt((-3.241485,
    2.458485))
mod.sketches['__profile__'].geometry.findAt((-3.241485,
    2.399985))
mod.sketches['__profile__'].geometry.findAt((-3.299985,
    2.458485))
mod.sketches['__profile__'].copyMove(objectList=(
    mod.sketches['__profile__'].geometry.findAt((-3.300142,
    2.39749), ), mod.sketches['__profile__'].geometry.findAt(
    (-3.299828, 2.40248), ),
    mod.sketches['__profile__'].geometry.findAt((-3.224985,
    2.341485), ),
    mod.sketches['__profile__'].geometry.findAt((-3.373485,
    2.474985), ),
    mod.sketches['__profile__'].geometry.findAt((-3.374985,
    2.326485), ),
    mod.sketches['__profile__'].geometry.findAt((-3.358485,
    2.324985), ),
    mod.sketches['__profile__'].geometry.findAt((-3.358485,
    2.458485), ),
    mod.sketches['__profile__'].geometry.findAt((-3.241485,
    2.458485), ),
    mod.sketches['__profile__'].geometry.findAt((-3.241485,
    2.399985), ),
    mod.sketches['__profile__'].geometry.findAt((-3.299985,
    2.458485), )), vector=(0.0, -2.55))
mod.parts['Inner_plate'].PartitionFaceBySketch(faces=
    mod.parts['Inner_plate'].faces.findAt(((0.050401, 0.0,
    0.201599), ), ((2.649599, 0.0, 3.398401), ), ((2.498397, 0.0, 0.050319), ),
    ((0.201603, 0.0, 3.549681), ), ), sketch=
    mod.sketches['__profile__'], sketchUpEdge=
    mod.parts['Inner_plate'].edges.findAt((2.3625, 0.0, 0.0),
    ))
del mod.sketches['__profile__']
mod.parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mod.parts['Inner_plate'].faces.findAt(((2.45, 0.0,
    3.575), ), ((0.25, 0.0, 3.575), ), ((2.1, 0.0, 3.45), ), ((1.65, 0.0,
    3.45), ), ((1.2, 0.0, 3.45), ), ((0.75, 0.0, 3.45), ), ), point1=
    mod.parts['Inner_plate'].vertices.findAt((0.15, 0.0,
    3.45), ), point2=
    mod.parts['Inner_plate'].vertices.findAt((2.55, 0.0,
    3.45), ))
mod.parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mod.parts['Inner_plate'].faces.findAt(((2.35, 0.0, 3.35),
    ), ((2.45, 0.0, 3.475), ), ((2.4, 0.0, 2.85), ), ((2.4, 0.0, 2.4), ), ((
    2.4, 0.0, 1.95), ), ((2.4, 0.0, 1.5), ), ((2.4, 0.0, 1.05), ), ((2.4, 0.0,
    0.6), ), ((2.675, 0.0, 0.25), ), ), point1=
    mod.parts['Inner_plate'].vertices.findAt((2.55, 0.0,
    3.45), ), point2=
    mod.parts['Inner_plate'].vertices.findAt((2.55, 0.0,
    0.15), ))
mod.parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mod.parts['Inner_plate'].faces.findAt(((2.45, 0.0, 0.35),
    ), ((0.025, 0.0, 0.25), ), ((2.1, 0.0, 0.3), ), ((1.65, 0.0, 0.3), ), ((
    1.2, 0.0, 0.3), ), ((0.75, 0.0, 0.3), ), ), point1=
    mod.parts['Inner_plate'].vertices.findAt((2.55, 0.0,
    0.15), ), point2=
    mod.parts['Inner_plate'].vertices.findAt((0.15, 0.0,
    0.15), ))
mod.parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mod.parts['Inner_plate'].faces.findAt(((0.35, 0.0, 0.25),
    ), ((0.35, 0.0, 3.35), ), ((0.3, 0.0, 0.75), ), ((0.3, 0.0, 1.2), ), ((0.3,
    0.0, 1.65), ), ((0.3, 0.0, 2.1), ), ((0.3, 0.0, 2.55), ), ((0.3, 0.0, 3.0),
    ), ), point1=mod.parts['Inner_plate'].vertices.findAt((
    0.15, 0.0, 0.15), ), point2=
    mod.parts['Inner_plate'].vertices.findAt((0.15, 0.0,
    3.45), ))
## Inner plate ##
mod.parts['Inner_plate'].seedPart(deviationFactor=0.1,
    minSizeFactor=0.1, size=0.05)
mod.parts['Inner_plate'].setMeshControls(elemShape=QUAD,
    regions=mod.parts['Inner_plate'].faces.findAt(((0.125,
    0.0, 0.25), ), ((0.1, 0.0, 0.75), ), ((0.1, 0.0, 1.2), ), ((0.1, 0.0,
    1.65), ), ((0.1, 0.0, 2.1), ), ((0.1, 0.0, 2.55), ), ((0.1, 0.0, 3.0), ), (
    (0.125, 0.0, 3.35), ), ((2.45, 0.0, 0.125), ), ((2.1, 0.0, 0.1), ), ((1.65,
    0.0, 0.1), ), ((1.2, 0.0, 0.1), ), ((0.75, 0.0, 0.1), ), ((0.25, 0.0,
    0.125), ), ((2.35, 0.0, 0.25), ), ((2.45, 0.0, 0.75), ), ((2.45, 0.0, 1.2),
    ), ((2.45, 0.0, 1.65), ), ((2.45, 0.0, 2.1), ), ((2.45, 0.0, 2.55), ), ((
    2.45, 0.0, 3.0), ), ((2.575, 0.0, 3.35), ), ((2.45, 0.0, 3.35), ), ((2.1,
    0.0, 3.35), ), ((1.65, 0.0, 3.35), ), ((1.2, 0.0, 3.35), ), ((0.75, 0.0,
    3.35), ), ((0.25, 0.0, 3.475), ), ((2.624784, 0.0, 3.498362), ), ((
    2.598362, 0.0, 3.524784), ), ((2.45, 0.0, 3.475), ), ((2.650589, 0.0,
    3.474411), ), ((2.574411, 0.0, 3.550589), ), ((2.651638, 0.0, 3.524784), ),
    ((2.624784, 0.0, 3.551638), ), ((2.675589, 0.0, 3.550589), ), ((0.048362,
    0.0, 0.074784), ), ((0.074784, 0.0, 0.048362), ), ((0.024411, 0.0,
    0.100589), ), ((0.100589, 0.0, 0.024411), ), ((0.074784, 0.0, 0.101638), ),
    ((0.25, 0.0, 0.25), ), ((0.101638, 0.0, 0.074784), ), ((0.100589, 0.0,
    0.125589), ), ((2.650589, 0.0, 0.024411), ), ((2.651638, 0.0, 0.074784), ),
    ((2.624784, 0.0, 0.048362), ), ((2.675589, 0.0, 0.100589), ), ((2.624784,
    0.0, 0.101638), ), ((2.574411, 0.0, 0.100589), ), ((2.598362, 0.0,
    0.074784), ), ((2.650589, 0.0, 0.125589), ), ((0.048362, 0.0, 3.524784), ),
    ((0.074784, 0.0, 3.498362), ), ((0.100589, 0.0, 3.474411), ), ((0.024411,
    0.0, 3.550589), ), ((0.25, 0.0, 3.25), ), ((0.101638, 0.0, 3.524784), ), ((
    0.074784, 0.0, 3.551638), ), ((0.125589, 0.0, 3.550589), ), ((1.95, 0.0,
    0.25), ), ((2.1, 0.0, 0.75), ), ((2.1, 0.0, 1.2), ), ((2.1, 0.0, 1.65), ),
    ((2.1, 0.0, 2.1), ), ((2.1, 0.0, 2.55), ), ((2.1, 0.0, 3.0), ), ((1.95,
    0.0, 3.5), ), ((1.5, 0.0, 0.25), ), ((1.65, 0.0, 0.75), ), ((1.65, 0.0,
    1.2), ), ((1.65, 0.0, 1.65), ), ((1.65, 0.0, 2.1), ), ((1.65, 0.0, 2.55),
    ), ((1.65, 0.0, 3.0), ), ((1.5, 0.0, 3.5), ), ((1.05, 0.0, 0.25), ), ((1.2,
    0.0, 0.75), ), ((1.2, 0.0, 1.2), ), ((1.2, 0.0, 1.65), ), ((1.2, 0.0, 2.1),
    ), ((1.2, 0.0, 2.55), ), ((1.2, 0.0, 3.0), ), ((1.05, 0.0, 3.5), ), ((0.6,
    0.0, 0.25), ), ((0.75, 0.0, 0.75), ), ((0.75, 0.0, 1.2), ), ((0.75, 0.0,
    1.65), ), ((0.75, 0.0, 2.1), ), ((0.75, 0.0, 2.55), ), ((0.75, 0.0, 3.0),
    ), ((0.6, 0.0, 3.5), ), ((0.125589, 0.0, 0.100589), ), ((0.25, 0.0, 0.6),
    ), ((0.25, 0.0, 1.05), ), ((0.25, 0.0, 1.5), ), ((0.25, 0.0, 1.95), ), ((
    0.25, 0.0, 2.4), ), ((2.650589, 0.0, 3.575589), ), ((0.25, 0.0, 2.85), ), (
    (2.6, 0.0, 2.85), ), ((2.6, 0.0, 2.4), ), ((2.6, 0.0, 1.95), ), ((2.6, 0.0,
    1.5), ), ((2.6, 0.0, 1.05), ), ((2.6, 0.0, 0.6), ), ((2.575, 0.0, 0.25), ),
    ((0.100589, 0.0, 3.575589), ), ), technique=STRUCTURED)
mod.parts['Inner_plate'].seedEdgeByBias(biasMethod=SINGLE,
    constraint=FINER, end1Edges=
    mod.parts['Inner_plate'].edges.findAt(((2.604924, 0.0,
    3.504924), ), ((2.604375, 0.0, 3.525), ), ((2.604924, 0.0, 3.545076), ), ((
    2.625, 0.0, 3.545625), ), ((0.054375, 0.0, 0.075), ), ((0.054924, 0.0,
    0.054924), ), ((0.054924, 0.0, 0.095076), ), ((0.075, 0.0, 0.095625), ), ((
    2.604924, 0.0, 0.054924), ), ((2.625, 0.0, 0.095625), ), ((2.604924, 0.0,
    0.095076), ), ((2.604375, 0.0, 0.075), ), ((0.054375, 0.0, 3.525), ), ((
    0.054924, 0.0, 3.504924), ), ((0.054924, 0.0, 3.545076), ), ((0.075, 0.0,
    3.545625), ), ), end2Edges=
    mod.parts['Inner_plate'].edges.findAt(((2.625, 0.0,
    3.468125), ), ((2.681692, 0.0, 3.468308), ), ((2.681875, 0.0, 3.525), ), ((
    2.681692, 0.0, 3.581692), ), ((0.075, 0.0, 0.018125), ), ((0.131692, 0.0,
    0.018308), ), ((0.131875, 0.0, 0.075), ), ((0.131692, 0.0, 0.131692), ), ((
    2.681692, 0.0, 0.018308), ), ((2.625, 0.0, 0.018125), ), ((2.681875, 0.0,
    0.075), ), ((2.681692, 0.0, 0.131692), ), ((0.075, 0.0, 3.468125), ), ((
    0.131692, 0.0, 3.468308), ), ((0.131875, 0.0, 3.525), ), ((0.131692, 0.0,
    3.581692), ), ), number=8, ratio=20)
mod.parts['Inner_plate'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Inner_plate'].edges.findAt(((2.55, 0.0,
    0.01875), ), ((2.55, 0.0, 0.09375), ), ((0.15, 0.0, 0.05625), ), ((0.15,
    0.0, 0.13125), ), ((0.15, 0.0, 3.58125), ), ((2.55, 0.0, 3.54375), ), ), number=2)
mod.parts['Inner_plate'].generateMesh()
## Outer plate ##
mod.parts['Outer_plate'].seedPart(deviationFactor=0.1,
    minSizeFactor=0.1, size=0.05)
mod.parts['Outer_plate'].generateMesh()
## Insulation ##
mod.parts['Insulation'].seedPart(deviationFactor=0.1,
    minSizeFactor=0.1, size=0.1)
mod.parts['Insulation'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Insulation'].edges.findAt(((0.0, 0.02,
    3.6), ), ((0.0, 0.02, 0.0), ), ((2.7, 0.06, 3.6), ), ((2.7, 0.06, 0.0), ),
    ), number=4)
mod.parts['Insulation'].generateMesh()
# Set mesh type #
mod.parts['Frame'].setElementType(elemTypes=(ElemType(
    elemCode=DS4, elemLibrary=STANDARD), ElemType(elemCode=DS3,
    elemLibrary=STANDARD)), regions=(
    mod.parts['Frame'].faces.findAt(((0.0, 0.048362,
    0.074784), ), ((0.0, 0.048362, 0.075216), ), ((0.0, 0.074784, 0.048362), ),
    ((0.0, 0.074784, 0.101638), ), ((0.0, 0.075216, 0.048362), ), ((0.0,
    0.075216, 0.101638), ), ((0.0, 0.101638, 0.074784), ), ((0.0, 0.074784,
    2.651638), ), ((0.0, 0.048362, 2.625216), ), ((0.0, 0.100589, 2.675589), ),
    ((0.0, 0.024411, 2.599411), ), ((0.0, 0.101638, 2.625216), ), ((0.0,
    0.074784, 2.598362), ), ((0.0, 0.125589, 2.599411), ), ((0.15, 0.048362,
    2.625216), ), ((0.15, 0.048362, 2.624784), ), ((0.15, 0.074784, 2.651638),
    ), ((0.15, 0.074784, 2.598362), ), ((0.15, 0.075216, 2.651638), ), ((0.15,
    0.075216, 2.598362), ), ((0.15, 0.101638, 2.625216), ), ((0.15, 0.101638,
    0.074784), ), ((0.15, 0.075216, 0.048362), ), ((0.15, 0.125589, 0.100589),
    ), ((0.15, 0.049411, 0.024411), ), ((0.15, 0.075216, 0.101638), ), ((0.15,
    0.048362, 0.074784), ), ((0.15, 0.049411, 0.125589), ), ((0.15, 0.1, 1.75),
    ), ((0.1, 0.0, 1.75), ), ((0.0, 0.05, 1.75), ), ((0.15, 0.024411,
    0.100589), ), ((0.1, 0.0, 0.1), ), ((0.0, 0.101638, 0.075216), ), ((0.15,
    0.101638, 2.624784), ), ((0.0, 0.100589, 2.574411), ), ((0.05, 0.0, 2.6),
    ), ), ))
mod.parts['Inner_plate'].setElementType(elemTypes=(ElemType(
    elemCode=DS4, elemLibrary=STANDARD), ElemType(elemCode=DS3,
    elemLibrary=STANDARD)), regions=(
    mod.parts['Inner_plate'].faces.findAt(((0.125, 0.0,
    0.25), ), ((0.1, 0.0, 0.75), ), ((0.1, 0.0, 1.2), ), ((0.1, 0.0, 1.65), ),
    ((0.1, 0.0, 2.1), ), ((0.1, 0.0, 2.55), ), ((0.1, 0.0, 3.0), ), ((0.125,
    0.0, 3.35), ), ((2.45, 0.0, 0.125), ), ((2.1, 0.0, 0.1), ), ((1.65, 0.0,
    0.1), ), ((1.2, 0.0, 0.1), ), ((0.75, 0.0, 0.1), ), ((0.25, 0.0, 0.125), ),
    ((2.35, 0.0, 0.25), ), ((2.45, 0.0, 0.75), ), ((2.45, 0.0, 1.2), ), ((2.45,
    0.0, 1.65), ), ((2.45, 0.0, 2.1), ), ((2.45, 0.0, 2.55), ), ((2.45, 0.0,
    3.0), ), ((2.575, 0.0, 3.35), ), ((2.45, 0.0, 3.35), ), ((2.1, 0.0, 3.35),
    ), ((1.65, 0.0, 3.35), ), ((1.2, 0.0, 3.35), ), ((0.75, 0.0, 3.35), ), ((
    0.25, 0.0, 3.475), ), ((2.624784, 0.0, 3.498362), ), ((2.598362, 0.0,
    3.524784), ), ((2.45, 0.0, 3.475), ), ((2.650589, 0.0, 3.474411), ), ((
    2.574411, 0.0, 3.550589), ), ((2.651638, 0.0, 3.524784), ), ((2.624784,
    0.0, 3.551638), ), ((2.675589, 0.0, 3.550589), ), ((0.048362, 0.0,
    0.074784), ), ((0.074784, 0.0, 0.048362), ), ((0.024411, 0.0, 0.100589), ),
    ((0.100589, 0.0, 0.024411), ), ((0.074784, 0.0, 0.101638), ), ((0.25, 0.0,
    0.25), ), ((0.101638, 0.0, 0.074784), ), ((0.100589, 0.0, 0.125589), ), ((
    2.650589, 0.0, 0.024411), ), ((2.651638, 0.0, 0.074784), ), ((2.624784,
    0.0, 0.048362), ), ((2.675589, 0.0, 0.100589), ), ((2.624784, 0.0,
    0.101638), ), ((2.574411, 0.0, 0.100589), ), ((2.598362, 0.0, 0.074784), ),
    ((2.650589, 0.0, 0.125589), ), ((0.048362, 0.0, 3.524784), ), ((0.074784,
    0.0, 3.498362), ), ((0.100589, 0.0, 3.474411), ), ((0.024411, 0.0,
    3.550589), ), ((0.25, 0.0, 3.25), ), ((0.101638, 0.0, 3.524784), ), ((
    0.074784, 0.0, 3.551638), ), ((0.125589, 0.0, 3.550589), ), ((2.6, 0.0,
    2.85), ), ((2.1, 0.0, 3.0), ), ((1.65, 0.0, 3.0), ), ((1.2, 0.0, 3.0), ), (
    (0.75, 0.0, 3.0), ), ((0.25, 0.0, 2.85), ), ((2.6, 0.0, 2.4), ), ((2.1,
    0.0, 2.55), ), ((1.65, 0.0, 2.55), ), ((1.2, 0.0, 2.55), ), ((0.75, 0.0,
    2.55), ), ((0.25, 0.0, 2.4), ), ((2.6, 0.0, 1.95), ), ((2.1, 0.0, 2.1), ),
    ((1.65, 0.0, 2.1), ), ((1.2, 0.0, 2.1), ), ((0.75, 0.0, 2.1), ), ((0.25,
    0.0, 1.95), ), ((2.6, 0.0, 1.5), ), ((2.1, 0.0, 1.65), ), ((1.65, 0.0,
    1.65), ), ((1.2, 0.0, 1.65), ), ((0.75, 0.0, 1.65), ), ((0.25, 0.0, 1.5),
    ), ((2.6, 0.0, 1.05), ), ((2.1, 0.0, 1.2), ), ((1.65, 0.0, 1.2), ), ((1.2,
    0.0, 1.2), ), ((0.75, 0.0, 1.2), ), ((0.25, 0.0, 1.05), ), ((2.6, 0.0,
    0.6), ), ((2.1, 0.0, 0.75), ), ((1.65, 0.0, 0.75), ), ((1.2, 0.0, 0.75), ),
    ((0.75, 0.0, 0.75), ), ((0.25, 0.0, 0.6), ), ((0.100589, 0.0, 3.575589), ),
    ((0.6, 0.0, 3.5), ), ((1.05, 0.0, 3.5), ), ((2.575, 0.0, 0.25), ), ((1.5,
    0.0, 3.5), ), ((1.95, 0.0, 0.25), ), ((1.95, 0.0, 3.5), ), ((1.5, 0.0,
    0.25), ), ((1.05, 0.0, 0.25), ), ((0.6, 0.0, 0.25), ), ((0.125589, 0.0,
    0.100589), ), ((2.650589, 0.0, 3.575589), ), ), ))
mod.parts['Insulation'].setElementType(elemTypes=(ElemType(
    elemCode=DC3D8, elemLibrary=STANDARD), ElemType(elemCode=DC3D6,
    elemLibrary=STANDARD), ElemType(elemCode=DC3D4, elemLibrary=STANDARD)),
    regions=(mod.parts['Insulation'].cells.findAt(((2.7,
    0.053333, 2.4), )), ))
mod.parts['Outer_plate'].setElementType(elemTypes=(ElemType(
    elemCode=S4R, elemLibrary=STANDARD, secondOrderAccuracy=OFF,
    hourglassControl=DEFAULT), ElemType(elemCode=S3, elemLibrary=STANDARD)),
    regions=(mod.parts['Outer_plate'].faces.findAt(((2.55,
    0.0, 3.0), ), ((2.1, 0.0, 3.0), ), ((1.65, 0.0, 3.0), ), ((1.2, 0.0, 3.0),
    ), ((0.75, 0.0, 3.0), ), ((0.3, 0.0, 3.0), ), ((2.55, 0.0, 2.55), ), ((2.1,
    0.0, 2.55), ), ((1.65, 0.0, 2.55), ), ((1.2, 0.0, 2.55), ), ((0.75, 0.0,
    2.55), ), ((0.3, 0.0, 2.55), ), ((2.55, 0.0, 2.1), ), ((2.1, 0.0, 2.1), ),
    ((1.65, 0.0, 2.1), ), ((1.2, 0.0, 2.1), ), ((0.75, 0.0, 2.1), ), ((0.3,
    0.0, 2.1), ), ((2.55, 0.0, 1.65), ), ((2.1, 0.0, 1.65), ), ((1.65, 0.0,
    1.65), ), ((1.2, 0.0, 1.65), ), ((0.75, 0.0, 1.65), ), ((0.3, 0.0, 1.65),
    ), ((2.55, 0.0, 1.2), ), ((2.1, 0.0, 1.2), ), ((1.65, 0.0, 1.2), ), ((1.2,
    0.0, 1.2), ), ((0.75, 0.0, 1.2), ), ((0.3, 0.0, 1.2), ), ((2.55, 0.0,
    0.75), ), ((2.1, 0.0, 0.75), ), ((1.65, 0.0, 0.75), ), ((1.2, 0.0, 0.75),
    ), ((0.75, 0.0, 0.75), ), ((0.3, 0.0, 0.75), ), ((0.15, 0.0, 3.3), ), ((
    0.6, 0.0, 3.3), ), ((1.05, 0.0, 3.3), ), ((2.55, 0.0, 0.3), ), ((1.5, 0.0,
    3.3), ), ((2.1, 0.0, 0.3), ), ((1.95, 0.0, 3.3), ), ((1.65, 0.0, 0.3), ), (
    (1.2, 0.0, 0.3), ), ((0.75, 0.0, 0.3), ), ((0.3, 0.0, 0.3), ), ((2.4, 0.0,
    3.3), ), ), ))
mod.parts['Outer_plate'].setElementType(elemTypes=(ElemType(
    elemCode=DS4, elemLibrary=STANDARD), ElemType(elemCode=DS3,
    elemLibrary=STANDARD)), regions=(
    mod.parts['Outer_plate'].faces.findAt(((2.55, 0.0, 3.0),
    ), ((2.1, 0.0, 3.0), ), ((1.65, 0.0, 3.0), ), ((1.2, 0.0, 3.0), ), ((0.75,
    0.0, 3.0), ), ((0.3, 0.0, 3.0), ), ((2.55, 0.0, 2.55), ), ((2.1, 0.0,
    2.55), ), ((1.65, 0.0, 2.55), ), ((1.2, 0.0, 2.55), ), ((0.75, 0.0, 2.55),
    ), ((0.3, 0.0, 2.55), ), ((2.55, 0.0, 2.1), ), ((2.1, 0.0, 2.1), ), ((1.65,
    0.0, 2.1), ), ((1.2, 0.0, 2.1), ), ((0.75, 0.0, 2.1), ), ((0.3, 0.0, 2.1),
    ), ((2.55, 0.0, 1.65), ), ((2.1, 0.0, 1.65), ), ((1.65, 0.0, 1.65), ), ((
    1.2, 0.0, 1.65), ), ((0.75, 0.0, 1.65), ), ((0.3, 0.0, 1.65), ), ((2.55,
    0.0, 1.2), ), ((2.1, 0.0, 1.2), ), ((1.65, 0.0, 1.2), ), ((1.2, 0.0, 1.2),
    ), ((0.75, 0.0, 1.2), ), ((0.3, 0.0, 1.2), ), ((2.55, 0.0, 0.75), ), ((2.1,
    0.0, 0.75), ), ((1.65, 0.0, 0.75), ), ((1.2, 0.0, 0.75), ), ((0.75, 0.0,
    0.75), ), ((0.3, 0.0, 0.75), ), ((0.15, 0.0, 3.3), ), ((0.6, 0.0, 3.3), ),
    ((1.05, 0.0, 3.3), ), ((2.55, 0.0, 0.3), ), ((1.5, 0.0, 3.3), ), ((2.1,
    0.0, 0.3), ), ((1.95, 0.0, 3.3), ), ((1.65, 0.0, 0.3), ), ((1.2, 0.0, 0.3),
    ), ((0.75, 0.0, 0.3), ), ((0.3, 0.0, 0.3), ), ((2.4, 0.0, 3.3), ), ), ))
### REGENERATE ASSEMBLY ###
modRa.regenerate()
# Node set all #
modRa.Set(name='Nall', nodes=
    modRa.instances['Frame-1'].nodes[0:772]+\
    modRa.instances['Frame-2'].nodes[0:772]+\
    modRa.instances['Inner_plate-1'].nodes[0:4643]+\
    modRa.instances['Insulation-1'].nodes[0:5180]+\
    modRa.instances['Outer_plate-1'].nodes[0:4015])
# Name the surface #
PartInnerPlate=mod.parts['Inner_plate']
nameSideFaces=mod.parts['Inner_plate'].faces
# initial surface matrix
surface_number=1
surfrow = 1
surfcolumn = 1
# name the first row
for surfrow in range(1, 7):
    for surfcolumn in range(1, 9):
        y_ordinate = 3.75 - 0.45 * surfcolumn
        x_ordinate = 2.85 - 0.45 * surfrow
        surfcolumn = surfcolumn + 1
        PartInnerPlate.Surface(name='Surf-%s'%surface_number,
                               side1Faces=nameSideFaces.findAt(((x_ordinate, 0.0, y_ordinate),)))
        surface_number = surface_number + 1
    surfrow = surfrow + 1
# Correct name for some surface #
mod.parts['Inner_plate'].Surface(name='Surf-1', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((2.575, 0.0,
    3.35), ), ((2.45, 0.0, 3.35), ), ((2.624784, 0.0, 3.498362), ), ((2.598362,
    0.0, 3.524784), ), ((2.45, 0.0, 3.475), ), ((2.650589, 0.0, 3.474411), ), (
    (2.574411, 0.0, 3.550589), ), ((2.651638, 0.0, 3.524784), ), ((2.624784,
    0.0, 3.551638), ), ((2.675589, 0.0, 3.550589), ), ((2.650589, 0.0,
    3.575589), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-2', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((2.45, 0.0, 3.0),
    ), ((2.6, 0.0, 2.85), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-3', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((2.45, 0.0, 2.55),
    ), ((2.6, 0.0, 2.4), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-4', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((2.45, 0.0, 2.1),
    ), ((2.6, 0.0, 1.95), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-5', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((2.45, 0.0, 1.65),
    ), ((2.6, 0.0, 1.5), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-6', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((2.45, 0.0, 1.2),
    ), ((2.6, 0.0, 1.05), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-7', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((2.45, 0.0, 0.75),
    ), ((2.6, 0.0, 0.6), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-8', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((2.45, 0.0,
    0.125), ), ((2.35, 0.0, 0.25), ), ((2.650589, 0.0, 0.024411), ), ((
    2.651638, 0.0, 0.074784), ), ((2.624784, 0.0, 0.048362), ), ((2.675589,
    0.0, 0.100589), ), ((2.624784, 0.0, 0.101638), ), ((2.574411, 0.0,
    0.100589), ), ((2.598362, 0.0, 0.074784), ), ((2.650589, 0.0, 0.125589), ),
    ((2.575, 0.0, 0.25), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-9', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((2.1, 0.0, 3.35),
    ), ((1.95, 0.0, 3.5), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-16', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((2.1, 0.0, 0.1),
    ), ((1.95, 0.0, 0.25), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-17', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((1.65, 0.0, 3.35),
    ), ((1.5, 0.0, 3.5), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-24', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((1.65, 0.0, 0.1),
    ), ((1.5, 0.0, 0.25), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-25', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((1.2, 0.0, 3.35),
    ), ((1.05, 0.0, 3.5), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-32', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((1.2, 0.0, 0.1),
    ), ((1.05, 0.0, 0.25), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-33', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.75, 0.0, 3.35),
    ), ((0.6, 0.0, 3.5), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-40', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.75, 0.0, 0.1),
    ), ((0.6, 0.0, 0.25), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-41', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.125, 0.0,
    3.35), ), ((0.25, 0.0, 3.475), ), ((0.048362, 0.0, 3.524784), ), ((
    0.074784, 0.0, 3.498362), ), ((0.100589, 0.0, 3.474411), ), ((0.024411,
    0.0, 3.550589), ), ((0.25, 0.0, 3.25), ), ((0.101638, 0.0, 3.524784), ), ((
    0.074784, 0.0, 3.551638), ), ((0.125589, 0.0, 3.550589), ), ((0.100589,
    0.0, 3.575589), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-42', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.1, 0.0, 3.0),
    ), ((0.25, 0.0, 2.85), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-43', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.1, 0.0, 2.55),
    ), ((0.25, 0.0, 2.4), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-44', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.1, 0.0, 2.1),
    ), ((0.25, 0.0, 1.95), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-45', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.1, 0.0, 1.65),
    ), ((0.25, 0.0, 1.5), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-46', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.1, 0.0, 1.2),
    ), ((0.25, 0.0, 1.05), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-47', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.1, 0.0, 0.75),
    ), ((0.25, 0.0, 0.6), ), ))
mod.parts['Inner_plate'].Surface(name='Surf-48', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.125, 0.0,
    0.25), ), ((0.25, 0.0, 0.125), ), ((0.048362, 0.0, 0.074784), ), ((
    0.074784, 0.0, 0.048362), ), ((0.024411, 0.0, 0.100589), ), ((0.100589,
    0.0, 0.024411), ), ((0.074784, 0.0, 0.101638), ), ((0.25, 0.0, 0.25), ), ((
    0.101638, 0.0, 0.074784), ), ((0.100589, 0.0, 0.125589), ), ((0.125589,
    0.0, 0.100589), ), ))
### CREATE CONVECTION BETWEEN SURFACES ###
mod.ContactProperty('Conductance')
mod.interactionProperties['Conductance'].ThermalConductance(
    clearanceDepTable=((100000.0, 0.0), (0.0, 0.015)), clearanceDependency=ON,
    definition=TABULAR, dependenciesC=0, massFlowRateDependencyC=OFF,
    pressureDependency=OFF, temperatureDependencyC=OFF)
# Defined here for Field Output Request and Model Change Interaction
modRa.Set(edges=
    modRa.instances['Frame-1'].edges.findAt(((0.0,
    -0.15, 0.05625), ), ((0.0, -0.15, 0.13125), ), ((0.0, 0.0, 0.09375), ), ((
    0.0, 0.0, 0.01875), ), ((0.0, -0.1125, 0.0), ), )+\
    modRa.instances['Frame-2'].edges.findAt(((0.0,
    0.0, 3.54375), ), ((0.0, 0.0, 3.46875), ), ((0.0, -0.15, 3.50625), ), ((
    0.0, -0.15, 3.58125), ), ((0.0, -0.0375, 3.6), ), ), name='Column_bottom',
    vertices=
    modRa.instances['Frame-1'].vertices.findAt(((
    0.0, -0.15, 0.0), ), ((0.0, -0.15, 0.075), ), ((0.0, -0.15, 0.15), ), ((
    0.0, 0.0, 0.15), ), ((0.0, 0.0, 0.075), ), ((0.0, 0.0, 0.0), ), )+\
    modRa.instances['Frame-2'].vertices.findAt(((
    0.0, 0.0, 3.6), ), ((0.0, 0.0, 3.525), ), ((0.0, 0.0, 3.45), ), ((0.0,
    -0.15, 3.45), ), ((0.0, -0.15, 3.525), ), ((0.0, -0.15, 3.6), ), ))
mod.DisplacementBC(amplitude=UNSET, createStepName='Initial',
    distributionType=UNIFORM, fieldName='', localCsys=None, name=
    'Column_bottom', region=
    modRa.sets['Column_bottom'], u1=SET, u2=SET,
    u3=SET, ur1=UNSET, ur2=UNSET, ur3=UNSET)
modRa.Set(edges=
    modRa.instances['Frame-1'].edges.findAt(((2.7,
    -0.15, 0.01875), ), ((2.7, -0.15, 0.09375), ), ((2.7, 0.0, 0.05625), ), ((
    2.7, 0.0, 0.13125), ), ((2.7, -0.0375, 0.0), ), )+\
    modRa.instances['Frame-2'].edges.findAt(((2.7,
    0.0, 3.58125), ), ((2.7, 0.0, 3.50625), ), ((2.7, -0.15, 3.54375), ), ((
    2.7, -0.15, 3.46875), ), ((2.7, -0.1125, 3.6), ), ), name='Column_top',
    vertices=
    modRa.instances['Frame-1'].vertices.findAt(((
    2.7, -0.15, 0.075), ), ((2.7, -0.15, 0.0), ), ((2.7, -0.15, 0.15), ), ((
    2.7, 0.0, 0.0), ), ((2.7, 0.0, 0.075), ), ((2.7, 0.0, 0.15), ), )+\
    modRa.instances['Frame-2'].vertices.findAt(((
    2.7, 0.0, 3.525), ), ((2.7, 0.0, 3.6), ), ((2.7, 0.0, 3.45), ), ((2.7,
    -0.15, 3.6), ), ((2.7, -0.15, 3.525), ), ((2.7, -0.15, 3.45), ), ))
mod.DisplacementBC(amplitude=UNSET, createStepName='Initial',
    distributionType=UNIFORM, fieldName='', localCsys=None, name='Column_top',
    region=modRa.sets['Column_top'], u1=UNSET, u2=
    SET, u3=SET, ur1=UNSET, ur2=UNSET, ur3=UNSET)
modRa.Surface(name='CP-1-Inner_plate-1',
    side1Faces=
    modRa.instances['Inner_plate-1'].faces.findAt(
    ((0.125, 0.002, 0.25), ), ((0.1, 0.002, 0.75), ), ((0.1, 0.002, 1.2), ), ((
    0.1, 0.002, 1.65), ), ((0.1, 0.002, 2.1), ), ((0.1, 0.002, 2.55), ), ((0.1,
    0.002, 3.0), ), ((0.125, 0.002, 3.35), ), ((2.45, 0.002, 0.125), ), ((2.1,
    0.002, 0.1), ), ((1.65, 0.002, 0.1), ), ((1.2, 0.002, 0.1), ), ((0.75,
    0.002, 0.1), ), ((0.25, 0.002, 0.125), ), ((2.35, 0.002, 0.25), ), ((2.45,
    0.002, 0.75), ), ((2.45, 0.002, 1.2), ), ((2.45, 0.002, 1.65), ), ((2.45,
    0.002, 2.1), ), ((2.45, 0.002, 2.55), ), ((2.45, 0.002, 3.0), ), ((2.575,
    0.002, 3.35), ), ((2.45, 0.002, 3.35), ), ((2.1, 0.002, 3.35), ), ((1.65,
    0.002, 3.35), ), ((1.2, 0.002, 3.35), ), ((0.75, 0.002, 3.35), ), ((0.25,
    0.002, 3.475), ), ((2.624784, 0.002, 3.498362), ), ((2.598362, 0.002,
    3.524784), ), ((2.45, 0.002, 3.475), ), ((2.650589, 0.002, 3.474411), ), ((
    2.574411, 0.002, 3.550589), ), ((2.651638, 0.002, 3.524784), ), ((2.624784,
    0.002, 3.551638), ), ((2.675589, 0.002, 3.550589), ), ((0.048362, 0.002,
    0.074784), ), ((0.074784, 0.002, 0.048362), ), ((0.024411, 0.002,
    0.100589), ), ((0.100589, 0.002, 0.024411), ), ((0.074784, 0.002,
    0.101638), ), ((0.25, 0.002, 0.25), ), ((0.101638, 0.002, 0.074784), ), ((
    0.100589, 0.002, 0.125589), ), ((2.650589, 0.002, 0.024411), ), ((2.651638,
    0.002, 0.074784), ), ((2.624784, 0.002, 0.048362), ), ((2.675589, 0.002,
    0.100589), ), ((2.624784, 0.002, 0.101638), ), ((2.574411, 0.002,
    0.100589), ), ((2.598362, 0.002, 0.074784), ), ((2.650589, 0.002,
    0.125589), ), ((0.048362, 0.002, 3.524784), ), ((0.074784, 0.002,
    3.498362), ), ((0.100589, 0.002, 3.474411), ), ((0.024411, 0.002,
    3.550589), ), ((0.25, 0.002, 3.25), ), ((0.101638, 0.002, 3.524784), ), ((
    0.074784, 0.002, 3.551638), ), ((0.125589, 0.002, 3.550589), ), ((2.6,
    0.002, 2.85), ), ((2.1, 0.002, 3.0), ), ((1.65, 0.002, 3.0), ), ((1.2,
    0.002, 3.0), ), ((0.75, 0.002, 3.0), ), ((0.25, 0.002, 2.85), ), ((2.6,
    0.002, 2.4), ), ((2.1, 0.002, 2.55), ), ((1.65, 0.002, 2.55), ), ((1.2,
    0.002, 2.55), ), ((0.75, 0.002, 2.55), ), ((0.25, 0.002, 2.4), ), ((2.6,
    0.002, 1.95), ), ((2.1, 0.002, 2.1), ), ((1.65, 0.002, 2.1), ), ((1.2,
    0.002, 2.1), ), ((0.75, 0.002, 2.1), ), ((0.25, 0.002, 1.95), ), ((2.6,
    0.002, 1.5), ), ((2.1, 0.002, 1.65), ), ((1.65, 0.002, 1.65), ), ((1.2,
    0.002, 1.65), ), ((0.75, 0.002, 1.65), ), ((0.25, 0.002, 1.5), ), ((2.6,
    0.002, 1.05), ), ((2.1, 0.002, 1.2), ), ((1.65, 0.002, 1.2), ), ((1.2,
    0.002, 1.2), ), ((0.75, 0.002, 1.2), ), ((0.25, 0.002, 1.05), ), ((2.6,
    0.002, 0.6), ), ((2.1, 0.002, 0.75), ), ((1.65, 0.002, 0.75), ), ((1.2,
    0.002, 0.75), ), ((0.75, 0.002, 0.75), ), ((0.25, 0.002, 0.6), ), ((
    0.100589, 0.002, 3.575589), ), ((0.6, 0.002, 3.5), ), ((1.05, 0.002, 3.5),
    ), ((2.575, 0.002, 0.25), ), ((1.5, 0.002, 3.5), ), ((1.95, 0.002, 0.25),
    ), ((1.95, 0.002, 3.5), ), ((1.5, 0.002, 0.25), ), ((1.05, 0.002, 0.25), ),
    ((0.6, 0.002, 0.25), ), ((0.125589, 0.002, 0.100589), ), ((2.650589, 0.002,
    3.575589), ), ))
modRa.Surface(name='CP-1-Frame-1', side1Faces=
    modRa.instances['Frame-1'].faces.findAt(((
    2.625216, 0.0, 0.048362), ), ((2.624784, 0.0, 0.048362), ), ((2.651638,
    0.0, 0.074784), ), ((2.598362, 0.0, 0.074784), ), ((2.651638, 0.0,
    0.075216), ), ((2.598362, 0.0, 0.075216), ), ((2.625216, 0.0, 0.101638), ),
    ((0.074784, 0.0, 0.101638), ), ((0.048362, 0.0, 0.075216), ), ((0.100589,
    0.0, 0.125589), ), ((0.024411, 0.0, 0.049411), ), ((0.101638, 0.0,
    0.075216), ), ((0.074784, 0.0, 0.048362), ), ((0.125589, 0.0, 0.049411), ),
    ((1.75, 0.0, 0.1), ), ((0.100589, 0.0, 0.024411), ), ((2.624784, 0.0,
    0.101638), ), ))
modRa.Surface(name='CP-2-Inner_plate-1',
    side1Faces=
    modRa.instances['Inner_plate-1'].faces.findAt(
    ((0.125, 0.002, 0.25), ), ((0.1, 0.002, 0.75), ), ((0.1, 0.002, 1.2), ), ((
    0.1, 0.002, 1.65), ), ((0.1, 0.002, 2.1), ), ((0.1, 0.002, 2.55), ), ((0.1,
    0.002, 3.0), ), ((0.125, 0.002, 3.35), ), ((2.45, 0.002, 0.125), ), ((2.1,
    0.002, 0.1), ), ((1.65, 0.002, 0.1), ), ((1.2, 0.002, 0.1), ), ((0.75,
    0.002, 0.1), ), ((0.25, 0.002, 0.125), ), ((2.35, 0.002, 0.25), ), ((2.45,
    0.002, 0.75), ), ((2.45, 0.002, 1.2), ), ((2.45, 0.002, 1.65), ), ((2.45,
    0.002, 2.1), ), ((2.45, 0.002, 2.55), ), ((2.45, 0.002, 3.0), ), ((2.575,
    0.002, 3.35), ), ((2.45, 0.002, 3.35), ), ((2.1, 0.002, 3.35), ), ((1.65,
    0.002, 3.35), ), ((1.2, 0.002, 3.35), ), ((0.75, 0.002, 3.35), ), ((0.25,
    0.002, 3.475), ), ((2.624784, 0.002, 3.498362), ), ((2.598362, 0.002,
    3.524784), ), ((2.45, 0.002, 3.475), ), ((2.650589, 0.002, 3.474411), ), ((
    2.574411, 0.002, 3.550589), ), ((2.651638, 0.002, 3.524784), ), ((2.624784,
    0.002, 3.551638), ), ((2.675589, 0.002, 3.550589), ), ((0.048362, 0.002,
    0.074784), ), ((0.074784, 0.002, 0.048362), ), ((0.024411, 0.002,
    0.100589), ), ((0.100589, 0.002, 0.024411), ), ((0.074784, 0.002,
    0.101638), ), ((0.25, 0.002, 0.25), ), ((0.101638, 0.002, 0.074784), ), ((
    0.100589, 0.002, 0.125589), ), ((2.650589, 0.002, 0.024411), ), ((2.651638,
    0.002, 0.074784), ), ((2.624784, 0.002, 0.048362), ), ((2.675589, 0.002,
    0.100589), ), ((2.624784, 0.002, 0.101638), ), ((2.574411, 0.002,
    0.100589), ), ((2.598362, 0.002, 0.074784), ), ((2.650589, 0.002,
    0.125589), ), ((0.048362, 0.002, 3.524784), ), ((0.074784, 0.002,
    3.498362), ), ((0.100589, 0.002, 3.474411), ), ((0.024411, 0.002,
    3.550589), ), ((0.25, 0.002, 3.25), ), ((0.101638, 0.002, 3.524784), ), ((
    0.074784, 0.002, 3.551638), ), ((0.125589, 0.002, 3.550589), ), ((2.6,
    0.002, 2.85), ), ((2.1, 0.002, 3.0), ), ((1.65, 0.002, 3.0), ), ((1.2,
    0.002, 3.0), ), ((0.75, 0.002, 3.0), ), ((0.25, 0.002, 2.85), ), ((2.6,
    0.002, 2.4), ), ((2.1, 0.002, 2.55), ), ((1.65, 0.002, 2.55), ), ((1.2,
    0.002, 2.55), ), ((0.75, 0.002, 2.55), ), ((0.25, 0.002, 2.4), ), ((2.6,
    0.002, 1.95), ), ((2.1, 0.002, 2.1), ), ((1.65, 0.002, 2.1), ), ((1.2,
    0.002, 2.1), ), ((0.75, 0.002, 2.1), ), ((0.25, 0.002, 1.95), ), ((2.6,
    0.002, 1.5), ), ((2.1, 0.002, 1.65), ), ((1.65, 0.002, 1.65), ), ((1.2,
    0.002, 1.65), ), ((0.75, 0.002, 1.65), ), ((0.25, 0.002, 1.5), ), ((2.6,
    0.002, 1.05), ), ((2.1, 0.002, 1.2), ), ((1.65, 0.002, 1.2), ), ((1.2,
    0.002, 1.2), ), ((0.75, 0.002, 1.2), ), ((0.25, 0.002, 1.05), ), ((2.6,
    0.002, 0.6), ), ((2.1, 0.002, 0.75), ), ((1.65, 0.002, 0.75), ), ((1.2,
    0.002, 0.75), ), ((0.75, 0.002, 0.75), ), ((0.25, 0.002, 0.6), ), ((
    0.100589, 0.002, 3.575589), ), ((0.6, 0.002, 3.5), ), ((1.05, 0.002, 3.5),
    ), ((2.575, 0.002, 0.25), ), ((1.5, 0.002, 3.5), ), ((1.95, 0.002, 0.25),
    ), ((1.95, 0.002, 3.5), ), ((1.5, 0.002, 0.25), ), ((1.05, 0.002, 0.25), ),
    ((0.6, 0.002, 0.25), ), ((0.125589, 0.002, 0.100589), ), ((2.650589, 0.002,
    3.575589), ), ))
modRa.Surface(name='CP-2-Frame-2', side1Faces=
    modRa.instances['Frame-2'].faces.findAt(((
    0.074784, 0.0, 3.551638), ), ((0.075216, 0.0, 3.551638), ), ((0.048362,
    0.0, 3.525216), ), ((0.101638, 0.0, 3.525216), ), ((0.048362, 0.0,
    3.524784), ), ((0.101638, 0.0, 3.524784), ), ((0.074784, 0.0, 3.498362), ),
    ((2.651638, 0.0, 3.525216), ), ((2.625216, 0.0, 3.551638), ), ((2.675589,
    0.0, 3.499411), ), ((2.599411, 0.0, 3.575589), ), ((2.625216, 0.0,
    3.498362), ), ((2.598362, 0.0, 3.525216), ), ((2.599411, 0.0, 3.474411), ),
    ((1.75, 0.0, 3.55), ), ((0.075216, 0.0, 3.498362), ), ((2.574411, 0.0,
    3.499411), ), ))
modRa.Surface(name='CP-3-Insulation-1',
    side1Faces=
    modRa.instances['Insulation-1'].faces.findAt((
    (1.8, 0.0025, 2.4), )))
modRa.Surface(name='CP-3-Inner_plate-1',
    side2Faces=
    modRa.instances['Inner_plate-1'].faces.findAt(
    ((0.125, 0.002, 0.25), ), ((0.1, 0.002, 0.75), ), ((0.1, 0.002, 1.2), ), ((
    0.1, 0.002, 1.65), ), ((0.1, 0.002, 2.1), ), ((0.1, 0.002, 2.55), ), ((0.1,
    0.002, 3.0), ), ((0.125, 0.002, 3.35), ), ((2.45, 0.002, 0.125), ), ((2.1,
    0.002, 0.1), ), ((1.65, 0.002, 0.1), ), ((1.2, 0.002, 0.1), ), ((0.75,
    0.002, 0.1), ), ((0.25, 0.002, 0.125), ), ((2.35, 0.002, 0.25), ), ((2.45,
    0.002, 0.75), ), ((2.45, 0.002, 1.2), ), ((2.45, 0.002, 1.65), ), ((2.45,
    0.002, 2.1), ), ((2.45, 0.002, 2.55), ), ((2.45, 0.002, 3.0), ), ((2.575,
    0.002, 3.35), ), ((2.45, 0.002, 3.35), ), ((2.1, 0.002, 3.35), ), ((1.65,
    0.002, 3.35), ), ((1.2, 0.002, 3.35), ), ((0.75, 0.002, 3.35), ), ((0.25,
    0.002, 3.475), ), ((2.624784, 0.002, 3.498362), ), ((2.598362, 0.002,
    3.524784), ), ((2.45, 0.002, 3.475), ), ((2.650589, 0.002, 3.474411), ), ((
    2.574411, 0.002, 3.550589), ), ((2.651638, 0.002, 3.524784), ), ((2.624784,
    0.002, 3.551638), ), ((2.675589, 0.002, 3.550589), ), ((0.048362, 0.002,
    0.074784), ), ((0.074784, 0.002, 0.048362), ), ((0.024411, 0.002,
    0.100589), ), ((0.100589, 0.002, 0.024411), ), ((0.074784, 0.002,
    0.101638), ), ((0.25, 0.002, 0.25), ), ((0.101638, 0.002, 0.074784), ), ((
    0.100589, 0.002, 0.125589), ), ((2.650589, 0.002, 0.024411), ), ((2.651638,
    0.002, 0.074784), ), ((2.624784, 0.002, 0.048362), ), ((2.675589, 0.002,
    0.100589), ), ((2.624784, 0.002, 0.101638), ), ((2.574411, 0.002,
    0.100589), ), ((2.598362, 0.002, 0.074784), ), ((2.650589, 0.002,
    0.125589), ), ((0.048362, 0.002, 3.524784), ), ((0.074784, 0.002,
    3.498362), ), ((0.100589, 0.002, 3.474411), ), ((0.024411, 0.002,
    3.550589), ), ((0.25, 0.002, 3.25), ), ((0.101638, 0.002, 3.524784), ), ((
    0.074784, 0.002, 3.551638), ), ((0.125589, 0.002, 3.550589), ), ((2.6,
    0.002, 2.85), ), ((2.1, 0.002, 3.0), ), ((1.65, 0.002, 3.0), ), ((1.2,
    0.002, 3.0), ), ((0.75, 0.002, 3.0), ), ((0.25, 0.002, 2.85), ), ((2.6,
    0.002, 2.4), ), ((2.1, 0.002, 2.55), ), ((1.65, 0.002, 2.55), ), ((1.2,
    0.002, 2.55), ), ((0.75, 0.002, 2.55), ), ((0.25, 0.002, 2.4), ), ((2.6,
    0.002, 1.95), ), ((2.1, 0.002, 2.1), ), ((1.65, 0.002, 2.1), ), ((1.2,
    0.002, 2.1), ), ((0.75, 0.002, 2.1), ), ((0.25, 0.002, 1.95), ), ((2.6,
    0.002, 1.5), ), ((2.1, 0.002, 1.65), ), ((1.65, 0.002, 1.65), ), ((1.2,
    0.002, 1.65), ), ((0.75, 0.002, 1.65), ), ((0.25, 0.002, 1.5), ), ((2.6,
    0.002, 1.05), ), ((2.1, 0.002, 1.2), ), ((1.65, 0.002, 1.2), ), ((1.2,
    0.002, 1.2), ), ((0.75, 0.002, 1.2), ), ((0.25, 0.002, 1.05), ), ((2.6,
    0.002, 0.6), ), ((2.1, 0.002, 0.75), ), ((1.65, 0.002, 0.75), ), ((1.2,
    0.002, 0.75), ), ((0.75, 0.002, 0.75), ), ((0.25, 0.002, 0.6), ), ((
    0.100589, 0.002, 3.575589), ), ((0.6, 0.002, 3.5), ), ((1.05, 0.002, 3.5),
    ), ((2.575, 0.002, 0.25), ), ((1.5, 0.002, 3.5), ), ((1.95, 0.002, 0.25),
    ), ((1.95, 0.002, 3.5), ), ((1.5, 0.002, 0.25), ), ((1.05, 0.002, 0.25), ),
    ((0.6, 0.002, 0.25), ), ((0.125589, 0.002, 0.100589), ), ((2.650589, 0.002,
    3.575589), ), ))
modRa.Surface(name='CP-4-Insulation-1',
    side1Faces=
    modRa.instances['Insulation-1'].faces.findAt((
    (0.9, 0.0825, 2.4), )))
modRa.Surface(name='CP-4-Outer_plate-1',
    side1Faces=
    modRa.instances['Outer_plate-1'].faces.findAt(
    ((2.55, 0.083, 3.0), ), ((2.1, 0.083, 3.0), ), ((1.65, 0.083, 3.0), ), ((
    1.2, 0.083, 3.0), ), ((0.75, 0.083, 3.0), ), ((0.3, 0.083, 3.0), ), ((2.55,
    0.083, 2.55), ), ((2.1, 0.083, 2.55), ), ((1.65, 0.083, 2.55), ), ((1.2,
    0.083, 2.55), ), ((0.75, 0.083, 2.55), ), ((0.3, 0.083, 2.55), ), ((2.55,
    0.083, 2.1), ), ((2.1, 0.083, 2.1), ), ((1.65, 0.083, 2.1), ), ((1.2,
    0.083, 2.1), ), ((0.75, 0.083, 2.1), ), ((0.3, 0.083, 2.1), ), ((2.55,
    0.083, 1.65), ), ((2.1, 0.083, 1.65), ), ((1.65, 0.083, 1.65), ), ((1.2,
    0.083, 1.65), ), ((0.75, 0.083, 1.65), ), ((0.3, 0.083, 1.65), ), ((2.55,
    0.083, 1.2), ), ((2.1, 0.083, 1.2), ), ((1.65, 0.083, 1.2), ), ((1.2,
    0.083, 1.2), ), ((0.75, 0.083, 1.2), ), ((0.3, 0.083, 1.2), ), ((2.55,
    0.083, 0.75), ), ((2.1, 0.083, 0.75), ), ((1.65, 0.083, 0.75), ), ((1.2,
    0.083, 0.75), ), ((0.75, 0.083, 0.75), ), ((0.3, 0.083, 0.75), ), ((0.15,
    0.083, 3.3), ), ((0.6, 0.083, 3.3), ), ((1.05, 0.083, 3.3), ), ((2.55,
    0.083, 0.3), ), ((1.5, 0.083, 3.3), ), ((2.1, 0.083, 0.3), ), ((1.95,
    0.083, 3.3), ), ((1.65, 0.083, 0.3), ), ((1.2, 0.083, 0.3), ), ((0.75,
    0.083, 0.3), ), ((0.3, 0.083, 0.3), ), ((2.4, 0.083, 3.3), ), ))
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE,
    interactionProperty='Conductance', slave=
    modRa.surfaces['CP-1-Inner_plate-1'], name=
    'CP-1-Inner_plate-1-Frame-1', master=
    modRa.surfaces['CP-1-Frame-1'], sliding=FINITE
    , surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE,
    interactionProperty='Conductance', slave=
    modRa.surfaces['CP-2-Inner_plate-1'], name=
    'CP-2-Inner_plate-1-Frame-2', master=
    modRa.surfaces['CP-2-Frame-2'], sliding=FINITE
    , surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE,
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-3-Insulation-1'], name=
    'CP-3-Insulation-1-Inner_plate-1', slave=
    modRa.surfaces['CP-3-Inner_plate-1'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE,
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-4-Insulation-1'], name=
    'CP-4-Insulation-1-Outer_plate-1', slave=
    modRa.surfaces['CP-4-Outer_plate-1'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
### Create Step ###
# Step is later modified for current iteration (by upGeomHT).
mod.HeatTransferStep(deltmx=50.0, initialInc=1.0, maxInc=
    1.0, maxNumInc=1000, minInc=1E-6, name='i0_HT-step',
	previous='Initial', timePeriod=5.0)
### Import Adiabatic Temperature Data ###
imp = mod.TabularAmplitude
modFOR = mod.fieldOutputRequests['F-Output-1']
modFOR.setValues(variables=('NT',), frequency=1)  # or this
### Request Restart File for Initial Request ###
mod.steps['i0_HT-step'].Restart(frequency=0, numberIntervals=1, overlay=ON,
	timeMarks=OFF)
### Model change Interaction ###
mod.ModelChange(name='ModelChange', createStepName='i0_HT-step',
	isRestart=True)
########################## End of HT_basicModel ###########################
################### Additional Lines Added by upGeomHT ####################
### Create/Update Additional Steps ###
mod.steps['i0_HT-step'].setValues(timePeriod=5, maxInc=1.0)
### Define Restart Job/Step ###
#no additional restart information is written since it is the initial (zero'th) iteration
### Update ConRad and AST Data ###
imp = mod.TabularAmplitude
# execfile(r'../AST_Amp_data.py', __main__.__dict__)
execfile(r'../AST_Amp_data.py', __main__.__dict__)
### Assign temperature ###
# Change name #
Panel_name = 1
Partition_number = 1
surface_number = 1
for Panel_name in range(1, 4):
    for Partition_number in range(1, 17):
        ### Change radiation ###
        mod.RadiationToAmbient(name='Rad_%s-%s'%(Panel_name, Partition_number), createStepName='i0_HT-step',
            emissivity=0.8, ambientTemperature=1.0,
            ambientTemperatureAmp='i0_AST_%s-%s'%(Panel_name, Partition_number),
            surface=modRa.instances['Inner_plate-1'].surfaces['Surf-%s'%surface_number])
        ### change convection ###
        mod.FilmCondition(name='Conv_%s-%s'%(Panel_name, Partition_number), createStepName='i0_HT-step', definition=EMBEDDED_COEFF, filmCoeff=25,
                          sinkAmplitude='i0_AST_%s-%s'%(Panel_name, Partition_number), sinkTemperature=1.0,
                          surface=modRa.instances['Inner_plate-1'].surfaces['Surf-%s'%surface_number])
        Partition_number = Partition_number + 1
        surface_number = surface_number + 1
    Panel_name = Panel_name + 1
## Boundary condition for the column ##
modRa.Set(edges=
    modRa.instances['Frame-1'].edges.findAt(((0.0,
    -0.15, 0.05625), ), ((0.0, -0.15, 0.13125), ), ((0.0, 0.0, 0.09375), ), ((
    0.0, 0.0, 0.01875), ), ((0.0, -0.1125, 0.0), ), )+\
    modRa.instances['Frame-2'].edges.findAt(((0.0,
    0.0, 3.54375), ), ((0.0, 0.0, 3.46875), ), ((0.0, -0.15, 3.50625), ), ((
    0.0, -0.15, 3.58125), ), ((0.0, -0.0375, 3.6), ), ), name='Column_bottom',
    vertices=
    modRa.instances['Frame-1'].vertices.findAt(((
    0.0, -0.15, 0.0), ), ((0.0, -0.15, 0.075), ), ((0.0, -0.15, 0.15), ), ((
    0.0, 0.0, 0.15), ), ((0.0, 0.0, 0.075), ), ((0.0, 0.0, 0.0), ), )+\
    modRa.instances['Frame-2'].vertices.findAt(((
    0.0, 0.0, 3.6), ), ((0.0, 0.0, 3.525), ), ((0.0, 0.0, 3.45), ), ((0.0,
    -0.15, 3.45), ), ((0.0, -0.15, 3.525), ), ((0.0, -0.15, 3.6), ), ))
mod.DisplacementBC(amplitude=UNSET, createStepName='Initial',
    distributionType=UNIFORM, fieldName='', localCsys=None, name='Column_bottom',
    region=modRa.sets['Column_bottom'], u1=SET, u2=
    SET, u3=SET, ur1=UNSET, ur2=UNSET, ur3=UNSET)
modRa.Set(edges=
    modRa.instances['Frame-1'].edges.findAt(((2.7,
    -0.15, 0.01875), ), ((2.7, -0.15, 0.09375), ), ((2.7, 0.0, 0.05625), ), ((
    2.7, 0.0, 0.13125), ), ((2.7, -0.0375, 0.0), ), )+\
    modRa.instances['Frame-2'].edges.findAt(((2.7,
    0.0, 3.58125), ), ((2.7, 0.0, 3.50625), ), ((2.7, -0.15, 3.54375), ), ((
    2.7, -0.15, 3.46875), ), ((2.7, -0.1125, 3.6), ), ), name='Column_top',
    vertices=
    modRa.instances['Frame-1'].vertices.findAt(((
    2.7, -0.15, 0.075), ), ((2.7, -0.15, 0.0), ), ((2.7, -0.15, 0.15), ), ((
    2.7, 0.0, 0.0), ), ((2.7, 0.0, 0.075), ), ((2.7, 0.0, 0.15), ), )+\
    modRa.instances['Frame-2'].vertices.findAt(((
    2.7, 0.0, 3.525), ), ((2.7, 0.0, 3.6), ), ((2.7, 0.0, 3.45), ), ((2.7,
    -0.15, 3.6), ), ((2.7, -0.15, 3.525), ), ((2.7, -0.15, 3.45), ), ))
mod.DisplacementBC(amplitude=UNSET, createStepName='Initial',
    distributionType=UNIFORM, fieldName='', localCsys=None, name='Column_top',
    region=modRa.sets['Column_top'], u1=UNSET, u2=
    SET, u3=SET, ur1=UNSET, ur2=UNSET, ur3=UNSET)
########################## End of Buckling_basicModel ###########################
################### Additional Lines Added by upGeomHT ####################
### Define Restart Job/Step ###
#no additional restart information is written since it is the initial (zero'th) iteration
### Update ConRad and AST Data ###
mod.steps['i0_HT-step'].setValues(timePeriod=5)
############The following is additional lines to update HT script ############

