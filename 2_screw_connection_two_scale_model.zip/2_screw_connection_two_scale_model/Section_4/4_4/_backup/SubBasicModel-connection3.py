# -*- coding: mbcs -*-
from abaqus import *
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from abaqusConstants import *
cliCommand("""session.journalOptions.setValues(replayGeometry=COORDINATE,
	recoverGeometry=COORDINATE)""")
### use this lines for use in FDS-2-Abaqus (relative path)
currentPath = os.getcwd()
### Set directory to outputHT, if not exists, create the folder ##
os.chdir(currentPath + '\\outputSR\\')
## Name Model ##
mod = mdb.models['Model-1']
modRa = mod.rootAssembly
## Specify-Attributes ##
mod.setValues(absoluteZero=-273.15, stefanBoltzmann=5.67e-08)
## Create plate-1 (frame) ##
mod.ConstrainedSketch(name='__profile__', sheetSize=0.5)
mod.sketches['__profile__'].rectangle(point1=(-0.015, -0.015),
    point2=(0.015, 0.015))
mod.sketches['__profile__'].CircleByCenterPerimeter(center=(
    0.0, 0.0), point1=(0.0025, 0.0))
mod.Part(dimensionality=THREE_D, name='Plate-1', type=
    DEFORMABLE_BODY)
mod.parts['Plate-1'].BaseSolidExtrude(depth=0.003, sketch=
    mod.sketches['__profile__'])
del mod.sketches['__profile__']
## Create partition for threaded contact ##
mod.ConstrainedSketch(gridSpacing=0.002, name='__profile__',
    sheetSize=0.085, transform=
    mod.parts['Plate-1'].MakeSketchTransform(
    sketchPlane=mod.parts['Plate-1'].faces.findAt((0.006603,
    -0.005319, 0.003), ), sketchPlaneSide=SIDE1,
    sketchUpEdge=mod.parts['Plate-1'].edges.findAt((0.015,
    0.0075, 0.003), ), sketchOrientation=RIGHT, origin=(0.0, 0.0, 0.003)))
mod.sketches['__profile__'].sketchOptions.setValues(
    decimalPlaces=3)
mod.parts['Plate-1'].projectReferencesOntoSketch(filter=
    COPLANAR_EDGES, sketch=mod.sketches['__profile__'])
mod.sketches['__profile__'].CircleByCenterPerimeter(center=(
    0.0, 0.0), point1=(0.0026, 0.0))
mod.parts['Plate-1'].PartitionFaceBySketch(faces=
    mod.parts['Plate-1'].faces.findAt(((0.006603, -0.005319,
    0.003), )), sketch=mod.sketches['__profile__'],
    sketchUpEdge=mod.parts['Plate-1'].edges.findAt((0.015,
    0.0075, 0.003), ))
del mod.sketches['__profile__']
## Create Partition for plate ##
mod.parts['Plate-1'].PartitionCellByPlaneThreePoints(cells=
    mod.parts['Plate-1'].cells.findAt(((0.015, 0.005, 0.002),
    )), point1=mod.parts['Plate-1'].InterestingPoint(
    mod.parts['Plate-1'].edges.findAt((0.0, 0.0025, 0.003),
    ), CENTER), point2=mod.parts['Plate-1'].vertices.findAt((
    -0.015, -0.015, 0.003), ), point3=
    mod.parts['Plate-1'].InterestingPoint(
    mod.parts['Plate-1'].edges.findAt((0.0, 0.0025, 0.0), ),
    CENTER))
mod.parts['Plate-1'].PartitionCellByPlanePointNormal(cells=
    mod.parts['Plate-1'].cells.findAt(((-0.001982, -0.001523,
    0.001), ), ((0.015, 0.005, 0.002), ), ), normal=
    mod.parts['Plate-1'].edges.findAt((0.011692, 0.011692,
    0.003), ), point=mod.parts['Plate-1'].InterestingPoint(
    mod.parts['Plate-1'].edges.findAt((0.0, 0.0025, 0.003),
    ), CENTER))
mod.parts['Plate-1'].PartitionCellByExtrudeEdge(cells=
    mod.parts['Plate-1'].cells.findAt(((0.006311, -0.006006,
    0.0), ), ((-0.001982, 0.001523, 0.002), ), ((-0.001523, 0.001982, 0.001),
    ), ((0.005908, -0.006359, 0.0), ), ), edges=(
    mod.parts['Plate-1'].edges.findAt((0.002162, -0.001444,
    0.003), ), mod.parts['Plate-1'].edges.findAt((0.00255,
    0.000507, 0.003), ), mod.parts['Plate-1'].edges.findAt((
    -0.002402, 0.000995, 0.003), ),
    mod.parts['Plate-1'].edges.findAt((0.000995, 0.002402,
    0.003), ), mod.parts['Plate-1'].edges.findAt((-0.000995,
    -0.002402, 0.003), )), line=
    mod.parts['Plate-1'].edges.findAt((0.001768, -0.001768,
    0.00225), ), sense=FORWARD)
## Partition face for measuring displacement ##
mod.parts['Plate-1'].PartitionFaceByShortestPath(faces=
    mod.parts['Plate-1'].faces.findAt(((-0.005, 0.015,
    0.002), )), point1=mod.parts['Plate-1'].InterestingPoint(
    mod.parts['Plate-1'].edges.findAt((-0.0075, 0.015,
    0.003), ), MIDDLE), point2=
    mod.parts['Plate-1'].InterestingPoint(
    mod.parts['Plate-1'].edges.findAt((-0.0075, 0.015, 0.0),
    ), MIDDLE))
mod.parts['Plate-1'].PartitionFaceByShortestPath(faces=
    mod.parts['Plate-1'].faces.findAt(((-0.015, -0.005,
    0.002), )), point1=mod.parts['Plate-1'].InterestingPoint(
    mod.parts['Plate-1'].edges.findAt((-0.015, -0.0075,
    0.003), ), MIDDLE), point2=
    mod.parts['Plate-1'].InterestingPoint(
    mod.parts['Plate-1'].edges.findAt((-0.015, -0.0075, 0.0),
    ), MIDDLE))
mod.parts['Plate-1'].PartitionFaceByShortestPath(faces=
    mod.parts['Plate-1'].faces.findAt(((0.005, -0.015,
    0.002), )), point1=mod.parts['Plate-1'].InterestingPoint(
    mod.parts['Plate-1'].edges.findAt((0.0075, -0.015,
    0.003), ), MIDDLE), point2=
    mod.parts['Plate-1'].InterestingPoint(
    mod.parts['Plate-1'].edges.findAt((0.0075, -0.015, 0.0),
    ), MIDDLE))
mod.parts['Plate-1'].PartitionFaceByShortestPath(faces=
    mod.parts['Plate-1'].faces.findAt(((0.015, 0.005, 0.002),
    )), point1=mod.parts['Plate-1'].InterestingPoint(
    mod.parts['Plate-1'].edges.findAt((0.015, 0.0075, 0.003),
    ), MIDDLE), point2=mod.parts['Plate-1'].InterestingPoint(
    mod.parts['Plate-1'].edges.findAt((0.015, 0.0075, 0.0),
    ), MIDDLE))
## Create plate 2 (plate) ##
mod.Part(name='Plate-2', objectToCopy=
    mod.parts['Plate-1'])
mod.parts['Plate-2'].features['Solid extrude-1'].setValues(
    depth=0.001)
mod.parts['Plate-2'].regenerate()
## Create screw connection ##
mod.ConstrainedSketch(name='__profile__', sheetSize=0.02)
mod.sketches['__profile__'].sketchOptions.setValues(
    decimalPlaces=4)
mod.sketches['__profile__'].ConstructionLine(point1=(0.0,
    -0.01), point2=(0.0, 0.01))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.0))
mod.sketches['__profile__'].FixedConstraint(entity=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.0),
    ))
mod.sketches['__profile__'].Line(point1=(0.0, 0.004), point2=
    (0.005, 0.004))
mod.sketches['__profile__'].geometry.findAt((0.0025, 0.004))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.0025,
    0.004), ))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.0025, 0.004))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.0), )
    , entity2=mod.sketches['__profile__'].geometry.findAt((
    0.0025, 0.004), ))
mod.sketches['__profile__'].vertices.findAt((0.0, 0.004))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.0))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.0, 0.004),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    0.0, 0.0), ))
mod.sketches['__profile__'].Line(point1=(0.005,
    0.004), point2=(0.005, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.005, 0.002))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.005,
    0.002), ))
mod.sketches['__profile__'].geometry.findAt((0.0025, 0.004))
mod.sketches['__profile__'].geometry.findAt((0.005, 0.002))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((0.0025,
    0.004), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.005,
    0.002), ))
mod.sketches['__profile__'].Line(point1=(0.005,
    0.0), point2=(0.0025, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.00375, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.00375,
    0.0), ))
mod.sketches['__profile__'].geometry.findAt((0.005, 0.002))
mod.sketches['__profile__'].geometry.findAt((0.00375, 0.0))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((0.005,
    0.002), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.00375,
    0.0), ))
mod.sketches['__profile__'].Line(point1=(0.0025,
    0.0), point2=(0.0025, -0.006))
mod.sketches['__profile__'].geometry.findAt((0.0025,
    -0.0035))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.0025,
    -0.0035), ))
mod.sketches['__profile__'].geometry.findAt((0.00375, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.0025,
    -0.0035))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((0.00375,
    0.0), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.0025,
    -0.0035), ))
mod.sketches['__profile__'].Line(point1=(0.0025,
    -0.006), point2=(0.0, -0.006))
mod.sketches['__profile__'].geometry.findAt((0.00125,
    -0.006))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.00125,
    -0.006), ))
mod.sketches['__profile__'].geometry.findAt((0.0025,
    -0.0035))
mod.sketches['__profile__'].geometry.findAt((0.00125,
    -0.006))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((0.0025,
    -0.0035), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.00125,
    -0.006), ))
mod.sketches['__profile__'].vertices.findAt((0.0, -0.006))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.0))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.0,
    -0.006), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.0),
    ))
mod.sketches['__profile__'].Line(point1=(0.0, -0.006),
    point2=(0.0, 0.004))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.00345))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.0,
    0.00345), ))
mod.sketches['__profile__'].geometry.findAt((0.00125,
    -0.006))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.00345))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((0.00125,
    -0.006), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((0.0,
    0.00345), ))
mod.Part(dimensionality=THREE_D, name='Screw', type=
    DEFORMABLE_BODY)
mod.parts['Screw'].BaseSolidRevolve(angle=360.0,
    flipRevolveDirection=OFF, sketch=
    mod.sketches['__profile__'])
del mod.sketches['__profile__']
## Create partition for meshing ##
mod.parts['Screw'].PartitionCellByPlanePointNormal(cells=
    mod.parts['Screw'].cells.findAt(((0.000326, -0.006,
    0.002269), )), normal=mod.parts['Screw'].edges.findAt((
    0.0025, -0.00175, 0.0), ), point=
    mod.parts['Screw'].vertices.findAt((0.0025, 0.0, 0.0), ))
mod.parts['Screw'].PartitionCellByPlanePointNormal(cells=
    mod.parts['Screw'].cells.findAt(((0.004122, 0.0,
    -0.000384), ), ((0.000326, -0.006, 0.002269), ), ), normal=
    mod.parts['Screw'].edges.findAt((0.004375, 0.0, 0.0), ),
    point=mod.parts['Screw'].InterestingPoint(
    mod.parts['Screw'].edges.findAt((0.0, 0.004, 0.005), ),
    CENTER))
mod.parts['Screw'].PartitionCellByPlanePointNormal(cells=
    mod.parts['Screw'].cells.findAt(((-0.000258, -0.006,
    0.000793), ), ((-0.000371, 0.004, 0.001625), ), ((0.000371, 0.0,
    -0.004125), ), ((0.000258, -0.006, 0.000793), ), ), normal=
    mod.parts['Screw'].edges.findAt((0.0, 0.004, 0.0025), ),
    point=mod.parts['Screw'].InterestingPoint(
    mod.parts['Screw'].edges.findAt((0.004619, 0.004,
    0.001913), ), CENTER))
## Create material property ##
## Steel properties ## including temperature dependant properties ##
mod.Material(name='Steel_S355')
mod.materials['Steel_S355'].Elastic(table=((210000000000.0, 0.3,
    0), (210000000000.0, 0.3, 20), (210000000000.0, 0.3, 100), (
    126000000000.0, 0.3, 500), (63000000000.0, 0.3, 600), (31000000000.0,
    0.3, 700), (10000000000.0, 0.3, 1000)), temperatureDependency=ON)
mod.materials['Steel_S355'].Density(table=((7850.0, ), ))
mod.materials['Steel_S355'].SpecificHeat(table=((440.0, 20.0), (
    760.0, 600.0), (5000.0, 735.0), (650.4, 900.0), (650.0, 1200.0)),
    temperatureDependency=ON)
mod.materials['Steel_S355'].Conductivity(table=((53.3, 20.0), (
    27.4, 800.0), (27.3, 1200.0)), temperatureDependency=ON)
mod.materials['Steel_S355'].Plastic(table=(
	(355000000.0, 0.0, 0), (510000000.0, 0.14, 0),
	(355000000.0, 0.0, 400), (510000000.0, 0.14, 400),
	(177000000.0, 0.0, 600), (255000000.0, 0.14, 600),
	(88800000.0, 0.0, 700), (128000000.0, 0.14, 700),
	(35500000.0, 0.0, 800), (51000000.0, 0.14, 800),
	(17800000.0, 0.0, 1000), (25500000.0, 0.14, 1000)), temperatureDependency=ON)
mod.materials['Steel_S355'].DuctileDamageInitiation(table=((
    0.15, 0.0, 0.0), ))
mod.materials['Steel_S355'].ductileDamageInitiation.DamageEvolution(
    table=((2e-04, ), ), type=DISPLACEMENT)
## Create section and assign property ##
mod.HomogeneousSolidSection(material='Steel_S355', name=
    'Steel_section', thickness=None)
mod.parts['Plate-1'].SectionAssignment(offset=0.0,
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    cells=mod.parts['Plate-1'].cells.findAt(((0.001263,
    -0.002183, 0.0), ), ((-0.005944, 0.006414, 0.003), ), ((-0.006414,
    0.005944, 0.003), ), ((0.006363, -0.006046, 0.003), ), ((0.001924,
    0.001619, 0.0), ), ((-0.001982, 0.001523, 0.002), ), ((-0.001523, 0.001982,
    0.001), ), ((0.005944, -0.006414, 0.003), ), )), sectionName=
    'Steel_section', thicknessAssignment=FROM_SECTION)
mod.parts['Plate-2'].SectionAssignment(offset=0.0,
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    cells=mod.parts['Plate-2'].cells.findAt(((0.001263,
    -0.002183, 0.0), ), ((-0.005944, 0.006414, 0.001), ), ((-0.006414,
    0.005944, 0.001), ), ((0.006363, -0.006046, 0.001), ), ((0.001924,
    0.001619, 0.0), ), ((-0.001982, 0.001523, 0.000667), ), ((-0.001523,
    0.001982, 0.000333), ), ((0.005944, -0.006414, 0.001), ), )), sectionName=
    'Steel_section', thicknessAssignment=FROM_SECTION)
mod.parts['Screw'].SectionAssignment(offset=0.0, offsetField=
    '', offsetType=MIDDLE_SURFACE, region=Region(
    cells=mod.parts['Screw'].cells.findAt(((0.001626, -0.006,
    0.000258), ), ((0.003292, 0.004, 0.000371), ), ((-0.004125, 0.0, 0.000371),
    ), ((-0.001626, -0.006, 0.000258), ), ((-0.001626, -0.006, -0.000258), ), (
    (-0.004125, 0.0, -0.000371), ), ((0.000371, 0.0, -0.004125), ), ((0.001626,
    -0.006, -0.000258), ), )), sectionName='Steel_section',
    thicknessAssignment=FROM_SECTION)
## Assembly ##
# First make contact with every parts #
modRa.DatumCsysByDefault(CARTESIAN)
modRa.Instance(dependent=ON, name='Plate-1-1',
    part=mod.parts['Plate-1'])
modRa.Instance(dependent=ON, name='Plate-2-1',
    part=mod.parts['Plate-2'])
modRa.Instance(dependent=ON, name='Screw-1',
    part=mod.parts['Screw'])
modRa.instances['Plate-2-1'].translate(vector=(
    0.033, 0.0, 0.0))
modRa.instances['Screw-1'].translate(vector=(
    0.054, 0.0, 0.0))
modRa.translate(instanceList=('Plate-2-1', ),
    vector=(-0.033, 0.0, 0.003))
modRa.rotate(angle=90.0, axisDirection=(1.0, 0.0,
    0.0), axisPoint=(0.0, 0.0, 0.0), instanceList=('Screw-1', ))
modRa.translate(instanceList=('Screw-1', ),
    vector=(-0.054, 0.0, 0.004))
modRa.rotate(angle=90.0, axisDirection=(-1.0, 0.0,
    0.0), axisPoint=(0.0, 0.0, 0.0), instanceList=('Plate-1-1', 'Plate-2-1',
    'Screw-1'))
# Place all parts to certain location (screw center) #
modRa.translate(instanceList=('Plate-1-1',
    'Plate-2-1', 'Screw-1'), vector=(0.075, -0.0015, 0.075))
## Create MESH ##
mod.parts['Plate-1'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Plate-1'].edges.findAt(((0.002079,
    -0.001389, 0.003), ), ((0.002452, 0.000488, 0.003), ), ((0.002452,
    0.000488, 0.0), ), ((0.002079, -0.001389, 0.0), ), ), number=2)
mod.parts['Plate-1'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Plate-1'].edges.findAt(((-0.015, -0.015,
    0.00075), )), number=4)
mod.parts['Plate-1'].seedPart(deviationFactor=0.1,
    minSizeFactor=0.1, size=0.002)
mod.parts['Plate-1'].seedEdgeByBias(biasMethod=SINGLE,
    constraint=FINER, end1Edges=
    mod.parts['Plate-1'].edges.findAt(((0.005129, 0.005129,
    0.0), ), ((0.005129, -0.005129, 0.0), ), ((-0.005129, -0.005129, 0.003), ),
    ((-0.005129, 0.005129, 0.003), ), ), end2Edges=
    mod.parts['Plate-1'].edges.findAt(((0.01171, 0.01171,
    0.003), ), ((-0.01171, -0.01171, 0.0), ), ((-0.01171, 0.01171, 0.0), ), ((
    0.01171, -0.01171, 0.003), ), ), number=9, ratio=5.0)
mod.parts['Plate-1'].generateMesh()
# Mesh for plate 2 #
mod.parts['Plate-2'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Plate-2'].edges.findAt(((0.002079,
    -0.001389, 0.001), ), ((0.002452, 0.000488, 0.001), ), ((0.002452,
    0.000488, 0.0), ), ((0.002079, -0.001389, 0.0), ), ), number=2)
mod.parts['Plate-2'].seedPart(deviationFactor=0.1,
    minSizeFactor=0.1, size=0.002)
mod.parts['Plate-2'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Plate-2'].edges.findAt(((-0.015, -0.015,
    0.00025), )), number=4)
mod.parts['Plate-2'].seedEdgeByBias(biasMethod=SINGLE,
    constraint=FINER, end1Edges=
    mod.parts['Plate-2'].edges.findAt(((0.005129, 0.005129,
    0.0), ), ((0.005129, -0.005129, 0.0), ), ((-0.005129, -0.005129, 0.001), ),
    ((-0.005129, 0.005129, 0.001), ), ), end2Edges=
    mod.parts['Plate-2'].edges.findAt(((0.01171, 0.01171,
    0.001), ), ((-0.01171, -0.01171, 0.0), ), ((-0.01171, 0.01171, 0.0), ), ((
    0.01171, -0.01171, 0.001), ), ), number=9, ratio=5.0)
mod.parts['Plate-2'].generateMesh()
# Mesh for screw #
mod.parts['Screw'].setMeshControls(algorithm=MEDIAL_AXIS,
    regions=mod.parts['Screw'].cells.findAt(((0.003292,
    0.004, 0.000371), ), ((-0.004125, 0.0, 0.000371), ), ((-0.004125, 0.0,
    -0.000371), ), ((0.000371, 0.0, -0.004125), ), ))
mod.parts['Screw'].seedPart(deviationFactor=0.1,
    minSizeFactor=0.1, size=0.001)
mod.parts['Screw'].generateMesh()
# Create set for thread contact #
mod.parts['Plate-1'].Set(name='Set-thread-nodes-1', nodes=
    mod.parts['Plate-1'].nodes[0:2]+\
    mod.parts['Plate-1'].nodes[4:5]+\
    mod.parts['Plate-1'].nodes[7:8]+\
    mod.parts['Plate-1'].nodes[9:11]+\
    mod.parts['Plate-1'].nodes[13:15]+\
    mod.parts['Plate-1'].nodes[24:25]+\
    mod.parts['Plate-1'].nodes[35:38]+\
    mod.parts['Plate-1'].nodes[41:44]+\
    mod.parts['Plate-1'].nodes[50:53]+\
    mod.parts['Plate-1'].nodes[56:59]+\
    mod.parts['Plate-1'].nodes[67:70]+\
    mod.parts['Plate-1'].nodes[88:91]+\
    mod.parts['Plate-1'].nodes[110:116]+\
    mod.parts['Plate-1'].nodes[126:129]+\
    mod.parts['Plate-1'].nodes[139:142]+\
    mod.parts['Plate-1'].nodes[160:164]+\
    mod.parts['Plate-1'].nodes[176:181]+\
    mod.parts['Plate-1'].nodes[220:229]+\
    mod.parts['Plate-1'].nodes[292:301]+\
    mod.parts['Plate-1'].nodes[397:406]+\
    mod.parts['Plate-1'].nodes[516:531])
mod.parts['Plate-2'].Set(name='Set-thread-nodes-2', nodes=
    mod.parts['Plate-2'].nodes[0:2]+\
    mod.parts['Plate-2'].nodes[4:5]+\
    mod.parts['Plate-2'].nodes[7:8]+\
    mod.parts['Plate-2'].nodes[9:11]+\
    mod.parts['Plate-2'].nodes[13:15]+\
    mod.parts['Plate-2'].nodes[24:25]+\
    mod.parts['Plate-2'].nodes[35:38]+\
    mod.parts['Plate-2'].nodes[41:44]+\
    mod.parts['Plate-2'].nodes[50:53]+\
    mod.parts['Plate-2'].nodes[56:59]+\
    mod.parts['Plate-2'].nodes[67:70]+\
    mod.parts['Plate-2'].nodes[88:91]+\
    mod.parts['Plate-2'].nodes[110:116]+\
    mod.parts['Plate-2'].nodes[126:129]+\
    mod.parts['Plate-2'].nodes[139:142]+\
    mod.parts['Plate-2'].nodes[160:164]+\
    mod.parts['Plate-2'].nodes[176:181]+\
    mod.parts['Plate-2'].nodes[220:229]+\
    mod.parts['Plate-2'].nodes[292:301]+\
    mod.parts['Plate-2'].nodes[397:406]+\
    mod.parts['Plate-2'].nodes[516:531])
## Create STEP ##
mod.StaticStep(initialInc=0.5, maxInc=1, minInc=5e-06, timePeriod=5.0, name='i0_Sub_step',
    nlgeom=ON, previous='Initial')
mod.fieldOutputRequests['F-Output-1'].setValues(variables=(
    'S', 'U', 'PE', 'PEEQ', 'SDEG', 'NT', 'STATUS'), numIntervals=10)
mod.historyOutputRequests['H-Output-1'].setValues(
    numIntervals=10, variables=('CFTM', 'CFT1', 'CFT2', 'CFT3'))
mod.steps['i0_Sub_step'].Restart(frequency=0, numberIntervals=1,
    overlay=ON, timeMarks=OFF)
## Interaction Properties ##
mod.ContactProperty('Frictionless')
mod.interactionProperties['Frictionless'].TangentialBehavior(
    formulation=FRICTIONLESS)
mod.interactionProperties['Frictionless'].NormalBehavior(
    allowSeparation=ON, constraintEnforcementMethod=DEFAULT,
    pressureOverclosure=HARD)
mod.ContactProperty('Friction')
mod.interactionProperties['Friction'].TangentialBehavior(
    dependencies=0, directionality=ISOTROPIC, elasticSlipStiffness=None,
    formulation=PENALTY, fraction=0.005, maximumElasticSlip=FRACTION,
    pressureDependency=OFF, shearStressLimit=None, slipRateDependency=OFF,
    table=((0.3, ), ), temperatureDependency=OFF)
mod.interactionProperties['Friction'].NormalBehavior(
    allowSeparation=ON, constraintEnforcementMethod=DEFAULT,
    pressureOverclosure=HARD)
## Create contact pair ##
modRa.Surface(name='CP-1-Plate-1-1', side1Faces=
    modRa.instances['Plate-1-1'].faces.findAt(((
    0.076953, 0.0015, 0.076635), ), ((0.081363, 0.0015, 0.081046), ), ((
    0.072997, 0.0015, 0.073466), ), ((0.069056, 0.0015, 0.068586), ), ((
    0.080944, 0.0015, 0.081414), ), ((0.076263, 0.0015, 0.077183), ), ((
    0.068586, 0.0015, 0.069056), ), ((0.073737, 0.0015, 0.072817), ), ))
modRa.Surface(name='CP-1-Plate-2-1', side1Faces=
    modRa.instances['Plate-2-1'].faces.findAt(((
    0.081414, 0.0015, 0.080944), ), ((0.076263, 0.0015, 0.077183), ), ((
    0.072997, 0.0015, 0.076534), ), ((0.080944, 0.0015, 0.068586), ), ((
    0.069056, 0.0015, 0.081414), ), ((0.073737, 0.0015, 0.072817), ), ((
    0.068586, 0.0015, 0.069056), ), ((0.076924, 0.0015, 0.073381), ), ))
modRa.Surface(name='CP-2-Plate-1-1', side1Faces=
    modRa.instances['Plate-1-1'].faces.findAt(((
    0.076915, -0.0005, 0.076607), ), ((0.073018, 0.0005, 0.073477), ), ((
    0.073477, -0.0005, 0.073018), ), ((0.076523, -0.0005, 0.076982), ), ))
modRa.Surface(name='CP-2-Screw-1', side1Faces=
    modRa.instances['Screw-1'].faces.findAt(((
    0.072514, -0.0015, 0.07526), ), ((0.07526, -0.0015, 0.077486), ), ((
    0.07526, 0.0005, 0.072514), ), ((0.072514, 0.0005, 0.07474), ), ))
modRa.Surface(name='CP-3-Screw-1', side1Faces=
    modRa.instances['Screw-1'].faces.findAt(((
    0.072514, -0.0015, 0.07526), ), ((0.07526, -0.0015, 0.077486), ), ((
    0.07526, 0.0005, 0.072514), ), ((0.072514, 0.0005, 0.07474), ), ))
modRa.Surface(name='CP-3-Plate-2-1', side1Faces=
    modRa.instances['Plate-2-1'].faces.findAt(((
    0.076915, 0.001833, 0.076607), ), ((0.073018, 0.002167, 0.073477), ), ((
    0.073477, 0.001833, 0.073018), ), ((0.076523, 0.001833, 0.076982), ), ))
modRa.Surface(name='CP-4-Plate-2-1', side1Faces=
    modRa.instances['Plate-2-1'].faces.findAt(((
    0.076953, 0.0025, 0.076635), ), ((0.081363, 0.0025, 0.081046), ), ((
    0.072997, 0.0025, 0.073466), ), ((0.069056, 0.0025, 0.068586), ), ((
    0.080944, 0.0025, 0.081414), ), ((0.076263, 0.0025, 0.077183), ), ((
    0.068586, 0.0025, 0.069056), ), ((0.073737, 0.0025, 0.072817), ), ))
modRa.Surface(name='CP-4-Screw-1', side1Faces=
    modRa.instances['Screw-1'].faces.findAt(((
    0.070875, 0.0025, 0.075371), ), ((0.075371, 0.0025, 0.079125), ), ((
    0.075371, 0.0025, 0.070875), ), ((0.070875, 0.0025, 0.074629), ), ))
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE,
    interactionProperty='Frictionless', master=
    modRa.surfaces['CP-1-Plate-1-1'], name=
    'CP-1-Plate-1-1-Plate-2-1', slave=
    modRa.surfaces['CP-1-Plate-2-1'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE,
    interactionProperty='Frictionless', master=
    modRa.surfaces['CP-2-Plate-1-1'], name=
    'CP-2-Plate-1-1-Screw-1', slave=
    modRa.surfaces['CP-2-Screw-1'], sliding=FINITE
    , surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE,
    interactionProperty='Friction', master=
    modRa.surfaces['CP-3-Screw-1'], name=
    'CP-3-Screw-1-Plate-2-1', slave=
    modRa.surfaces['CP-3-Plate-2-1'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE,
    interactionProperty='Frictionless', master=
    modRa.surfaces['CP-4-Plate-2-1'], name=
    'CP-4-Plate-2-1-Screw-1', slave=
    modRa.surfaces['CP-4-Screw-1'], sliding=FINITE
    , surfaceSmoothing=AUTOMATIC)
## Thread contact ##
modRa.Surface(name='Plate-inner-surf', side1Faces=
    modRa.instances['Plate-1-1'].faces.findAt(((
    0.076991, 0.0005, 0.076672), ), ((0.076584, -0.0005, 0.077062), ), ((
    0.072938, -0.0005, 0.076584), ), ((0.073416, -0.0005, 0.072938), ), ))
modRa.Set(faces=
    modRa.instances['Screw-1'].faces.findAt(((
    0.072514, -0.0018, 0.07526), ), ((0.07526, -0.0018, 0.077486), ), ((
    0.07526, 0.0002, 0.072514), ), ((0.072514, 0.0002, 0.07474), ), ), name=
    'Screw-thread-surf')
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    clearanceRegion=
    modRa.sets['Screw-thread-surf'],
    createStepName='Initial', enforcement=NODE_TO_SURFACE, datumAxis=
    modRa.instances['Screw-1'].datums[1],
    halfThreadAngle=-30.0, initialClearance=0.0, interactionProperty='Friction'
    , majorBoltDiameter=5.0, master=
    modRa.surfaces['Plate-inner-surf'],
    meanBoltDiameter=COMPUTED, name='Thread-contact', pitch=2.0, slave=
    modRa.sets['Screw-thread-surf'], sliding=
    SMALL, thickness=ON, useReverseDatumAxis=OFF)
### BC ###
# Find global-scale model #
mod.setValues(globalJob='i0_SR-Job', shellToSolid=ON)
## Submodel BC ##
modRa.regenerate()
mod.parts['Plate-2'].Set(name='Set-sub-plate', nodes=
    mod.parts['Plate-2'].nodes[8:9]+\
    mod.parts['Plate-2'].nodes[11:13]+\
    mod.parts['Plate-2'].nodes[18:20]+\
    mod.parts['Plate-2'].nodes[22:24]+\
    mod.parts['Plate-2'].nodes[33:34]+\
    mod.parts['Plate-2'].nodes[78:80]+\
    mod.parts['Plate-2'].nodes[101:110]+\
    mod.parts['Plate-2'].nodes[116:118]+\
    mod.parts['Plate-2'].nodes[142:148]+\
    mod.parts['Plate-2'].nodes[156:160]+\
    mod.parts['Plate-2'].nodes[181:187]+\
    mod.parts['Plate-2'].nodes[213:215]+\
    mod.parts['Plate-2'].nodes[217:220]+\
    mod.parts['Plate-2'].nodes[286:292]+\
    mod.parts['Plate-2'].nodes[406:412]+\
    mod.parts['Plate-2'].nodes[531:543]+\
    mod.parts['Plate-2'].nodes[648:654])
mod.parts['Plate-1'].Set(name='Set-sub-frame', nodes=
    mod.parts['Plate-1'].nodes[15:18]+\
    mod.parts['Plate-1'].nodes[20:22]+\
    mod.parts['Plate-1'].nodes[25:27]+\
    mod.parts['Plate-1'].nodes[34:35]+\
    mod.parts['Plate-1'].nodes[99:110]+\
    mod.parts['Plate-1'].nodes[129:131]+\
    mod.parts['Plate-1'].nodes[142:148]+\
    mod.parts['Plate-1'].nodes[172:176]+\
    mod.parts['Plate-1'].nodes[181:187]+\
    mod.parts['Plate-1'].nodes[215:220]+\
    mod.parts['Plate-1'].nodes[286:292]+\
    mod.parts['Plate-1'].nodes[406:412]+\
    mod.parts['Plate-1'].nodes[531:543]+\
    mod.parts['Plate-1'].nodes[648:654])
mod.SubmodelBC(absoluteExteriorTolerance=None,
    createStepName='i0_Sub_step', exteriorTolerance=0.05, globalDrivingRegion='',
    globalIncrement=0, globalStep='1', name='SubBC-plate', region=
    modRa.instances['Plate-2-1'].sets['Set-sub-plate']
    , shellThickness=0.001, timeScale=OFF)
mod.SubmodelBC(absoluteExteriorTolerance=None,
    createStepName='i0_Sub_step', exteriorTolerance=0.05, globalDrivingRegion='',
    globalIncrement=0, globalStep='1', name='SubBC-frame', region=
    modRa.instances['Plate-1-1'].sets['Set-sub-frame']
    , shellThickness=0.004, timeScale=OFF)
modRa.regenerate()
## Create wire for tension ##
modRa.WirePolyLine(mergeType=IMPRINT, meshable=OFF
    , points=((
    modRa.instances['Screw-1'].vertices.findAt((
    0.08, 0.0065, 0.075), ),
    modRa.instances['Screw-1'].vertices.findAt((
    0.0775, -0.0035, 0.075), )), (
    modRa.instances['Screw-1'].vertices.findAt((
    0.075, 0.0065, 0.08), ),
    modRa.instances['Screw-1'].vertices.findAt((
    0.075, -0.0035, 0.0775), )), (
    modRa.instances['Screw-1'].vertices.findAt((
    0.07, 0.0065, 0.075), ),
    modRa.instances['Screw-1'].vertices.findAt((
    0.0725, -0.0035, 0.075), )), (
    modRa.instances['Screw-1'].vertices.findAt((
    0.075, 0.0065, 0.07), ),
    modRa.instances['Screw-1'].vertices.findAt((
    0.075, -0.0035, 0.0725), ))))
modRa.Set(edges=
    modRa.edges.findAt(((0.075, 0.004, 0.070625),
    ), ((0.070625, 0.004, 0.075), ), ((0.075, 0.004, 0.079375), ), ((0.079375,
    0.004, 0.075), ), ), name='Wire-1-Set-1')
## Create wire for shearing ##
# Create shearing in 1-direction #
modRa.WirePolyLine(mergeType=IMPRINT, meshable=OFF
    , points=((
    modRa.instances['Plate-2-1'].vertices.findAt((
    0.09, 0.0025, 0.075), ),
    modRa.instances['Plate-1-1'].vertices.findAt((
    0.09, -0.0015, 0.075), )), (
    modRa.instances['Plate-2-1'].vertices.findAt((
    0.06, 0.0025, 0.075), ),
    modRa.instances['Plate-1-1'].vertices.findAt((
    0.06, -0.0015, 0.075), ))))
modRa.Set(edges=
    modRa.edges.findAt(((0.06, 0.0015, 0.075), ),
    ((0.09, 0.0015, 0.075), ), ), name='Wire-2-Set-1')
# Create shearing in 3-direction #
modRa.WirePolyLine(mergeType=IMPRINT, meshable=OFF
    , points=((
    modRa.instances['Plate-2-1'].vertices.findAt((
    0.075, 0.0025, 0.06), ),
    modRa.instances['Plate-1-1'].vertices.findAt((
    0.075, -0.0015, 0.06), )), (
    modRa.instances['Plate-2-1'].vertices.findAt((
    0.075, 0.0025, 0.09), ),
    modRa.instances['Plate-1-1'].vertices.findAt((
    0.075, -0.0015, 0.09), ))))
modRa.Set(edges=
    modRa.edges.findAt(((0.075, 0.0015, 0.09), ),
    ((0.075, 0.0015, 0.06), ), ), name='Wire-3-Set-1')
## Create element sets for monitor ##
modRa.Set(elements=
    modRa.instances['Plate-1-1'].elements[0:16]+\
    modRa.instances['Plate-1-1'].elements[24:25]+\
    modRa.instances['Plate-1-1'].elements[33:34]+\
    modRa.instances['Plate-1-1'].elements[42:43]+\
    modRa.instances['Plate-1-1'].elements[51:52]+\
    modRa.instances['Plate-1-1'].elements[60:61]+\
    modRa.instances['Plate-1-1'].elements[69:70]+\
    modRa.instances['Plate-1-1'].elements[78:79]+\
    modRa.instances['Plate-1-1'].elements[87:88]+\
    modRa.instances['Plate-1-1'].elements[96:97]+\
    modRa.instances['Plate-1-1'].elements[105:106]+\
    modRa.instances['Plate-1-1'].elements[114:115]+\
    modRa.instances['Plate-1-1'].elements[123:124]+\
    modRa.instances['Plate-1-1'].elements[132:133]+\
    modRa.instances['Plate-1-1'].elements[141:142]+\
    modRa.instances['Plate-1-1'].elements[150:151]+\
    modRa.instances['Plate-1-1'].elements[159:161]+\
    modRa.instances['Plate-1-1'].elements[169:170]+\
    modRa.instances['Plate-1-1'].elements[178:179]+\
    modRa.instances['Plate-1-1'].elements[187:188]+\
    modRa.instances['Plate-1-1'].elements[196:197]+\
    modRa.instances['Plate-1-1'].elements[205:206]+\
    modRa.instances['Plate-1-1'].elements[214:215]+\
    modRa.instances['Plate-1-1'].elements[223:224]+\
    modRa.instances['Plate-1-1'].elements[232:233]+\
    modRa.instances['Plate-1-1'].elements[241:242]+\
    modRa.instances['Plate-1-1'].elements[250:251]+\
    modRa.instances['Plate-1-1'].elements[259:260]+\
    modRa.instances['Plate-1-1'].elements[268:269]+\
    modRa.instances['Plate-1-1'].elements[277:278]+\
    modRa.instances['Plate-1-1'].elements[286:287]+\
    modRa.instances['Plate-1-1'].elements[295:296]+\
    modRa.instances['Plate-1-1'].elements[304:305]+\
    modRa.instances['Plate-1-1'].elements[313:314]+\
    modRa.instances['Plate-1-1'].elements[322:323]+\
    modRa.instances['Plate-1-1'].elements[331:332]+\
    modRa.instances['Plate-1-1'].elements[340:341]+\
    modRa.instances['Plate-1-1'].elements[349:350]+\
    modRa.instances['Plate-1-1'].elements[358:359]+\
    modRa.instances['Plate-1-1'].elements[367:368]+\
    modRa.instances['Plate-1-1'].elements[376:377]+\
    modRa.instances['Plate-1-1'].elements[385:386]+\
    modRa.instances['Plate-1-1'].elements[394:395]+\
    modRa.instances['Plate-1-1'].elements[403:404]+\
    modRa.instances['Plate-1-1'].elements[412:413]+\
    modRa.instances['Plate-1-1'].elements[421:422]+\
    modRa.instances['Plate-1-1'].elements[430:431]+\
    modRa.instances['Plate-1-1'].elements[439:440]+\
    modRa.instances['Plate-1-1'].elements[448:449]+\
    modRa.instances['Plate-1-1'].elements[457:458]+\
    modRa.instances['Plate-1-1'].elements[466:467]+\
    modRa.instances['Plate-1-1'].elements[475:476]+\
    modRa.instances['Plate-1-1'].elements[484:485]+\
    modRa.instances['Plate-1-1'].elements[493:494]+\
    modRa.instances['Plate-1-1'].elements[502:503]+\
    modRa.instances['Plate-1-1'].elements[511:512]+\
    modRa.instances['Plate-1-1'].elements[520:576]+\
    modRa.instances['Plate-1-1'].elements[584:585]+\
    modRa.instances['Plate-1-1'].elements[593:594]+\
    modRa.instances['Plate-1-1'].elements[602:603]+\
    modRa.instances['Plate-1-1'].elements[611:612]+\
    modRa.instances['Plate-1-1'].elements[620:621]+\
    modRa.instances['Plate-1-1'].elements[629:630]+\
    modRa.instances['Plate-1-1'].elements[638:639]+\
    modRa.instances['Plate-1-1'].elements[647:648]+\
    modRa.instances['Plate-1-1'].elements[656:657]+\
    modRa.instances['Plate-1-1'].elements[665:666]+\
    modRa.instances['Plate-1-1'].elements[674:675]+\
    modRa.instances['Plate-1-1'].elements[683:684]+\
    modRa.instances['Plate-1-1'].elements[692:693]+\
    modRa.instances['Plate-1-1'].elements[701:702]+\
    modRa.instances['Plate-1-1'].elements[710:711]+\
    modRa.instances['Plate-1-1'].elements[719:720]
    , name='Set-Plate1_edge_elements')
modRa.Set(elements=
    modRa.instances['Plate-2-1'].elements[0:16]+\
    modRa.instances['Plate-2-1'].elements[24:25]+\
    modRa.instances['Plate-2-1'].elements[33:34]+\
    modRa.instances['Plate-2-1'].elements[42:43]+\
    modRa.instances['Plate-2-1'].elements[51:52]+\
    modRa.instances['Plate-2-1'].elements[60:61]+\
    modRa.instances['Plate-2-1'].elements[69:70]+\
    modRa.instances['Plate-2-1'].elements[78:79]+\
    modRa.instances['Plate-2-1'].elements[87:88]+\
    modRa.instances['Plate-2-1'].elements[96:97]+\
    modRa.instances['Plate-2-1'].elements[105:106]+\
    modRa.instances['Plate-2-1'].elements[114:115]+\
    modRa.instances['Plate-2-1'].elements[123:124]+\
    modRa.instances['Plate-2-1'].elements[132:133]+\
    modRa.instances['Plate-2-1'].elements[141:142]+\
    modRa.instances['Plate-2-1'].elements[150:151]+\
    modRa.instances['Plate-2-1'].elements[159:161]+\
    modRa.instances['Plate-2-1'].elements[169:170]+\
    modRa.instances['Plate-2-1'].elements[178:179]+\
    modRa.instances['Plate-2-1'].elements[187:188]+\
    modRa.instances['Plate-2-1'].elements[196:197]+\
    modRa.instances['Plate-2-1'].elements[205:206]+\
    modRa.instances['Plate-2-1'].elements[214:215]+\
    modRa.instances['Plate-2-1'].elements[223:224]+\
    modRa.instances['Plate-2-1'].elements[232:233]+\
    modRa.instances['Plate-2-1'].elements[241:242]+\
    modRa.instances['Plate-2-1'].elements[250:251]+\
    modRa.instances['Plate-2-1'].elements[259:260]+\
    modRa.instances['Plate-2-1'].elements[268:269]+\
    modRa.instances['Plate-2-1'].elements[277:278]+\
    modRa.instances['Plate-2-1'].elements[286:287]+\
    modRa.instances['Plate-2-1'].elements[295:296]+\
    modRa.instances['Plate-2-1'].elements[304:305]+\
    modRa.instances['Plate-2-1'].elements[313:314]+\
    modRa.instances['Plate-2-1'].elements[322:323]+\
    modRa.instances['Plate-2-1'].elements[331:332]+\
    modRa.instances['Plate-2-1'].elements[340:341]+\
    modRa.instances['Plate-2-1'].elements[349:350]+\
    modRa.instances['Plate-2-1'].elements[358:359]+\
    modRa.instances['Plate-2-1'].elements[367:368]+\
    modRa.instances['Plate-2-1'].elements[376:377]+\
    modRa.instances['Plate-2-1'].elements[385:386]+\
    modRa.instances['Plate-2-1'].elements[394:395]+\
    modRa.instances['Plate-2-1'].elements[403:404]+\
    modRa.instances['Plate-2-1'].elements[412:413]+\
    modRa.instances['Plate-2-1'].elements[421:422]+\
    modRa.instances['Plate-2-1'].elements[430:431]+\
    modRa.instances['Plate-2-1'].elements[439:440]+\
    modRa.instances['Plate-2-1'].elements[448:449]+\
    modRa.instances['Plate-2-1'].elements[457:458]+\
    modRa.instances['Plate-2-1'].elements[466:467]+\
    modRa.instances['Plate-2-1'].elements[475:476]+\
    modRa.instances['Plate-2-1'].elements[484:485]+\
    modRa.instances['Plate-2-1'].elements[493:494]+\
    modRa.instances['Plate-2-1'].elements[502:503]+\
    modRa.instances['Plate-2-1'].elements[511:512]+\
    modRa.instances['Plate-2-1'].elements[520:576]+\
    modRa.instances['Plate-2-1'].elements[584:585]+\
    modRa.instances['Plate-2-1'].elements[593:594]+\
    modRa.instances['Plate-2-1'].elements[602:603]+\
    modRa.instances['Plate-2-1'].elements[611:612]+\
    modRa.instances['Plate-2-1'].elements[620:621]+\
    modRa.instances['Plate-2-1'].elements[629:630]+\
    modRa.instances['Plate-2-1'].elements[638:639]+\
    modRa.instances['Plate-2-1'].elements[647:648]+\
    modRa.instances['Plate-2-1'].elements[656:657]+\
    modRa.instances['Plate-2-1'].elements[665:666]+\
    modRa.instances['Plate-2-1'].elements[674:675]+\
    modRa.instances['Plate-2-1'].elements[683:684]+\
    modRa.instances['Plate-2-1'].elements[692:693]+\
    modRa.instances['Plate-2-1'].elements[701:702]+\
    modRa.instances['Plate-2-1'].elements[710:711]+\
    modRa.instances['Plate-2-1'].elements[719:720]
    , name='Set-Plate2_edge_elements')
modRa.Set(elements=
    modRa.instances['Screw-1'].elements[0:336],
    name='Set-Bolt_edge_elements')
## Create set for temperature assignment ##
modRa.Set(cells=
    modRa.instances['Plate-1-1'].cells.findAt(((
    0.076263, -0.0015, 0.077183), ), ((0.069056, 0.0015, 0.068586), ), ((
    0.068586, 0.0015, 0.069056), ), ((0.081363, 0.0015, 0.081046), ), ((
    0.076924, -0.0015, 0.073381), ), ((0.073018, 0.0005, 0.073477), ), ((
    0.073477, -0.0005, 0.073018), ), ((0.080944, 0.0015, 0.081414), ), )+\
    modRa.instances['Plate-2-1'].cells.findAt(((
    0.076263, 0.0015, 0.077183), ), ((0.069056, 0.0025, 0.068586), ), ((
    0.068586, 0.0025, 0.069056), ), ((0.081363, 0.0025, 0.081046), ), ((
    0.076924, 0.0015, 0.073381), ), ((0.073018, 0.002167, 0.073477), ), ((
    0.073477, 0.001833, 0.073018), ), ((0.080944, 0.0025, 0.081414), ), )+\
    modRa.instances['Screw-1'].cells.findAt(((
    0.076626, -0.0035, 0.075258), ), ((0.078292, 0.0065, 0.075371), ), ((
    0.070875, 0.0025, 0.075371), ), ((0.073374, -0.0035, 0.075258), ), ((
    0.073374, -0.0035, 0.074742), ), ((0.070875, 0.0025, 0.074629), ), ((
    0.075371, 0.0025, 0.070875), ), ((0.076626, -0.0035, 0.074742), ), ),
    edges=
    modRa.instances['Plate-1-1'].edges.findAt(((
    0.09, -0.00075, 0.075), ), ((0.09, -0.0015, 0.06375), ), ((0.09, -0.00075,
    0.06), ), ((0.09, 0.0015, 0.06375), ), ((0.075, -0.00075, 0.09), ), ((
    0.08625, -0.0015, 0.09), ), ((0.09, -0.00075, 0.09), ), ((0.08625, 0.0015,
    0.09), ), ((0.06, -0.00075, 0.075), ), ((0.06, -0.0015, 0.08625), ), ((
    0.06, -0.00075, 0.09), ), ((0.06, 0.0015, 0.08625), ), ((0.075, -0.00075,
    0.06), ), ((0.06375, -0.0015, 0.06), ), ((0.06, -0.00075, 0.06), ), ((
    0.06375, 0.0015, 0.06), ), ((0.076838, -0.00075, 0.076838), ), ((0.077162,
    0.0015, 0.076444), ), ((0.07755, 0.0015, 0.074493), ), ((0.076838,
    -0.00075, 0.073162), ), ((0.077402, -0.0015, 0.074005), ), ((0.075995,
    -0.0015, 0.077402), ), ((0.073162, 0.00075, 0.076838), ), ((0.074005,
    0.0015, 0.077402), ), ((0.072598, -0.0015, 0.075995), ), ((0.073162,
    0.00075, 0.073162), ), ((0.072598, 0.0015, 0.074005), ), ((0.074005,
    -0.0015, 0.072598), ), ((0.075995, 0.0015, 0.072598), ), ((0.080129,
    -0.0015, 0.069871), ), ((0.09, -0.0015, 0.07875), ), ((0.080129, -0.0015,
    0.080129), ), ((0.073179, -0.0015, 0.076821), ), ((0.074043, -0.0015,
    0.07731), ), ((0.076785, -0.0015, 0.076785), ), ((0.076821, 0.0015,
    0.076821), ), ((0.076768, 0.00075, 0.076768), ), ((0.08671, 0.0015,
    0.06329), ), ((0.069871, 0.0015, 0.080129), ), ((0.06329, -0.0015,
    0.08671), ), ((0.073179, -0.0015, 0.073179), ), ((0.07269, -0.0015,
    0.074043), ), ((0.06329, -0.0015, 0.06329), ), ((0.07875, -0.0015, 0.06),
    ), ((0.069871, 0.0015, 0.069871), ), ((0.08671, 0.0015, 0.08671), ), ((
    0.073232, -0.00075, 0.073232), ), ((0.073215, 0.0015, 0.073215), ), ((
    0.07125, -0.0015, 0.09), ), ((0.077079, 0.0015, 0.076389), ), ((0.077452,
    0.0015, 0.074512), ), ((0.076768, 0.00075, 0.073232), ), ((0.077452,
    -0.0015, 0.074512), ), ((0.077079, -0.0015, 0.076389), ), ((0.076821,
    0.0015, 0.073179), ), ((0.09, 0.0015, 0.07875), ), ((0.07269, 0.0015,
    0.074043), ), ((0.073232, -0.00075, 0.076768), ), ((0.076785, -0.0015,
    0.073215), ), ((0.075957, -0.0015, 0.07269), ), ((0.073215, 0.0015,
    0.076785), ), ((0.07875, 0.0015, 0.06), ), ((0.07125, 0.0015, 0.09), ), ((
    0.074043, 0.0015, 0.07731), ), ((0.06, -0.0015, 0.07125), ), ((0.075957,
    0.0015, 0.07269), ), ((0.06, 0.0015, 0.07125), ), )+\
    modRa.instances['Plate-2-1'].edges.findAt(((
    0.09, 0.00175, 0.075), ), ((0.09, 0.0015, 0.06375), ), ((0.09, 0.00175,
    0.06), ), ((0.09, 0.0025, 0.06375), ), ((0.075, 0.00175, 0.09), ), ((
    0.08625, 0.0015, 0.09), ), ((0.09, 0.00175, 0.09), ), ((0.08625, 0.0025,
    0.09), ), ((0.06, 0.00175, 0.075), ), ((0.06, 0.0015, 0.08625), ), ((0.06,
    0.00175, 0.09), ), ((0.06, 0.0025, 0.08625), ), ((0.075, 0.00175, 0.06), ),
    ((0.06375, 0.0015, 0.06), ), ((0.06, 0.00175, 0.06), ), ((0.06375, 0.0025,
    0.06), ), ((0.076838, 0.00175, 0.076838), ), ((0.077162, 0.0025, 0.076444),
    ), ((0.07755, 0.0025, 0.074493), ), ((0.076838, 0.00175, 0.073162), ), ((
    0.077402, 0.0015, 0.074005), ), ((0.075995, 0.0015, 0.077402), ), ((
    0.073162, 0.00225, 0.076838), ), ((0.074005, 0.0025, 0.077402), ), ((
    0.072598, 0.0015, 0.075995), ), ((0.073162, 0.00225, 0.073162), ), ((
    0.072598, 0.0025, 0.074005), ), ((0.074005, 0.0015, 0.072598), ), ((
    0.075995, 0.0025, 0.072598), ), ((0.080129, 0.0015, 0.069871), ), ((0.09,
    0.0015, 0.07875), ), ((0.080129, 0.0015, 0.080129), ), ((0.073179, 0.0015,
    0.076821), ), ((0.074043, 0.0015, 0.07731), ), ((0.076785, 0.0015,
    0.076785), ), ((0.076821, 0.0025, 0.076821), ), ((0.076768, 0.00225,
    0.076768), ), ((0.08671, 0.0025, 0.06329), ), ((0.069871, 0.0025,
    0.080129), ), ((0.06329, 0.0015, 0.08671), ), ((0.073179, 0.0015,
    0.073179), ), ((0.07269, 0.0015, 0.074043), ), ((0.06329, 0.0015, 0.06329),
    ), ((0.07875, 0.0015, 0.06), ), ((0.069871, 0.0025, 0.069871), ), ((
    0.08671, 0.0025, 0.08671), ), ((0.073232, 0.00175, 0.073232), ), ((
    0.073215, 0.0025, 0.073215), ), ((0.07125, 0.0015, 0.09), ), ((0.077079,
    0.0025, 0.076389), ), ((0.077452, 0.0025, 0.074512), ), ((0.076768,
    0.00225, 0.073232), ), ((0.077452, 0.0015, 0.074512), ), ((0.077079,
    0.0015, 0.076389), ), ((0.076821, 0.0025, 0.073179), ), ((0.09, 0.0025,
    0.07875), ), ((0.07269, 0.0025, 0.074043), ), ((0.073232, 0.00175,
    0.076768), ), ((0.076785, 0.0015, 0.073215), ), ((0.075957, 0.0015,
    0.07269), ), ((0.073215, 0.0025, 0.076785), ), ((0.07875, 0.0025, 0.06), ),
    ((0.07125, 0.0025, 0.09), ), ((0.074043, 0.0025, 0.07731), ), ((0.06,
    0.0015, 0.07125), ), ((0.075957, 0.0025, 0.07269), ), ((0.06, 0.0025,
    0.07125), ), )+\
    modRa.instances['Screw-1'].edges.findAt(((
    0.076875, 0.0025, 0.075), ), ((0.075, 0.0035, 0.075), ), ((0.07625, 0.0065,
    0.075), ), ((0.08, 0.0055, 0.075), ), ((0.079375, 0.0025, 0.075), ), ((
    0.075, -0.002, 0.075), ), ((0.0775, 0.001, 0.075), ), ((0.076875, -0.0035,
    0.075), ), ((0.074375, 0.0025, 0.075), ), ((0.074375, -0.0035, 0.075), ), (
    (0.0725, -0.002, 0.075), ), ((0.07, 0.0035, 0.075), ), ((0.07125, 0.0065,
    0.075), ), ((0.071875, 0.0025, 0.075), ), ((0.074043, 0.0025, 0.07731), ),
    ((0.075, 0.0025, 0.078125), ), ((0.073087, 0.0025, 0.079619), ), ((
    0.070381, 0.0065, 0.073087), ), ((0.075, 0.0055, 0.07), ), ((0.070381,
    0.0025, 0.073087), ), ((0.074043, -0.0035, 0.07731), ), ((0.075, -0.002,
    0.0775), ), ((0.075, 0.0025, 0.075625), ), ((0.075, -0.0035, 0.075625), ),
    ((0.075, 0.0065, 0.07375), ), ((0.07731, -0.0035, 0.075957), ), ((0.075,
    0.0025, 0.073125), ), ((0.075, 0.001, 0.0725), ), ((0.075, -0.0035,
    0.073125), ), ((0.076913, 0.0065, 0.070381), ), ((0.075, 0.0035, 0.08), ),
    ((0.075, 0.0065, 0.07875), ), ((0.07731, 0.0025, 0.075957), ), ((0.075,
    0.0025, 0.070625), ), ((0.07269, -0.0035, 0.074043), ), ((0.075957, 0.0025,
    0.07269), ), ((0.075957, -0.0035, 0.07269), ), ((0.07269, 0.0025,
    0.074043), ), ((0.079619, 0.0025, 0.076913), ), ((0.076913, 0.0025,
    0.070381), ), ((0.079619, 0.0065, 0.076913), ), ((0.073087, 0.0065,
    0.079619), ), ), faces=
    modRa.instances['Plate-1-1'].faces.findAt(((
    0.09, -0.0005, 0.07), ), ((0.08, -0.0005, 0.09), ), ((0.06, -0.0005, 0.08),
    ), ((0.07, -0.0005, 0.06), ), ((0.076991, 0.0005, 0.076672), ), ((0.076584,
    -0.0005, 0.077062), ), ((0.072938, -0.0005, 0.076584), ), ((0.073416,
    -0.0005, 0.072938), ), ((0.081414, -0.0015, 0.080944), ), ((0.076263,
    -0.0015, 0.077183), ), ((0.076815, -0.0005, 0.076815), ), ((0.081226,
    0.0005, 0.068774), ), ((0.068774, -0.0005, 0.081226), ), ((0.072997,
    -0.0015, 0.076534), ), ((0.080944, -0.0015, 0.068586), ), ((0.068774,
    -0.0005, 0.068774), ), ((0.081226, 0.0005, 0.081226), ), ((0.073185,
    0.0005, 0.073185), ), ((0.069056, -0.0015, 0.081414), ), ((0.076915,
    -0.0005, 0.076607), ), ((0.076953, 0.0015, 0.076635), ), ((0.081363,
    0.0015, 0.081046), ), ((0.073018, 0.0005, 0.073477), ), ((0.073737,
    -0.0015, 0.072817), ), ((0.072997, 0.0015, 0.073466), ), ((0.069056,
    0.0015, 0.068586), ), ((0.076815, -0.0005, 0.073185), ), ((0.073185,
    0.0005, 0.076815), ), ((0.080944, 0.0015, 0.081414), ), ((0.076263, 0.0015,
    0.077183), ), ((0.068586, -0.0015, 0.069056), ), ((0.073477, -0.0005,
    0.073018), ), ((0.068586, 0.0015, 0.069056), ), ((0.06, 0.0005, 0.07), ), (
    (0.08, 0.0005, 0.06), ), ((0.09, 0.0005, 0.08), ), ((0.07, 0.0005, 0.09),
    ), ((0.076523, -0.0005, 0.076982), ), ((0.073737, 0.0015, 0.072817), ), ((
    0.076924, -0.0015, 0.073381), ), )+\
    modRa.instances['Plate-2-1'].faces.findAt(((
    0.09, 0.001833, 0.07), ), ((0.08, 0.001833, 0.09), ), ((0.06, 0.001833,
    0.08), ), ((0.07, 0.001833, 0.06), ), ((0.076991, 0.002167, 0.076672), ), (
    (0.076584, 0.001833, 0.077062), ), ((0.072938, 0.001833, 0.076584), ), ((
    0.073416, 0.001833, 0.072938), ), ((0.081414, 0.0015, 0.080944), ), ((
    0.076263, 0.0015, 0.077183), ), ((0.076815, 0.001833, 0.076815), ), ((
    0.081226, 0.002167, 0.068774), ), ((0.068774, 0.001833, 0.081226), ), ((
    0.072997, 0.0015, 0.076534), ), ((0.080944, 0.0015, 0.068586), ), ((
    0.068774, 0.001833, 0.068774), ), ((0.081226, 0.002167, 0.081226), ), ((
    0.073185, 0.002167, 0.073185), ), ((0.069056, 0.0015, 0.081414), ), ((
    0.076915, 0.001833, 0.076607), ), ((0.076953, 0.0025, 0.076635), ), ((
    0.081363, 0.0025, 0.081046), ), ((0.073018, 0.002167, 0.073477), ), ((
    0.073737, 0.0015, 0.072817), ), ((0.072997, 0.0025, 0.073466), ), ((
    0.069056, 0.0025, 0.068586), ), ((0.076815, 0.001833, 0.073185), ), ((
    0.073185, 0.002167, 0.076815), ), ((0.080944, 0.0025, 0.081414), ), ((
    0.076263, 0.0025, 0.077183), ), ((0.068586, 0.0015, 0.069056), ), ((
    0.073477, 0.001833, 0.073018), ), ((0.068586, 0.0025, 0.069056), ), ((0.06,
    0.002167, 0.07), ), ((0.08, 0.002167, 0.06), ), ((0.09, 0.002167, 0.08), ),
    ((0.07, 0.002167, 0.09), ), ((0.076523, 0.001833, 0.076982), ), ((0.073737,
    0.0025, 0.072817), ), ((0.076924, 0.0015, 0.073381), ), )+\
    modRa.instances['Screw-1'].faces.findAt(((
    0.075833, 0.003833, 0.075), ), ((0.075833, 0.0005, 0.075), ), ((0.073333,
    0.0005, 0.075), ), ((0.070833, 0.003833, 0.075), ), ((0.070875, 0.0025,
    0.075371), ), ((0.070014, 0.005167, 0.074627), ), ((0.072514, -0.0015,
    0.07526), ), ((0.073374, 0.0025, 0.075258), ), ((0.073374, -0.0035,
    0.075258), ), ((0.071708, 0.0065, 0.074629), ), ((0.076626, -0.0035,
    0.075258), ), ((0.075, 0.0005, 0.074167), ), ((0.078292, 0.0065, 0.074629),
    ), ((0.075, 0.003833, 0.075833), ), ((0.076626, 0.0025, 0.075258), ), ((
    0.075, -0.0015, 0.075833), ), ((0.075, 0.003833, 0.074167), ), ((0.073374,
    -0.0035, 0.074742), ), ((0.07526, -0.0015, 0.077486), ), ((0.07526, 0.0005,
    0.072514), ), ((0.073374, 0.0025, 0.074742), ), ((0.075371, 0.0025,
    0.079125), ), ((0.075371, 0.0025, 0.070875), ), ((0.075373, 0.003833,
    0.079986), ), ((0.075373, 0.005167, 0.070014), ), ((0.078292, 0.0065,
    0.075371), ), ((0.076626, 0.0025, 0.074742), ), ((0.071708, 0.0065,
    0.075371), ), ((0.070014, 0.003833, 0.075373), ), ((0.070875, 0.0025,
    0.074629), ), ((0.072514, 0.0005, 0.07474), ), ((0.076626, -0.0035,
    0.074742), ), ), name='Set-temp-surf', vertices=
    modRa.instances['Plate-1-1'].vertices.findAt((
    (0.09, 0.0015, 0.075), ), ((0.09, -0.0015, 0.075), ), ((0.09, -0.0015,
    0.06), ), ((0.09, 0.0015, 0.06), ), ((0.075, 0.0015, 0.09), ), ((0.075,
    -0.0015, 0.09), ), ((0.09, -0.0015, 0.09), ), ((0.09, 0.0015, 0.09), ), ((
    0.06, 0.0015, 0.075), ), ((0.06, -0.0015, 0.075), ), ((0.06, -0.0015,
    0.09), ), ((0.06, 0.0015, 0.09), ), ((0.075, 0.0015, 0.06), ), ((0.075,
    -0.0015, 0.06), ), ((0.06, -0.0015, 0.06), ), ((0.06, 0.0015, 0.06), ), ((
    0.076838, -0.0015, 0.076838), ), ((0.076838, 0.0015, 0.076838), ), ((
    0.0776, 0.0015, 0.075), ), ((0.076838, 0.0015, 0.073162), ), ((0.076838,
    -0.0015, 0.073162), ), ((0.073162, -0.0015, 0.076838), ), ((0.073162,
    0.0015, 0.076838), ), ((0.073162, -0.0015, 0.073162), ), ((0.073162,
    0.0015, 0.073162), ), ((0.073232, -0.0015, 0.076768), ), ((0.076768,
    -0.0015, 0.076768), ), ((0.076768, 0.0015, 0.076768), ), ((0.073232,
    -0.0015, 0.073232), ), ((0.073232, 0.0015, 0.073232), ), ((0.0775, 0.0015,
    0.075), ), ((0.076768, 0.0015, 0.073232), ), ((0.076768, -0.0015,
    0.073232), ), ((0.0775, -0.0015, 0.075), ), ((0.073232, 0.0015, 0.076768),
    ), )+\
    modRa.instances['Plate-2-1'].vertices.findAt((
    (0.09, 0.0025, 0.075), ), ((0.09, 0.0015, 0.075), ), ((0.09, 0.0015, 0.06),
    ), ((0.09, 0.0025, 0.06), ), ((0.075, 0.0025, 0.09), ), ((0.075, 0.0015,
    0.09), ), ((0.09, 0.0015, 0.09), ), ((0.09, 0.0025, 0.09), ), ((0.06,
    0.0025, 0.075), ), ((0.06, 0.0015, 0.075), ), ((0.06, 0.0015, 0.09), ), ((
    0.06, 0.0025, 0.09), ), ((0.075, 0.0025, 0.06), ), ((0.075, 0.0015, 0.06),
    ), ((0.06, 0.0015, 0.06), ), ((0.06, 0.0025, 0.06), ), ((0.076838, 0.0015,
    0.076838), ), ((0.076838, 0.0025, 0.076838), ), ((0.0776, 0.0025, 0.075),
    ), ((0.076838, 0.0025, 0.073162), ), ((0.076838, 0.0015, 0.073162), ), ((
    0.073162, 0.0015, 0.076838), ), ((0.073162, 0.0025, 0.076838), ), ((
    0.073162, 0.0015, 0.073162), ), ((0.073162, 0.0025, 0.073162), ), ((
    0.073232, 0.0015, 0.076768), ), ((0.076768, 0.0015, 0.076768), ), ((
    0.076768, 0.0025, 0.076768), ), ((0.073232, 0.0015, 0.073232), ), ((
    0.073232, 0.0025, 0.073232), ), ((0.0775, 0.0025, 0.075), ), ((0.076768,
    0.0025, 0.073232), ), ((0.076768, 0.0015, 0.073232), ), ((0.0775, 0.0015,
    0.075), ), ((0.073232, 0.0025, 0.076768), ), )+\
    modRa.instances['Screw-1'].vertices.findAt(((
    0.0775, 0.0025, 0.075), ), ((0.075, 0.0025, 0.075), ), ((0.075, 0.0065,
    0.075), ), ((0.08, 0.0065, 0.075), ), ((0.08, 0.0025, 0.075), ), ((0.075,
    -0.0035, 0.075), ), ((0.0775, -0.0035, 0.075), ), ((0.0725, 0.0025, 0.075),
    ), ((0.0725, -0.0035, 0.075), ), ((0.07, 0.0025, 0.075), ), ((0.07, 0.0065,
    0.075), ), ((0.075, 0.0025, 0.0775), ), ((0.075, 0.0025, 0.08), ), ((0.075,
    0.0065, 0.07), ), ((0.075, 0.0025, 0.07), ), ((0.075, -0.0035, 0.0775), ),
    ((0.075, 0.0025, 0.0725), ), ((0.075, -0.0035, 0.0725), ), ((0.075, 0.0065,
    0.08), ), ))
## Adjust location of the small-scale model ##
########### The following should be updated based on connection location ############
mdb.models['Model-1'].rootAssembly.translate(instanceList=('Plate-1-1',
    'Plate-2-1', 'Screw-1'), vector=(0.0, 0, 3.45))
########### The following should be updated based on connection location ############
# Import temperature amplitude from global-scale model #
# execfile(r'../i0_Connection1_temp.py', __main__.__dict__)
