import os, shutil
import glob
import pandas as pd
from subprocess import run
from sys import exit
import Multi_scale_functions as MSF


def Step_Number_Control(SegmentNumber, StepNumber):
############################################################
## This function record current Segement and step number  ##
## The file looks like:                                   ##
##                                                        ##
## 2 (Segment Number)                                     ##
## 1 (step Number)                                        ##
############################################################
    Iteration_log = open('_iteration.log', 'w')
    interation_record = f'{SegmentNumber} \n{StepNumber}'
    Iteration_log.writelines(interation_record)
    Iteration_log.close()
    print(f'Now running Segment {SegmentNumber}, step {StepNumber}: \n')


def HTupdate(stepNumber, stepTime):
############################################################
## This function update the heat transfer model, the      ##
## temperature data is from FDS model AST temperature     ##
## files. The output.odb is using for the subsequent SR   ##
## analysis.                                              ##
##                                                        ##
## Require: HT_basicModel.py                              ##
##          AST_Amp_data.py                               ##
##          i{stepNumber-1}_HT-Job.odb                    ##
##          _iteration.log                                ##
##                                                        ##
## Output: i{stepNumber}_HT-Job.py                        ##
##         i{stepNumber}_HT-Job.odb                       ##
##                                                        ##
############################################################
    try:
        basicFile=open('HT_basicModel.py', 'r')
    except:
        print('HT_basicModel.py not exist!!!')
        exit(0)
    data = basicFile.readlines()
    basicFile.close()
    ## Name the previous model ##
    odb_step_name = f'i{stepNumber}_HT-step'
    odb_file_name = f'i{stepNumber}_HT-Job'
    pre_odb_step_name = f'i{stepNumber - 1}_HT-step'
    pre_odb_file_name = f'i{stepNumber - 1}_HT-Job'
    ## Create new script ##
    newscriptname = f"i{stepNumber}_HT-Job.py"
    file2 = open(newscriptname, 'w')
    file2.writelines(data)
    if stepNumber == 0 :
        # Append new script to this file #
        file2 = open(newscriptname, 'a')
        a = f'''
mod.steps['i0_HT-step'].setValues(timePeriod={stepTime})
############The following is additional lines to update HT script ############
## Create Job ##
mdb.Job(atTime=None, contactPrint=OFF, description='', echoPrint=OFF,
    explicitPrecision=SINGLE, getMemoryFromAnalysis=True, historyPrint=OFF,
    memory=90, memoryUnits=PERCENTAGE, model='Model-1', modelPrint=OFF,
    multiprocessingMode=DEFAULT, name='i0_HT-Job', nodalOutputPrecision=SINGLE,
    numCpus=2, numDomains=2, numGPUs=0, queue=None, resultsFormat=ODB, scratch=
    '', type=ANALYSIS, userSubroutine='', waitHours=0, waitMinutes=0)
'''
        file2.writelines(a)
        file2.close()
    elif stepNumber == 1:
        file2 = open(newscriptname, 'a')
        a = f'''
############The following is additional lines to update HT script ############
#no additional restart information is written since it is the initial (zero'th) iteration
### Update ConRad and AST Data ###
imp = mod.TabularAmplitude
execfile(r'..//AST_Amp_data.py', __main__.__dict__)
### Assign temperature ###
# Change name #
Panel_name = 1
Partition_number = 1
surface_number = 1
for Panel_name in range(1, 4):
    for Partition_number in range(1, 17):
        ### Change keys ###
        mod.amplitudes.changeKey(fromName='i0_AST_%s-%s'%(Panel_name, Partition_number), toName='i{stepNumber}_AST_%s-%s'%(Panel_name, Partition_number))
        ### Change radiation ###
        mod.RadiationToAmbient(name='Rad_%s-%s'%(Panel_name, Partition_number), createStepName='i0_HT-step',
            emissivity=0.8, ambientTemperature=1.0,
            ambientTemperatureAmp='i{stepNumber}_AST_%s-%s'%(Panel_name, Partition_number),
            surface=mod.rootAssembly.instances['Inner_plate-1'].surfaces['Surf-%s'%surface_number])
        ### change convection ###
        mod.FilmCondition(name='Conv_%s-%s'%(Panel_name, Partition_number), createStepName='i0_HT-step', definition=EMBEDDED_COEFF, filmCoeff=25,
                          sinkAmplitude='i{stepNumber}_AST_%s-%s'%(Panel_name, Partition_number), sinkTemperature=1.0,
                          surface=mod.rootAssembly.instances['Inner_plate-1'].surfaces['Surf-%s'%surface_number])
        Partition_number = Partition_number + 1
        surface_number = surface_number + 1
    Panel_name = Panel_name + 1
## Create New step ##
mod.setValues(restartJob='{pre_odb_file_name}', restartStep=
    '{pre_odb_step_name}')
mod.HeatTransferStep(deltmx=50.0, initialInc=1.0, maxInc=1.0, 
    maxNumInc=1000, minInc=5e-09, name='{odb_step_name}', previous='{pre_odb_step_name}', 
    timePeriod=5.0)
mod.steps['{odb_step_name}'].Restart(frequency=0, numberIntervals=
    1, overlay=ON, timeMarks=OFF)
mdb.Job(atTime=None, contactPrint=OFF, description='', echoPrint=OFF, 
    explicitPrecision=SINGLE, getMemoryFromAnalysis=True, historyPrint=OFF, 
    memory=90, memoryUnits=PERCENTAGE, model='Model-1', modelPrint=OFF, 
    multiprocessingMode=DEFAULT, name='{odb_file_name}', nodalOutputPrecision=SINGLE, 
    numCpus=2, numDomains=2, numGPUs=0, queue=None, resultsFormat=ODB, scratch=
    '', type=RESTART, userSubroutine='', waitHours=0, waitMinutes=0)
mod.steps['i1_HT-step'].setValues(timePeriod={stepTime})
## Remove initial buckling imperfection ##
mod.keywordBlock.synchVersions(storeNodesAndElements=False)
mod.keywordBlock.setValues(edited=0)
mod.keywordBlock.synchVersions(storeNodesAndElements=False)
        '''
        file2.writelines(a)
        file2.close()
    else:
        file2 = open(newscriptname, 'a')
### Mid step is needed for the following steps ###
        a = f'''
############The following is additional lines to update HT script ############
#no additional restart information is written since it is the initial (zero'th) iteration
### Update ConRad and AST Data ###
imp = mod.TabularAmplitude
execfile(r'..//AST_Amp_data.py', __main__.__dict__)
### Assign temperature ###
# Change name #
Panel_name = 1
Partition_number = 1
surface_number = 1
for Panel_name in range(1, 4):
    for Partition_number in range(1, 17):
        ### Change Keys ###
        mod.amplitudes.changeKey(fromName='i0_AST_%s-%s'%(Panel_name, Partition_number), toName='i{stepNumber}_AST_%s-%s'%(Panel_name, Partition_number))
        ### Change radiation ###
        mod.RadiationToAmbient(name='Rad_%s-%s'%(Panel_name, Partition_number), createStepName='i0_HT-step',
            emissivity=0.8, ambientTemperature=1.0,
            ambientTemperatureAmp='i{stepNumber}_AST_%s-%s'%(Panel_name, Partition_number),
            surface=mod.rootAssembly.instances['Inner_plate-1'].surfaces['Surf-%s'%surface_number])
        ### change convection ###
        mod.FilmCondition(name='Conv_%s-%s'%(Panel_name, Partition_number), createStepName='i0_HT-step', definition=EMBEDDED_COEFF, filmCoeff=25,
                          sinkAmplitude='i{stepNumber}_AST_%s-%s'%(Panel_name, Partition_number), sinkTemperature=1.0,
                          surface=mod.rootAssembly.instances['Inner_plate-1'].surfaces['Surf-%s'%surface_number])
        Partition_number = Partition_number + 1
        surface_number = surface_number + 1
    Panel_name = Panel_name + 1
### Create Mid-step ###
mdb.models['Model-1'].HeatTransferStep(deltmx=50.0, initialInc=1.0, maxInc=1.0, 
    maxNumInc=1000, minInc=5e-05, name='{pre_odb_step_name}', previous='i0_HT-step', 
    timePeriod=5.0)
mod.setValues(restartJob='{pre_odb_file_name}', restartStep=
    '{pre_odb_step_name}')
mod.HeatTransferStep(deltmx=50.0, initialInc=1.0, maxInc=1.0, 
    maxNumInc=1000, minInc=5e-09, name='{odb_step_name}', previous='{pre_odb_step_name}', 
    timePeriod=5.0)
mod.steps['{odb_step_name}'].Restart(frequency=0, numberIntervals=
    1, overlay=ON, timeMarks=OFF)
mdb.Job(atTime=None, contactPrint=OFF, description='', echoPrint=OFF, 
    explicitPrecision=SINGLE, getMemoryFromAnalysis=True, historyPrint=OFF, 
    memory=90, memoryUnits=PERCENTAGE, model='Model-1', modelPrint=OFF, 
    multiprocessingMode=DEFAULT, name='{odb_file_name}', nodalOutputPrecision=SINGLE, 
    numCpus=2, numDomains=2, numGPUs=0, queue=None, resultsFormat=ODB, scratch=
    '', type=RESTART, userSubroutine='', waitHours=0, waitMinutes=0)
## Remove initial buckling imperfection ##
mod.keywordBlock.synchVersions(storeNodesAndElements=False)
mod.keywordBlock.setValues(edited=0)
mod.keywordBlock.synchVersions(storeNodesAndElements=False)
mod.steps['i{stepNumber}_HT-step'].setValues(timePeriod={stepTime})
'''
        file2.writelines(a)
        file2.close()
## Create a script will be executed by DOS later ##
    data1_file = open(newscriptname, 'r')
    data1 = data1_file.readlines()
    data1_file.close()
    SR_Script = open("HT_Script_execute.py", 'w')
    SR_Script.writelines(data1)
    RunJob = f'''
mdb.jobs['{odb_file_name}'].submit(consistencyChecking=OFF)
mdb.jobs['{odb_file_name}'].waitForCompletion()
'''
    SR_Script.writelines(RunJob)
    SR_Script.close()
    

def ReWriteStiffness(newscriptname, connectionNum):
############################################################
## This function rewrite stiffness.log file to abaqus     ##
## formate.                                               ##
##                                                        ##
##                                                        ##
############################################################
    # Stiffness calculation for the spring #
    try:
        data = open('stiffness_%s.log'%connectionNum, 'r').readlines()
    except:
        print('No stiffness.log file found!!')
        exit(0)
    listForce = []
    listLength = []
    for i in range(len(data)):
        if i % 2 == 0:  # even lines are force
            listForce = listForce + data[i].split()
        else:  # odd lines are length
            listLength = listLength + data[i].split()
    # Switch the str to float number
    listForce = list(map(float, listForce))
    listLength = list(map(float, listLength))
    # Split the force and length for every directions #
    listForce1 = []
    listForce2 = []
    listForce3 = []
    for j in range(len(listForce)):
        if j % 3 == 0:
            listForce1.append(listForce[j])
        elif j % 3 == 1:
            listForce2.append(listForce[j])
        else:
            listForce3.append(listForce[j])
    listLength1 = []
    listLength2 = []
    listLength3 = []
    for j in range(len(listLength)):
        if j % 3 == 0:
            listLength1.append(listLength[j])
        elif j % 3 == 1:
            listLength2.append(listLength[j])
        else:
            listLength3.append(listLength[j])
    # Using dictionary to remove same length but have different stiffness
    stiffness1 = dict(zip(listLength1, listForce1))
    # Change it to (force, length) format
    stiffness1_list = list(zip(stiffness1.values(), stiffness1.keys()))
    # Sort the data in ascendent order
    stiffness1_new = sorted(stiffness1_list, key=lambda x: x[1])
    # Doing the same thing for other directions
    stiffness2 = dict(zip(listLength2, listForce2))
    stiffness2_list = list(zip(stiffness2.values(), stiffness2.keys()))
    stiffness2_new = sorted(stiffness2_list, key=lambda x: x[1])
    stiffness3 = dict(zip(listLength3, listForce3))
    stiffness3_list = list(zip(stiffness3.values(), stiffness3.keys()))
    stiffness3_new = sorted(stiffness3_list, key=lambda x: x[1])
    # Remove the [] of the list
    stiffness1_new = str(stiffness1_new).strip('[]')
    stiffness2_new = str(stiffness2_new).strip('[]')
    stiffness3_new = str(stiffness3_new).strip('[]')
    # Append new script to this file #
    file2=open(newscriptname, 'a')
    Spring_stiffness = f'''
# Create Spring section #
mdb.models['Model-1'].sections['ConnSect-{connectionNum}'].setValues(behaviorOptions=(
    ConnectorElasticity(behavior=NONLINEAR, coupling=COUPLED_MOTION, table=({stiffness1_new}
    ), independentComponents=(1, ), components=(1, )), 
    ConnectorElasticity(behavior=NONLINEAR, coupling=COUPLED_MOTION, table=({stiffness2_new}
    ), independentComponents=(2, ), components=(2, )), 
    ConnectorElasticity(behavior=NONLINEAR, coupling=COUPLED_MOTION, table=({stiffness3_new}
    ), independentComponents=(3, ), components=(3, ))), extrapolation=LINEAR)
'''
    file2.writelines(Spring_stiffness)
    file2.close()


def SRupdate(currentPath, stepNumber, stepTime):
############################################################
## This function updates the segment and step number, and ##
## spring stiffness will also be updated for the new      ##
## analysis.                                              ##
##                                                        ##
## Require: SysBasicSRModel.py                            ##
##          i{stepNumber -1 }_SR-Job.odb                  ##
##          i{stepNumber}_HT-Job.odb                      ##
##          _iteration.log                                ##
##          stiffness-{connectionNum}                     ##
##                                                        ##
## Output: i{stepNum}_SR-Job.py                           ##
##         i{stepNum}_SR-Job.odb                          ##
##                                                        ##
############################################################
    try:
        basicFile=open('SysBasicSRModel.py', 'r')
    except:
        print('No SysBasicSRModel.py exist.')
        exit(0)
    data=basicFile.readlines()
    basicFile.close()
    newscriptname=f"i{stepNumber}_SR-Job.py"
    file2=open(newscriptname, 'w')
    file2.writelines(data)
    file2.close()
    if stepNumber == 0:
        # Append new script to this file #
        file2 = open(newscriptname, 'a')
        a=f'''
############The following is additional lines to update SR script ############
## Predefine field for the temperature ##
mod.Temperature(absoluteExteriorTolerance=0.0,
    beginIncrement=None, beginStep=1, createStepName='i0_SR-Step',
    distributionType=FROM_FILE, endIncrement=None, endStep=None,
    exteriorTolerance=0.05, fileName=
    '{currentPath}\\outputHT\\i{stepNumber}_HT-Job.odb', interpolate=
    MIDSIDE_ONLY, name='Temp-From-HT')
## Create Job and Run the Job ##
mdb.Job(atTime=None, contactPrint=OFF, description='', echoPrint=OFF,
    explicitPrecision=SINGLE, getMemoryFromAnalysis=True, historyPrint=OFF,
    memory=90, memoryUnits=PERCENTAGE, model='Model-1', modelPrint=OFF,
    multiprocessingMode=DEFAULT, name='i{stepNumber}_SR-Job', nodalOutputPrecision=SINGLE,
    numCpus=2, numDomains=2, numGPUs=0, queue=None, resultsFormat=ODB, scratch=
    '', type=ANALYSIS, userSubroutine='', waitHours=0, waitMinutes=0)
mod.steps['i0_SR-Step'].setValues(timePeriod={stepTime})
'''
        file2.writelines(a)
        file2.close()
    else:
        connectionNum = [1, 2, 3, 4]
        for CN in connectionNum:
            MSF.ReWriteStiffness(newscriptname, CN)
        # Append new script to this file #
        file2 = open(newscriptname, 'a')
        a =f'''
## Import Temperature data from HT ##
mod.Temperature(absoluteExteriorTolerance=0.0,
    beginIncrement=None, beginStep=1, createStepName='i0_SR-Step',
    distributionType=FROM_FILE, endIncrement=None, endStep=None,
    exteriorTolerance=0.05, fileName=
    '{currentPath}\\outputHT\\i{stepNumber}_HT-Job.odb', interpolate=
    MIDSIDE_ONLY, name='Temp-From-HT')
## Import distorted mesh from previous step ##
mdb.models['Model-1'].InitialState(createStepName='Initial', endIncrement=
    STEP_END, endStep=LAST_STEP, fileName='i{stepNumber-1}_SR-Job', instances=(
    mdb.models['Model-1'].rootAssembly.instances['Frame-1'],
    mdb.models['Model-1'].rootAssembly.instances['Frame-2'],
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'],
    mdb.models['Model-1'].rootAssembly.instances['Insulation-1'],
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1']), name=
    'Import_restart', updateReferenceConfiguration=OFF)
## Create Job and Run the Job
mdb.Job(atTime=None, contactPrint=OFF, description='', echoPrint=OFF, 
    explicitPrecision=SINGLE, getMemoryFromAnalysis=True, historyPrint=OFF, 
    memory=90, memoryUnits=PERCENTAGE, model='Model-1', modelPrint=OFF, 
    multiprocessingMode=DEFAULT, name='i{stepNumber}_SR-Job', nodalOutputPrecision=SINGLE, 
    numCpus=2, numDomains=2, numGPUs=0, queue=None, resultsFormat=ODB, scratch=
    '', type=ANALYSIS, userSubroutine='', waitHours=0, waitMinutes=0)
mod.steps['i0_SR-Step'].setValues(timePeriod={stepTime})
## Remove initial buckling imperfection ##
mod.keywordBlock.synchVersions(storeNodesAndElements=False)
mod.keywordBlock.setValues(edited=0)
mod.keywordBlock.synchVersions(storeNodesAndElements=False)
'''
        file2.writelines(a)
        file2.close()
    # Create a script will be executed by DOS later #
    data1_file=open(newscriptname,'r')
    data1 = data1_file.readlines()
    data1_file.close()
    SR_Script=open(currentPath+"\\SR_Script_execute.py", 'w')
    SR_Script.writelines(data1)
    RunJob = f'''
mdb.jobs['i{stepNumber}_SR-Job'].submit(consistencyChecking=OFF)
mdb.jobs['i{stepNumber}_SR-Job'].waitForCompletion()
##### output the amplitude data for submodel ###
os.chdir(currentPath)
execfile('_Amplitude_temp_calculation.py')
'''
    SR_Script.writelines(RunJob)
    SR_Script.close()


def Subupdate(stepNumber, connectionNum, stepTime):
############################################################
## This function update the small-scale model, the        ##
## displacement boundary conditions is from the SR model, ##
## and temperature data script is needed for the temp.    ##
## boundary conditions.                                   ##
##                                                        ##
## Require: i{stepNumber}_Connection{connecNum}_temp.py   ##
##          i{stepNumber}_SR-Job.odb                      ##
##          SubBasicModel-connection{connecNum}.py        ##
##          _iteration.log                                ##
##                                                        ##
## Output: i{stepNumber}_Sub_CON{connecNum}-Job.py        ##
##         i{stepNumber}_Sub_CON{connecNum}-Job.odb       ##
##                                                        ##
############################################################

### Copy the basic model ###
    basicFile=open(f'SubBasicModel-connection{connectionNum}.py','r')
    data=basicFile.readlines()
    basicFile.close()
    newscriptname=f"i{stepNumber}_Sub_CON{connectionNum}-Job.py"
    file2=open(newscriptname, 'w')
    file2.writelines(data)
    file2.close()
    # Append new script to this file #
    file2=open(newscriptname, 'a')
    if stepNumber == 0:
        ######### Write amplitude data in file ################
        tempdata_file = open(f'i{stepNumber}_Connection{connectionNum}_temp.py', 'r')
        tempdata= tempdata_file.readlines()
        tempdata_file.close()
        file2.writelines(tempdata)
        ######### Append additional script in file ###########
        b=f'''
############The following is additional lines to update Sub script ############
mod.Temperature(amplitude='i{stepNumber}_Temp', createStepName=
    'i{stepNumber}_Sub_step', crossSectionDistribution=CONSTANT_THROUGH_THICKNESS,
    distributionType=UNIFORM, magnitudes=(1.0, ), name='Temp_from_Global',
    region=modRa.sets['Set-temp-surf'])
mod.steps['i0_Sub_step'].setValues(timePeriod={stepTime})
modRa.regenerate()
### Create Job ###
mdb.Job(atTime=None, contactPrint=OFF, description='', echoPrint=OFF,
    explicitPrecision=SINGLE, getMemoryFromAnalysis=True, historyPrint=OFF,
    memory=90, memoryUnits=PERCENTAGE, model='Model-1', modelPrint=OFF,
    multiprocessingMode=DEFAULT, name='i{stepNumber}_Sub_CON{connectionNum}-Job', nodalOutputPrecision=
    SINGLE, numCpus=2, numDomains=2, numGPUs=0, queue=None, resultsFormat=ODB,
    scratch='', type=ANALYSIS, userSubroutine='', waitHours=0, waitMinutes=0)
'''
        file2.writelines(b)
        file2.close()
    elif stepNumber == 1:
        a = f'''
############The following is additional lines to update Sub script ############
## Update the restart Job and global Job ##
mod.setValues(restartJob='i{stepNumber-1}_Sub_CON{connectionNum}-Job', restartStep='i{stepNumber-1}_Sub_step',
    globalJob='i{stepNumber}_SR-Job')
### step new ###
mod.StaticStep(initialInc=0.1, maxInc=1, minInc=5e-06, maxNumInc=1000, 
    name='i{stepNumber}_Sub_step', previous='i{stepNumber-1}_Sub_step', timePeriod=5.0)
# Improve convergence #
mod.steps['i{stepNumber}_Sub_step'].setValues(adaptiveDampingRatio=0.05
    , continueDampingFactors=False, stabilizationMagnitude=0.0002,
    stabilizationMethod=DISSIPATED_ENERGY_FRACTION)
## Output Request ##
mod.fieldOutputRequests['F-Output-1'].setValues(variables=(
    'S', 'PE', 'PEEQ', 'U', 'RF', 'SDEG', 'NT', 'STATUS'))
### Restart Request ###
mod.steps['i{stepNumber}_Sub_step'].Restart(frequency=1, 
    numberIntervals=0, overlay=ON, timeMarks=OFF)
### Adjust Submodel BC ###
mod.boundaryConditions['SubBC-frame'].move('i{stepNumber-1}_Sub_step', 
    'i{stepNumber}_Sub_step')
mod.boundaryConditions['SubBC-frame'].setValues(globalStep='{stepNumber+1}', 
    globalDrivingRegion='', shellThickness=0.004, absoluteExteriorTolerance=None, 
    exteriorTolerance=0.05)
mod.boundaryConditions['SubBC-plate'].move('i{stepNumber-1}_Sub_step', 
    'i{stepNumber}_Sub_step')
mod.boundaryConditions['SubBC-plate'].setValues(globalStep='{stepNumber+1}', 
    globalDrivingRegion='', shellThickness=0.001, absoluteExteriorTolerance=None, 
    exteriorTolerance=0.05)
'''
        file2.writelines(a)
        ######### Write amplitude data in file ################
        tempdata_file = open(f'i{stepNumber}_Connection{connectionNum}_temp.py', 'r')
        tempdata = tempdata_file.readlines()
        tempdata_file.close()
        file2.writelines(tempdata)
        ######### Append additional script in file ###########
        b = f'''
########## Assign temp data to all face ###########
mod.Temperature(amplitude='i{stepNumber}_Temp', createStepName=
    'i{stepNumber}_Sub_step', crossSectionDistribution=CONSTANT_THROUGH_THICKNESS,
    distributionType=UNIFORM, magnitudes=(1.0, ), name='Temp_from_Global',
    region=modRa.sets['Set-temp-surf'])
mod.steps['i1_Sub_step'].setValues(timePeriod={stepTime})
###### Create and Submit the job #######
### Create Job ###
mod.rootAssembly.regenerate()
mdb.Job(name='i{stepNumber}_Sub_CON{connectionNum}-Job', model='Model-1', description='', type=RESTART, 
    atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
    memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
    explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
    modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
    scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=2, 
    numDomains=2, numGPUs=0)
'''
        file2.writelines(b)
        file2.close()
    else :
        a = f'''
############The following is additional lines to update Sub script ############
## Update the restart Job and global Job ##
mod.setValues(restartJob='i{stepNumber - 1}_Sub_CON{connectionNum}-Job', restartStep='i{stepNumber - 1}_Sub_step',
    globalJob='i{stepNumber}_SR-Job')
### Create Mid-step ###
mod.StaticStep(initialInc=0.1, maxInc=1, minInc=5e-06, maxNumInc=1000, 
    name='i{stepNumber-1}_Sub_step', previous='i0_Sub_step', timePeriod=5.0)
### step new ###
mod.StaticStep(initialInc=0.1, maxInc=1, minInc=5e-06, maxNumInc=1000, 
    name='i{stepNumber}_Sub_step', previous='i{stepNumber - 1}_Sub_step', timePeriod=5.0)
# Improve convergence #
mod.steps['i{stepNumber}_Sub_step'].setValues(adaptiveDampingRatio=0.05
    , continueDampingFactors=False, stabilizationMagnitude=0.0002,
    stabilizationMethod=DISSIPATED_ENERGY_FRACTION)
## Output Request ##
mod.fieldOutputRequests['F-Output-1'].setValues(variables=(
    'S', 'PE', 'PEEQ', 'U', 'RF', 'SDEG', 'NT', 'STATUS'))
### Restart Request ###
mod.steps['i{stepNumber}_Sub_step'].Restart(frequency=1, 
    numberIntervals=0, overlay=ON, timeMarks=OFF)
### Adjust Submodel BC ###
mod.boundaryConditions['SubBC-frame'].move('i0_Sub_step', 
    'i{stepNumber}_Sub_step')
mod.boundaryConditions['SubBC-frame'].setValues(globalStep='{stepNumber + 1}', 
    globalDrivingRegion='', shellThickness=0.004, absoluteExteriorTolerance=None, 
    exteriorTolerance=0.05)
mod.boundaryConditions['SubBC-plate'].move('i0_Sub_step', 
    'i{stepNumber}_Sub_step')
mod.boundaryConditions['SubBC-plate'].setValues(globalStep='{stepNumber + 1}', 
    globalDrivingRegion='', shellThickness=0.001, absoluteExteriorTolerance=None, 
    exteriorTolerance=0.05)
'''
        file2.writelines(a)
        ######### Write amplitude data in file ################
        tempdata_file = open(f'i{stepNumber}_Connection{connectionNum}_temp.py', 'r')
        tempdata = tempdata_file.readlines()
        tempdata_file.close()
        file2.writelines(tempdata)
        ######### Append additional script in file ###########
        b = f'''
########## Assign temp data to all face ###########
mod.Temperature(amplitude='i{stepNumber}_Temp', createStepName=
    'i{stepNumber}_Sub_step', crossSectionDistribution=CONSTANT_THROUGH_THICKNESS,
    distributionType=UNIFORM, magnitudes=(1.0, ), name='Temp_from_Global',
    region=modRa.sets['Set-temp-surf'])
###### Create and Submit the job #######
mod.steps['i{stepNumber}_Sub_step'].setValues(timePeriod={stepTime})
### Create Job ###
mod.rootAssembly.regenerate()
mdb.Job(name='i{stepNumber}_Sub_CON{connectionNum}-Job', model='Model-1', description='', type=RESTART, 
    atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
    memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
    explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
    modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
    scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=2, 
    numDomains=2, numGPUs=0)
        '''
        file2.writelines(b)
        file2.close()
# Create a script will be executed by DOS later #
    data1=open(newscriptname,'r').readlines()
    SR_Script=open("Sub_Script_execute.py", 'w')
    SR_Script.writelines(data1)
    RunJob = f'''
mdb.jobs['i{stepNumber}_Sub_CON{connectionNum}-Job'].submit(consistencyChecking=OFF)
mdb.jobs['i{stepNumber}_Sub_CON{connectionNum}-Job'].waitForCompletion()
'''
    SR_Script.writelines(RunJob)
    SR_Script.close()


def Failure_monitor(currentPath, connectionNum):
    ### Monitor for element deletion ###
    if os.path.exists(currentPath + '\\Element_Monitor_Con_%s.txt'%connectionNum):
        Element_monitor = open('Element_Monitor_Con_%s.txt'%connectionNum, 'r')
        Element_status = Element_monitor.readlines()
        Element_monitor.close()
        Element_status_switch = Element_status[0].split()
        # Make it float #
        Element_status_switch = float(Element_status_switch[0])
    else:
        Element_status_switch = 1
    return Element_status_switch


def Convergence_checking(currentPath, stepNumber, connectionNum, convergence):
    if stepNumber == 0:
        convergence = True
    else:
        ## This function check the status of the last job ##
        stepNumber = stepNumber-1
        try:
            status_file = open(currentPath + f"\\outputSR\\i{stepNumber}_Sub_CON{connectionNum}-Job.sta", 'r')
        except:
            print('The status file for connection-%s in step-%s is not exist!'%(connectionNum, stepNumber))
            convergence = False
        for line in status_file:
            if "THE ANALYSIS HAS NOT BEEN COMPLETED" in line:
                # if not converged, turn the switch off #
                convergence = False
                print('The connection%s has not converged yet!'%connectionNum)
            else:
                convergence = True
        status_file.close()
    ## Write current connection status ##
        Connection_failure_file = open(f'Connection-{connectionNum}_status.log', 'a')
        Failure_information = f'''
The connection-{connectionNum} convergence status at step-{stepNumber} is:
{convergence} \n
'''
        Connection_failure_file.writelines(Failure_information)
        Connection_failure_file.close()
    return convergence


def suffix(file, *suffixName):
    array = map(file.endswith, suffixName)
    if True in array:
        return True
    else:
        return False


def Post_Processing():
    run('call abaqus cae noGUI=_Post_Processing.py', shell=True)
    os.chdir(currentPath + '\\outputSR\\')
    iris_concat = pd.DataFrame()
    for name in sorted(glob.glob('i*_displacement.txt'), key=len):
        iris = pd.read_table(name, skiprows=5, header=None,
                             names=['Time', 'RF', 'RF1', 'RF2', 'RF3', 'U1', 'U2', 'U3'], delim_whitespace=True)
        df = pd.DataFrame(iris)
        # data = df.head(1) # Taking first point as standard.
        iris_concat = pd.concat([iris_concat, df])
    #### Remove other unneccessary files ##
    targetDir = os.getcwd()
    for file in os.listdir(targetDir):
        targetFile = os.path.join(targetDir, file)
        if suffix(file, '.com'):  # '.mdl', '.stt', '.msg', '.prt', '.sim', '.sta', '.res', '.inp', '.dat',
            os.remove(targetFile)
    #### Write output to excel ####
    os.chdir(currentPath)
    iris_concat.to_excel('./_Force_Displacement.xlsx')  # , index = False


def Stiffness_after_failure(connectionNum):
    SOF1_previous = SOF2_previous = SOF3_previous = 200
    SOF1_final = SOF2_final = SOF3_final = 200
    length1 = length2 = length3 = 1
    # Find Contact pair force #
    outputfile = open(F'stiffness_{connectionNum}.log', 'w')
    stiffness_data = '%s %s %s\n 0 0 0\n %s %s %s\n %s %s %s\n' % (
        abs(SOF1_previous), abs(SOF2_previous), abs(SOF3_previous),
        abs(SOF1_final), abs(SOF2_final), abs(SOF3_final),
        length1, length2, abs(length3))
    outputfile.writelines(stiffness_data)
    outputfile.close()
