import matplotlib.axes as ax
import matplotlib.pyplot as plt
import pandas as pd
import os
from sys import exit
import numpy as np
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter,
                               AutoMinorLocator)


def RF_FigureOutput(ReactionForce_direction, ConnectionNum):
    all_dataFrame = []
    for CN in ConnectionNum:
        column = 1
        FileName = '_Connection_%s-RF%s.csv' % (CN, ReactionForce_direction)
        ColumnName = '_Connection_%s' % CN
        ## Rename the header ##
        header_names = ['Time_%s' % CN, ColumnName]
        single_data_frame = pd.read_csv(FileName, header=None, names=header_names)
        all_dataFrame.append(single_data_frame)
    ## concatenate frame horizentially, if veritically, try axis=0
    # finial_frame = pd.concat(all_dataFrame, axis=1).fillna(0)
    finial_frame = pd.concat(all_dataFrame, axis=1)
    x1 = finial_frame.iloc[:, 0]
    y1 = finial_frame.iloc[:, 1]
    x2 = finial_frame.iloc[:, 2]
    y2 = finial_frame.iloc[:, 3]
    x3 = finial_frame.iloc[:, 4]
    y3 = finial_frame.iloc[:, 5]
    x4 = finial_frame.iloc[:, 6]
    y4 = finial_frame.iloc[:, 7]
    ## Set Minor ticks ##
    fig, ax = plt.subplots()
    ax.xaxis.set_minor_locator(AutoMinorLocator())
    ax.yaxis.set_minor_locator(AutoMinorLocator())
    line_1 = ax.plot(x1, y1 / 1000, marker=".", markersize=5, linewidth=1.5, label='Connection_1')
    line_2 = ax.plot(x2, y2 / 1000, marker="o", markersize=5, linewidth=1.5, label='Connection_2')
    line_3 = ax.plot(x3, y3 / 1000, marker="s", markersize=5, linewidth=1.5, label='Connection_3')
    line_4 = ax.plot(x4, y4 / 1000, marker="x", markersize=5, linewidth=1.5, label='Connection_4')
    ## Set font ##
    plt.rcParams['font.sans-serif'] = ['Arial']
    ## Set Maxium ticks ##
    # plt.xticks(np.arange(min(x1), max(x1) + 1, 1.0))
    # plt.yticks(np.arange(min(y1), max(y1) / 1000 + 1, 2.0))
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    ## Adjustment for axis ##
    # plt.ylim(bottom=min(y1))
    plt.xlim(left=0)
    # plt.xticks(fontweight='bold') # using this command to change figure to bold font
    ## Find best location for legend ##
    plt.legend(loc='best', frameon=False)
    leg = plt.gca().get_legend()
    ltext = leg.get_texts()
    plt.setp(ltext, fontsize=12)
    ## Create lable for x and y ##
    plt.xlabel('Time(s)', fontsize=12)
    plt.ylabel('Reaction Force in %s-direction (kN)'%ReactionForce_direction, fontsize=12)
    ## Set grid on ##
    plt.grid(color='whitesmoke', linestyle="--")
    ## Save figures ##
    fig = plt.gcf()
    fig.set_size_inches(8, 6)
    fig.savefig('_RF%s for connections.png'%ReactionForce_direction, bbox_inches='tight', dpi=150)
    # plt.show()


def CONN_FigureOutput(RF_direction, connection_name):
    all_dataFrame = []
    for RF in RF_direction:
        column = 1
        FileName = '_Connection_%s-RF%s.csv' % (connection_name, RF)
        ColumnName = 'Reaction_force_in_%s-direction' % RF
        ## Rename the header ##
        header_names = ['Time_%s' % RF, ColumnName]
        single_data_frame = pd.read_csv(FileName, header=None, names=header_names)
        all_dataFrame.append(single_data_frame)
    ## concatenate frame horizentially, if veritically, try axis=0
    # finial_frame = pd.concat(all_dataFrame, axis=1).fillna(0)
    finial_frame = pd.concat(all_dataFrame, axis=1)
    x1 = finial_frame.iloc[:, 0]
    y1 = finial_frame.iloc[:, 1]
    x2 = finial_frame.iloc[:, 2]
    y2 = finial_frame.iloc[:, 3]
    x3 = finial_frame.iloc[:, 4]
    y3 = finial_frame.iloc[:, 5]
    # x4 = finial_frame.iloc[:, 6]
    # y4 = finial_frame.iloc[:, 7]
    ## Set Minor ticks ##
    fig, ax = plt.subplots()
    ax.xaxis.set_minor_locator(AutoMinorLocator())
    ax.yaxis.set_minor_locator(AutoMinorLocator())
    line_1, = ax.plot(x1, y1 / 1000, marker="o", markersize=5, linewidth=1.5, label='RF in 1-direction')
    line_2, = ax.plot(x2, y2 / 1000, marker="v", markersize=5, linewidth=1.5, label='RF in 2-direction')
    line_3, = ax.plot(x3, y3 / 1000, marker="s", markersize=5, linewidth=1.5, label='RF in 3-direction')
    # line_4, = ax.plot(x4, y4 / 1000, marker="s", markersize=5, linewidth=1.5, label='RF in 4-direction')
    ## Set font ##
    plt.rcParams['font.sans-serif'] = ['Arial']
    ## Set Maxium ticks ##
    # plt.xticks(np.arange(min(x1), max(x1) + 1, 1.0))
    # plt.yticks(np.arange(min(y1), max(y1) / 1000 + 1, 2.0))
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    ## Adjustment for axis ##
    # plt.ylim(bottom=min(y1))
    plt.xlim(left=0)
    # plt.xticks(fontweight='bold') # using this command to change figure to bold font
    ## Find best location for legend ##
    plt.legend(loc='best', frameon=False)
    leg = plt.gca().get_legend()
    ltext = leg.get_texts()
    plt.setp(ltext, fontsize=12)
    ## Create lable for x and y ##
    plt.xlabel('Time(s)', fontsize=12)
    plt.ylabel('Reaction Force of connection-%s (kN)' % connection_name, fontsize=12)
    ## Set grid on ##
    plt.grid(color='whitesmoke', linestyle="--")
    ## Save figures ##
    fig = plt.gcf()
    fig.set_size_inches(8, 6)
    fig.savefig('_RF of connection-%s.png' % connection_name, bbox_inches='tight', dpi=150)
    # plt.show()


def spring_FigureOutput(ReactionForce_direction, ConnectionNum):
    all_dataFrame = []
    for CN in ConnectionNum:
        column = 1
        FileName = '_Spring_%s-RF%s.csv' % (CN, ReactionForce_direction)
        ColumnName = 'Spring_%s' % CN
        ## Rename the header ##
        header_names = ['Time_%s' % CN, ColumnName]
        single_data_frame = pd.read_csv(FileName, header=None, names=header_names)
        all_dataFrame.append(single_data_frame)
    ## concatenate frame horizentially, if veritically, try axis=0
    # finial_frame = pd.concat(all_dataFrame, axis=1).fillna(0)
    finial_frame = pd.concat(all_dataFrame, axis=1)
    x1 = finial_frame.iloc[:, 0]
    y1 = finial_frame.iloc[:, 1]
    x2 = finial_frame.iloc[:, 2]
    y2 = finial_frame.iloc[:, 3]
    x3 = finial_frame.iloc[:, 4]
    y3 = finial_frame.iloc[:, 5]
    x4 = finial_frame.iloc[:, 6]
    y4 = finial_frame.iloc[:, 7]
    ## Set Minor ticks ##
    fig, ax = plt.subplots()
    ax.xaxis.set_minor_locator(AutoMinorLocator())
    ax.yaxis.set_minor_locator(AutoMinorLocator())
    line_1 = ax.plot(x1, y1 / 1000, marker=".", markersize=5, linewidth=1.5, label='Spring_1')
    line_2 = ax.plot(x2, y2 / 1000, marker="o", markersize=5, linewidth=1.5, label='Spring_2')
    line_3 = ax.plot(x3, y3 / 1000, marker="s", markersize=5, linewidth=1.5, label='Spring_3')
    line_4 = ax.plot(x4, y4 / 1000, marker="x", markersize=5, linewidth=1.5, label='Spring_4')
    ## Set font ##
    plt.rcParams['font.sans-serif'] = ['Arial']
    ## Set Maxium ticks ##
    # plt.xticks(np.arange(min(x1), max(x1) + 1, 1.0))
    # plt.yticks(np.arange(min(y1), max(y1) / 1000 + 1, 2.0))
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    ## Adjustment for axis ##
    # plt.ylim(bottom=min(y1))
    plt.xlim(left=0)
    # plt.xticks(fontweight='bold') # using this command to change figure to bold font
    ## Find best location for legend ##
    plt.legend(loc='best', frameon=False)
    leg = plt.gca().get_legend()
    ltext = leg.get_texts()
    plt.setp(ltext, fontsize=12)
    ## Create lable for x and y ##
    plt.xlabel('Time(s)', fontsize=12)
    plt.ylabel('Reaction Force in %s-direction (kN)'%ReactionForce_direction, fontsize=12)
    ## Set grid on ##
    plt.grid(color='whitesmoke', linestyle="--")
    ## Save figures ##
    fig = plt.gcf()
    fig.set_size_inches(8, 6)
    fig.savefig('_RF%s for spring.png'%ReactionForce_direction, bbox_inches='tight', dpi=150)
    # plt.show()


def spring_each_FigureOutput(RF_direction, connection_name):
    all_dataFrame = []
    for RF in RF_direction:
        column = 1
        FileName = '_Spring_%s-RF%s.csv' % (connection_name, RF)
        ColumnName = 'Spring_force_in_%s-direction' % RF
        ## Rename the header ##
        header_names = ['Time_%s' % RF, ColumnName]
        single_data_frame = pd.read_csv(FileName, header=None, names=header_names)
        all_dataFrame.append(single_data_frame)
    ## concatenate frame horizentially, if veritically, try axis=0
    # finial_frame = pd.concat(all_dataFrame, axis=1).fillna(0)
    finial_frame = pd.concat(all_dataFrame, axis=1)
    x1 = finial_frame.iloc[:, 0]
    y1 = finial_frame.iloc[:, 1]
    x2 = finial_frame.iloc[:, 2]
    y2 = finial_frame.iloc[:, 3]
    x3 = finial_frame.iloc[:, 4]
    y3 = finial_frame.iloc[:, 5]
    # x4 = finial_frame.iloc[:, 6]
    # y4 = finial_frame.iloc[:, 7]
    ## Set Minor ticks ##
    fig, ax = plt.subplots()
    ax.xaxis.set_minor_locator(AutoMinorLocator())
    ax.yaxis.set_minor_locator(AutoMinorLocator())
    line_1, = ax.plot(x1, y1 / 1000, marker="o", markersize=5, linewidth=1.5, label='RF in 1-direction')
    line_2, = ax.plot(x2, y2 / 1000, marker="v", markersize=5, linewidth=1.5, label='RF in 2-direction')
    line_3, = ax.plot(x3, y3 / 1000, marker="s", markersize=5, linewidth=1.5, label='RF in 3-direction')
    # line_4, = ax.plot(x4, y4 / 1000, marker="s", markersize=5, linewidth=1.5, label='RF in 4-direction')
    ## Set font ##
    plt.rcParams['font.sans-serif'] = ['Arial']
    ## Set Maxium ticks ##
    # plt.xticks(np.arange(min(x1), max(x1) + 1, 1.0))
    # plt.yticks(np.arange(min(y1), max(y1) / 1000 + 1, 2.0))
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    ## Adjustment for axis ##
    # plt.ylim(bottom=min(y1))
    plt.xlim(left=0)
    # plt.xticks(fontweight='bold') # using this command to change figure to bold font
    ## Find best location for legend ##
    plt.legend(loc='best', frameon=False)
    leg = plt.gca().get_legend()
    ltext = leg.get_texts()
    plt.setp(ltext, fontsize=12)
    ## Create lable for x and y ##
    plt.xlabel('Time(s)', fontsize=12)
    plt.ylabel('Reaction Force of spring-%s (kN)' % connection_name, fontsize=12)
    ## Set grid on ##
    plt.grid(color='whitesmoke', linestyle="--")
    ## Save figures ##
    fig = plt.gcf()
    fig.set_size_inches(8, 6)
    fig.savefig('_RF of spring-%s.png' % connection_name, bbox_inches='tight', dpi=150)
    # plt.show()


CurrentPath = os.getcwd()
RF_direction = [1, 2, 3]
ConnectionNum = [1, 2, 3, 4]
## To print Reaction force of each DIRECTION ##
for direction in RF_direction:
    ## For small-scale model ##
    RF_FigureOutput(direction, ConnectionNum)
    ## For spring element ##
    # spring_FigureOutput(direction, ConnectionNum)

## To print Reaction force of each CONNECTION ##
for connection_name in ConnectionNum:
    ## For small-scale model ##
    CONN_FigureOutput(RF_direction, connection_name)
    ## For spring element ##
    # spring_each_FigureOutput(RF_direction, connection_name)
exit(0)