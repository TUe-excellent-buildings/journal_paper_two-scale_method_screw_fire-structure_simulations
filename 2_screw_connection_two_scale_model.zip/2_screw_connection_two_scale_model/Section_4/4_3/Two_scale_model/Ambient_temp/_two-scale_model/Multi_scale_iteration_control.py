########################################################################################################
##### This script controlling iteration of the multi-scale couplling of the connection model,     ######
##### Input: Step number, Basic models of the HT, SR, and Sub.                                    ######
##### Output: .odb files of every steps.                                                          ######
##### By: Qingfeng Xu (Aiden)                                                   2019.09.13        ######
########################################################################################################
import os,shutil
import glob
import pandas as pd
from matplotlib import pyplot as plt
from subprocess import run


############################### Using this function to update SR script ################################
def SRupdate(iterationNum):
    basicFile=open('SysBasicSRModel.py', 'r')
    data=basicFile.readlines()
    basicFile.close()
    newscriptname=f"i{iterationNum}_Sys_SR.py"
    file2=open(newscriptname,'w')
    file2.writelines(data)
    file2.close()
    # Append new script to this file #
    file2=open(newscriptname,'a')
    frontlines='''
############The following is additional lines to update SR script ############
    '''
    file2.writelines(frontlines)
    if iterationNum==0:
        a='''
# Create Spring section #
mdb.models['Model-SR'].ConnectorSection(name='ConnSect-Spring',
    translationalType=CARTESIAN)
mdb.models['Model-SR'].sections['ConnSect-Spring'].setValues(behaviorOptions=(
    ConnectorElasticity(behavior=NONLINEAR, coupling=COUPLED_MOTION, table=((
    0.0, 0.0), (7000.0, 0.1)), independentComponents=(1, ), components=(1, )), 
    ConnectorElasticity(behavior=NONLINEAR, coupling=COUPLED_MOTION, table=((
    0.0, 0.0), (7000.0, 0.1)), independentComponents=(2, ), components=(2, )), 
    ConnectorElasticity(behavior=NONLINEAR, coupling=COUPLED_MOTION, table=((
    0.0, 0.0), (14000.0, 0.1)), independentComponents=(3, ), components=(3, ))), 
    extrapolation=LINEAR)
mdb.models['Model-SR'].rootAssembly.SectionAssignment(region=
    mdb.models['Model-SR'].rootAssembly.sets['Wire-1-Set-1'], sectionName=
    'ConnSect-Spring')
# ## Import Temperature data from HT ##
# mdb.models['Model-SR'].Temperature(absoluteExteriorTolerance=0.0, 
#     beginIncrement=None, beginStep=1, createStepName='i0_SR-Step', 
#     distributionType=FROM_FILE, endIncrement=None, endStep=None, 
#     exteriorTolerance=0.05, fileName=currentPath+'/outputHT/i0_Sys_HT.odb', 
#     interpolate=OFF, name='Predefined Field-1')
## Create Job and Run the Job
mdb.Job(atTime=None, contactPrint=OFF, description='', echoPrint=OFF, 
    explicitPrecision=SINGLE, getMemoryFromAnalysis=True, historyPrint=OFF, 
    memory=90, memoryUnits=PERCENTAGE, model='Model-SR', modelPrint=OFF, 
    multiprocessingMode=DEFAULT, name='i0_Sys_SR', nodalOutputPrecision=SINGLE, 
    numCpus=2, numDomains=2, numGPUs=0, queue=None, resultsFormat=ODB, scratch=
    '', type=ANALYSIS, userSubroutine='', waitHours=0, waitMinutes=0)
'''
        file2.writelines(a)
        file2.close()
    else :
        # Stiffness calculation for the spring #
        data = open('stiffness.log', 'r').readlines()
        listForce = []
        listLength = []
        for i in range(len(data)):
            if i % 2 == 0:  # even lines are force
                listForce = listForce + data[i].split()
            else:  # odd lines are length
                listLength = listLength + data[i].split()
        # Switch the str to float number
        listForce = list(map(float, listForce))
        listLength = list(map(float, listLength))
        # Split the force and length for every directions #
        listForce1 = []
        listForce2 = []
        listForce3 = []
        for j in range(len(listForce)):
            if j % 3 == 0:
                listForce1.append(listForce[j])
            elif j % 3 == 1:
                listForce2.append(listForce[j])
            else:
                listForce3.append(listForce[j])
        listLength1 = []
        listLength2 = []
        listLength3 = []
        for j in range(len(listLength)):
            if j % 3 == 0:
                listLength1.append(listLength[j])
            elif j % 3 == 1:
                listLength2.append(listLength[j])
            else:
                listLength3.append(listLength[j])
        # Using dictionary to remove same length but have different stiffness
        stiffness1 = dict(zip(listLength1, listForce1))
        # Change it to (force, length) format
        stiffness1_list = list(zip(stiffness1.values(), stiffness1.keys()))
        # Sort the data in ascendent order
        stiffness1_new = sorted(stiffness1_list, key=lambda x: x[1])
        # Doing the same thing for other directions
        stiffness2 = dict(zip(listLength2, listForce2))
        stiffness2_list = list(zip(stiffness2.values(), stiffness2.keys()))
        stiffness2_new = sorted(stiffness2_list, key=lambda x: x[1])
        stiffness3 = dict(zip(listLength3, listForce3))
        stiffness3_list = list(zip(stiffness3.values(), stiffness3.keys()))
        stiffness3_new = sorted(stiffness3_list, key=lambda x: x[1])
        # Remove the [] of the list
        stiffness1_new = str(stiffness1_new).strip('[]')
        stiffness2_new = str(stiffness2_new).strip('[]')
        stiffness3_new = str(stiffness3_new).strip('[]')
        a =f'''
# Create Spring section #
mdb.models['Model-SR'].ConnectorSection(name='ConnSect-Spring',
    translationalType=CARTESIAN)
mdb.models['Model-SR'].sections['ConnSect-Spring'].setValues(behaviorOptions=(
    ConnectorElasticity(behavior=NONLINEAR, coupling=COUPLED_MOTION, table=({stiffness1_new}
    ), independentComponents=(1, ), components=(1, )), 
    ConnectorElasticity(behavior=NONLINEAR, coupling=COUPLED_MOTION, table=({stiffness2_new}
    ), independentComponents=(2, ), components=(2, )), 
    ConnectorElasticity(behavior=NONLINEAR, coupling=COUPLED_MOTION, table=({stiffness3_new}
    ), independentComponents=(3, ), components=(3, ))), extrapolation=LINEAR)
mdb.models['Model-SR'].rootAssembly.SectionAssignment(region=
    mdb.models['Model-SR'].rootAssembly.sets['Wire-1-Set-1'], sectionName=
    'ConnSect-Spring')
# ## Import Temperature data from HT ##
# mdb.models['Model-SR'].Temperature(absoluteExteriorTolerance=0.0, 
#     beginIncrement=None, beginStep=1, createStepName='i0_SR-Step', 
#     distributionType=FROM_FILE, endIncrement=None, endStep=None, 
#     exteriorTolerance=0.05, fileName=currentPath+'/outputHT/i{iterationNum}_Sys_HT.odb', 
#     interpolate=OFF, name='Predefined Field-1')
## Import distorted mesh from previous step ##
mdb.models['Model-SR'].InitialState(createStepName='Initial', endIncrement=
    STEP_END, endStep=LAST_STEP, fileName='i{iterationNum-1}_Sys_SR', instances=(
    mdb.models['Model-SR'].rootAssembly.instances['Part-1-1'],
    mdb.models['Model-SR'].rootAssembly.instances['Part-2-1']), name=
    'Import_Mesh', updateReferenceConfiguration=OFF)
## Create Job and Run the Job
mdb.Job(atTime=None, contactPrint=OFF, description='', echoPrint=OFF, 
    explicitPrecision=SINGLE, getMemoryFromAnalysis=True, historyPrint=OFF, 
    memory=90, memoryUnits=PERCENTAGE, model='Model-SR', modelPrint=OFF, 
    multiprocessingMode=DEFAULT, name='i{iterationNum}_Sys_SR', nodalOutputPrecision=SINGLE, 
    numCpus=2, numDomains=2, numGPUs=0, queue=None, resultsFormat=ODB, scratch=
    '', type=ANALYSIS, userSubroutine='', waitHours=0, waitMinutes=0)
'''
        file2.writelines(a)
        file2.close()
    # Create a script will be executed by DOS later #
    data1=open(newscriptname,'r').readlines()
    SR_Script=open(currentPath+"\\SR_Script.py",'w')
    SR_Script.writelines(data1)
    RunJob = f'''
mdb.jobs['i{iterationNum}_Sys_SR'].submit(consistencyChecking=OFF)
mdb.jobs['i{iterationNum}_Sys_SR'].waitForCompletion()
##### output the amplitude data for submodel ###
os.chdir(currentPath)
execfile('_Amplitude_temp_calculation.py')
'''
    SR_Script.writelines(RunJob)
    SR_Script.close()


############################### Using this function to update Sub script ###############################
def Subupdate(iterationNum):
### Copy the basic model ###
    basicFile=open('SubBasicModel.py','r')
    data=basicFile.readlines()
    basicFile.close()
    newscriptname=f"i{iterationNum}_Sub.py"
    file2=open(newscriptname,'w')
    file2.writelines(data)
    file2.close()
    # Append new script to this file #
    file2=open(newscriptname,'a')
    frontlines='''
############The following is additional lines to update SR script ############
'''
    file2.writelines(frontlines)
    if iterationNum==0:
        a=f'''
### Create Job ###
mdb.Job(atTime=None, contactPrint=OFF, description='', echoPrint=OFF, 
    explicitPrecision=SINGLE, getMemoryFromAnalysis=True, historyPrint=OFF, 
    memory=90, memoryUnits=PERCENTAGE, model='Submodel', modelPrint=OFF, 
    multiprocessingMode=DEFAULT, name='i0_Sub', nodalOutputPrecision=SINGLE, 
    numCpus=2, numDomains=2, numGPUs=0, queue=None, resultsFormat=ODB, scratch=
    '', type=ANALYSIS, userSubroutine='', waitHours=0, waitMinutes=0)
'''
        file2.writelines(a)
        ######### Write amplitude data in file ################
        tempdata=open('_temp.py','r').readlines()
        file2.writelines(tempdata)
        ######### Append additional script in file ###########
        b=f'''
########## Assign temp data to all face ###########
mdb.models['Submodel'].Temperature(amplitude='i{iterationNum}_Temp', createStepName=
    'i{iterationNum}_Sub_step', crossSectionDistribution=CONSTANT_THROUGH_THICKNESS, 
    distributionType=UNIFORM, magnitudes=(1.0, ), name='Temperature_field', 
    region=mdb.models['Submodel'].rootAssembly.sets['Set_temperature_surfaces'])
###### Create and Submit the job #######
'''
        file2.writelines(b)
        file2.close()
    elif iterationNum==1:
        a = f'''
### step new ###
mdb.models['Submodel'].setValues(globalJob='i{iterationNum}_Sys_SR', restartJob='i{iterationNum-1}_Sub', 
    restartStep='i{iterationNum-1}_Sub_step')
mdb.models['Submodel'].StaticStep(initialInc=0.1, maxInc=1, minInc=5e-010, maxNumInc=1000, 
    name='i{iterationNum}_Sub_step', previous='i{iterationNum-1}_Sub_step', timePeriod=1.0)
# Improve convergence #
mdb.models['Submodel'].steps['i{iterationNum}_Sub_step'].setValues(adaptiveDampingRatio=0.05
    , continueDampingFactors=False, stabilizationMagnitude=0.0002,
    stabilizationMethod=DISSIPATED_ENERGY_FRACTION)
## Output Request ##
mdb.models['Submodel'].fieldOutputRequests['F-Output-1'].setValues(variables=(
    'S', 'PE', 'PEEQ', 'U', 'RF', 'SDEG', 'NT', 'STATUS'))
### Restart Request ###
mdb.models['Submodel'].steps['i{iterationNum}_Sub_step'].Restart(frequency=1, 
    numberIntervals=0, overlay=ON, timeMarks=OFF)
### Adjust Submodel BC ###
mdb.models['Submodel'].boundaryConditions['SubBC'].move('i{iterationNum-1}_Sub_step', 
    'i{iterationNum}_Sub_step')
mdb.models['Submodel'].boundaryConditions['SubBC'].setValues(globalStep='{iterationNum+1}', 
    globalDrivingRegion='', shellThickness=3.0, absoluteExteriorTolerance=None, 
    exteriorTolerance=0.05)
'''
        file2.writelines(a)
        ######### Write amplitude data in file ################
        tempdata = open('_temp.py', 'r').readlines()
        file2.writelines(tempdata)
        ######### Append additional script in file ###########
        b = f'''
########## Assign temp data to all face ###########
mdb.models['Submodel'].Temperature(amplitude='i{iterationNum}_Temp', createStepName=
    'i{iterationNum}_Sub_step', crossSectionDistribution=CONSTANT_THROUGH_THICKNESS, 
    distributionType=UNIFORM, magnitudes=(1.0, ), name='Temperature_field', 
    region=mdb.models['Submodel'].rootAssembly.sets['Set_temperature_surfaces'])
###### Create and Submit the job #######
### Create Job ###
mdb.models['Submodel'].rootAssembly.regenerate()
mdb.Job(name='i{iterationNum}_Sub', model='Submodel', description='', type=RESTART, 
    atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
    memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
    explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
    modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
    scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=2, 
    numDomains=2, numGPUs=0)
'''
        file2.writelines(b)
        file2.close()
    else :
        a = f'''### Create Mid-step ###
mdb.models['Submodel'].StaticStep(initialInc=0.1, maxInc=1, minInc=5e-06, maxNumInc=1000, 
    name='i{iterationNum-1}_Sub_step', previous='i0_Sub_step', timePeriod=1.0)
### step new ###
mdb.models['Submodel'].setValues(globalJob='i{iterationNum}_Sys_SR', restartJob='i{iterationNum-1}_Sub', 
    restartStep='i{iterationNum-1}_Sub_step')
mdb.models['Submodel'].StaticStep(initialInc=0.1, maxInc=1, minInc=1e-010, 
    name='i{iterationNum}_Sub_step', previous='i{iterationNum-1}_Sub_step', timePeriod=1.0, matrixSolver=DIRECT, 
    matrixStorage=UNSYMMETRIC)
# Improve convergence #
mdb.models['Submodel'].steps['i{iterationNum}_Sub_step'].setValues(adaptiveDampingRatio=0.05
    , continueDampingFactors=False, stabilizationMagnitude=0.0002,
    stabilizationMethod=DISSIPATED_ENERGY_FRACTION)
## Output Request ##
mdb.models['Submodel'].fieldOutputRequests['F-Output-1'].setValues(variables=(
    'S', 'PE', 'PEEQ', 'U', 'RF', 'SDEG', 'NT', 'STATUS'))
### Restart Request ###
mdb.models['Submodel'].steps['i{iterationNum}_Sub_step'].Restart(frequency=1, 
    numberIntervals=0, overlay=ON, timeMarks=OFF)
### Adjust Submodel BC ###
mdb.models['Submodel'].boundaryConditions['SubBC'].move('i0_Sub_step', 
    'i{iterationNum}_Sub_step')
mdb.models['Submodel'].boundaryConditions['SubBC'].setValues(globalStep='{iterationNum+1}', 
    globalDrivingRegion='', shellThickness=3.0, absoluteExteriorTolerance=None, 
    exteriorTolerance=0.05)
'''
        file2.writelines(a)
    ######### Write amplitude data in file ################
        tempdata = open('_temp.py', 'r').readlines()
        file2.writelines(tempdata)
    ######### Append additional script in file ###########
        b = f'''
########## Assign temp data to all face ###########
mdb.models['Submodel'].Temperature(amplitude='i{iterationNum}_Temp', createStepName=
    'i{iterationNum}_Sub_step', crossSectionDistribution=CONSTANT_THROUGH_THICKNESS, 
    distributionType=UNIFORM, magnitudes=(1.0, ), name='Temperature_field', 
    region=mdb.models['Submodel'].rootAssembly.sets['Set_temperature_surfaces'])
###### Create and Submit the job #######
### Create Job ###
mdb.models['Submodel'].rootAssembly.regenerate()
mdb.Job(name='i{iterationNum}_Sub', model='Submodel', description='', type=RESTART, 
    atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
    memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
    explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
    modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
    scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=2, 
    numDomains=2, numGPUs=0)
'''
        file2.writelines(b)
        file2.close()
# Create a script will be executed by DOS later #
    data1=open(newscriptname,'r').readlines()
    SR_Script=open(currentPath+"\\Sub_Script.py",'w')
    SR_Script.writelines(data1)
    RunJob = f'''
mdb.jobs['i{iterationNum}_Sub'].submit(consistencyChecking=OFF)
mdb.jobs['i{iterationNum}_Sub'].waitForCompletion()
'''
    SR_Script.writelines(RunJob)
    SR_Script.close()


def ProbModel(probSize, iterationNum):
    subfile = currentPath + f'/i{iterationNum}_Sub.py'
    probfile = currentPath + f'/i{iterationNum}_Prob.py'
    shutil.copyfile(subfile, probfile)
    additionallines=f'''
# Modify the created step to prob step #
mdb.models['Submodel'].steps['i{iterationNum}_Sub_step'].setValues(initialInc=0.001, maxInc=
    {probSize}, minInc=5e-10, timePeriod={probSize}, matrixSolver=DIRECT, matrixStorage=UNSYMMETRIC)
mdb.models['Submodel'].boundaryConditions['SubBC'].setValues(
    absoluteExteriorTolerance=None, exteriorTolerance=0.05, 
    globalDrivingRegion='', scale={probSize}, timeScale=ON)
### Create Job ###
mdb.models['Submodel'].rootAssembly.regenerate()
'''
    if iterationNum == 0:
        jobfile = f'''
mdb.Job(atTime=None, contactPrint=OFF, description='', echoPrint=OFF,
    explicitPrecision=SINGLE, getMemoryFromAnalysis=True, historyPrint=OFF,
    memory=90, memoryUnits=PERCENTAGE, model='Submodel', modelPrint=OFF,
    multiprocessingMode=DEFAULT, name='i{iterationNum}_Prob', nodalOutputPrecision=SINGLE,
    numCpus=2, numDomains=2, numGPUs=0, queue=None, resultsFormat=ODB, scratch=
    '', type=ANALYSIS, userSubroutine='', waitHours=0, waitMinutes=0)
'''
    else:
        jobfile = f'''
mdb.Job(name='i{iterationNum}_Prob', model='Submodel', description='', type=RESTART, 
    atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
    memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
    explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
    modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
    scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=2, 
    numDomains=2, numGPUs=0)
'''
    newprobfile=open(f'i{iterationNum}_Prob.py', 'a')
    newprobfile.writelines(additionallines)
    newprobfile.writelines(jobfile)
    newprobfile.close()
    RunJob=f'''
# Run Job and post processing #
mdb.jobs['i{iterationNum}_Prob'].submit(consistencyChecking=OFF)
mdb.jobs['i{iterationNum}_Prob'].waitForCompletion()
'''
# Copy the script for os execute #
    probfile_basic = currentPath + f'//i{iterationNum}_Prob.py'
    prob_model = currentPath + '/Prob_Model.py'
    shutil.copyfile(probfile_basic, prob_model)
    prob_model_run = open('Prob_Model.py', 'a')
    prob_model_run.writelines(RunJob)
    prob_model_run.close()


def Convergence_checking(currentPath, iterationNum):
    # change work directory
    os.chdir(currentPath + '\\outputSR\\')
    status_file = open(f"i{iterationNum}_Prob.sta", 'r')
    for line in status_file:
        if "THE ANALYSIS HAS NOT BEEN COMPLETED" in line:
            # if not converged, turn the switch down.
            convergence = False
        else:
            convergence = True
    status_file.close()
    os.chdir(currentPath)
    return convergence


############################### Using this function to post-processing ###############################
### Acquire file surffix name ###
def suffix(file, *suffixName) :
    array = map(file.endswith, suffixName)
    if True in array:
        return True
    else:
        return False


def Post_Processing():
    run('call abaqus cae noGUI=_Post_Processing.py', shell=True)
    os.chdir(currentPath + '\\outputSR\\')
    iris_concat = pd.DataFrame()
    for name in sorted(glob.glob('i*_displacement.txt'), key=len):
        iris = pd.read_table(name, skiprows=5, header=None, names=['Time', 'RF', 'RF1', 'RF2', 'RF3', 'U1', 'U2', 'U3'], delim_whitespace=True)
        df = pd.DataFrame(iris)
        #data = df.head(1) # Taking first point as standard.
        iris_concat = pd.concat([iris_concat, df])
    #### Remove other unneccessary files ##
    targetDir= os.getcwd()
    for file in os.listdir(targetDir):
        targetFile = os.path.join(targetDir, file)
        if suffix(file, '.com'): #'.mdl', '.stt', '.msg', '.prt', '.sim', '.sta', '.res', '.inp', '.dat',
            os.remove(targetFile)
    #### Write output to excel ####
    os.chdir(currentPath)
    iris_concat.to_excel('./_Force_Displacement.xlsx')  # , index = False


def Stiffness_after_failure():
    SOF1_previous = SOF2_previous = SOF3_previous = 200
    SOF1_final = SOF2_final = SOF3_final = 200
    length1 = length2 = length3 = 1
    # Find Contact pair force #
    outputfile = open('stiffness.log', 'w')
    stiffness_data = '%s %s %s\n 0 0 0\n %s %s %s\n %s %s %s\n' % (
    abs(SOF1_previous), abs(SOF2_previous), abs(SOF3_previous),
    abs(SOF1_final), abs(SOF2_final), abs(SOF3_final),
    length1, length2, abs(length3))
    outputfile.writelines(stiffness_data)
    outputfile.close()

########################################################################################################
######################################### Main Function ################################################
########################################################################################################
currentPath=os.getcwd()
Number=int(25)
### Create an iteration.log file for other programs ###
iterationNum = 0
probSize=1.01
Iteration_log = open('_iteration.log', 'w')
Iteration_log.writelines(str(iterationNum))
Iteration_log.close()
convergence = True
Element_status_switch = 1
while iterationNum < Number:
    SRupdate(iterationNum)
    # Create a batch file named batchFile #
    print('i%sSR__Script updating is finished, now running script, please waiting...'%iterationNum)
    run("call abaqus cae noGUI=SR_Script.py", shell=True)
    ### Monitor for element deletion ###
    if os.path.exists(currentPath + '\\Element_Monitor.txt'):
        Element_monitor = open('Element_Monitor.txt', 'r')
        Element_status = Element_monitor.readlines()
        Element_monitor.close()
        Element_status_switch = Element_status[0].split()
        # Make it float #
        Element_status_switch = float(Element_status_switch[0])
    # if Part not failed in this step, run sub model and prob step #
    if (Element_status_switch == 1) and (convergence == True):
        # First run HT and SR, output the Amplitude.py in the meantime #
        Subupdate(iterationNum)
        print('i%sSub__Script updating is finished, now running script, please waiting...' % iterationNum)
        # Sub Model Requires Amp.py data as input #
        run("call abaqus cae noGUI=Sub_Script.py", shell=True)
        ProbModel(probSize, iterationNum)
        print("The prob step is running ...")
        run("call abaqus cae noGUI=Prob_Model.py", shell=True)
        # Convergency checking, if not converged, the element status assumes to be 0 in next iteration
        convergence = Convergence_checking(currentPath, iterationNum)
        if convergence == True:
            print("Stiffness calculating")
            run("call abaqus cae noGUI=_outputRequest.py", shell=True)
        else:
            Stiffness_after_failure()
    # if Part failed in this step, stiffness assumed to be constant #
    else:
        Stiffness_after_failure()
    iterationNum += 1
    Iteration_log = open('_iteration.log', 'w')
    Iteration_log.writelines(str(iterationNum))
    Iteration_log.close()
    print('Step %s is finished successfully.' % iterationNum)
print('The multi-scale coupling process is finished, post-processing data now...')
## Post-processing ##
Post_Processing()
print('All done.')
