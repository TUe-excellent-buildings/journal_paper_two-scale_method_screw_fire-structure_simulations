from abaqus import *
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from abaqusConstants import *
cliCommand("""session.journalOptions.setValues(replayGeometry=COORDINATE,
	recoverGeometry=COORDINATE)""")
### use this lines for use in FDS-2-Abaqus (relative path)
currentPath = os.getcwd()
### Set directory to outputHT, if not exists, create the folder ##
if not os.path.exists(currentPath + '\\outputSR\\'):
    os.makedirs(currentPath + '\\outputSR\\')
os.chdir(currentPath + '\\outputSR\\')
# Change model name #
mdb.models.changeKey(fromName='Model-1', toName='Model-SR')
mod=mdb.models['Model-SR']
modRa = mod.rootAssembly
# Create plate #
mod.ConstrainedSketch(name='__profile__', sheetSize=200.0)
mod.sketches['__profile__'].rectangle(point1=(-50.0, -50.0),
    point2=(50.0, 50.0))
mod.sketches['__profile__'].CircleByCenterPerimeter(center=(
    0.0, 0.0), point1=(3.2, 0.0))
mod.Part(dimensionality=THREE_D, name='Part-1', type=
    DEFORMABLE_BODY)
mod.parts['Part-1'].BaseSolidExtrude(depth=0.9, sketch=
    mod.sketches['__profile__'])
del mod.sketches['__profile__']
# Create datum for partition #
mod.parts['Part-1'].DatumPlaneByPrincipalPlane(offset=-15,
    principalPlane=YZPLANE)
mod.parts['Part-1'].DatumPlaneByPrincipalPlane(offset=15,
    principalPlane=YZPLANE)
mod.parts['Part-1'].DatumPlaneByPrincipalPlane(offset=-15,
    principalPlane=XZPLANE)
mod.parts['Part-1'].DatumPlaneByPrincipalPlane(offset=15,
    principalPlane=XZPLANE)
mod.parts['Part-1'].PartitionCellByDatumPlane(cells=
    mod.parts['Part-1'].cells.findAt(((50.0, 16.666667,
    0.6), )), datumPlane=mod.parts['Part-1'].datums[2])
mod.parts['Part-1'].PartitionCellByDatumPlane(cells=
    mod.parts['Part-1'].cells.findAt(((11.666667, 50.0,
    0.6), )), datumPlane=mod.parts['Part-1'].datums[3])
mod.parts['Part-1'].PartitionCellByDatumPlane(cells=
    mod.parts['Part-1'].cells.findAt(((2.5, -50.0, 0.6), ),
    ((-21.666667, -50.0, 0.6), ), ((21.666667, 50.0, 0.6), ), ), datumPlane=
    mod.parts['Part-1'].datums[5])
mod.parts['Part-1'].PartitionCellByDatumPlane(cells=
    mod.parts['Part-1'].cells.findAt(((35.833333,
    -11.666667, 0.9), ), ((2.5, -50.0, 0.6), ), ((-21.666667, -50.0, 0.6), ), )
    , datumPlane=mod.parts['Part-1'].datums[4])
mod.parts['Part-1'].PartitionFaceByShortestPath(faces=
    mod.parts['Part-1'].faces.findAt(((6.162443, -6.739719,
    0.9), )), point1=mod.parts['Part-1'].vertices.findAt((
    15.0, 15.0, 0.9), ), point2=
    mod.parts['Part-1'].vertices.findAt((-15.0, -15.0, 0.9),
    ))
mod.parts['Part-1'].PartitionCellByPlanePointNormal(cells=
    mod.parts['Part-1'].cells.findAt(((3.172939, 0.415281,
    0.6), )), normal=mod.parts['Part-1'].edges.findAt((
    5.447056, 5.447056, 0.9), ), point=
    mod.parts['Part-1'].InterestingPoint(
    mod.parts['Part-1'].edges.findAt((3.138513, 0.624289,
    0.9), ), CENTER))
mod.parts['Part-1'].PartitionCellByPlanePointNormal(cells=
    mod.parts['Part-1'].cells.findAt(((-6.162443, 6.739719,
    0.9), ), ((-2.537255, 1.949959, 0.6), ), ), normal=
    mod.parts['Part-1'].edges.findAt((11.815685, -11.815685,
    0.9), ), point=mod.parts['Part-1'].InterestingPoint(
    mod.parts['Part-1'].edges.findAt((-2.956415, 1.224587,
    0.9), ), CENTER))
# Copy plate 1 to plate 2 #
mod.Part(name='Part-2', objectToCopy=
    mod.parts['Part-1'])
# mod.parts['Part-2'].features['Solid extrude-1'].setValues(
#     depth=0.75)
mod.parts['Part-2'].regenerate()
mod.parts['Part-2'].regenerate()
### MATERIAL PROPERTY ##
# S350
mod.Material(name='S350')
mod.materials['S350'].Elastic(table=((
    209550.0, 0.3, 20.0), (209550.0, 0.3, 100.0), (188595.0, 0.3, 200.0), (
    167640.0, 0.3, 300.0), (146685.0, 0.3, 400.0), (125730.0, 0.3, 500.0), (
    64960.5, 0.3, 600.0), (27241.5, 0.3, 700.0), (18859.5, 0.3, 800.0), (
    14144.625, 0.3, 900.0), (9429.75, 0.3, 1000.0)), temperatureDependency=ON)
mod.materials['S350'].Plastic(table=((355.6,
    0.0, 20.0), (361.07, 0.01512, 20.0), (463.77, 0.05094, 20.0), (571.0,
    0.15129, 20.0), (286.52408, 0.0, 200.0), (333.4481835, 0.004949834, 200.0),
    (349.2655592, 0.009875289, 200.0), (358.0812921, 0.014776602, 200.0), (
    362.0246571, 0.019654009, 200.0), (404.6108103, 0.139630126, 200.0), (
    149.1105857, 0.0, 400.0), (286.2301475, 0.00496231, 400.0), (330.4816972,
    0.009900117, 400.0), (353.6011561, 0.014813662, 400.0), (362.0193422,
    0.019703183, 400.0), (404.6060963, 0.13967374, 400.0), (99.68873174, 0.0,
    500.0), (217.5611719, 0.004967861, 500.0), (255.5081348, 0.009911165,
    500.0), (275.2677521, 0.014830152, 500.0), (282.3747565, 0.019725061,
    500.0), (315.592462, 0.139693145, 500.0), (30.03342951, 0.0, 600.0), (
    120.6362475, 0.004976065, 600.0), (149.79964, 0.009927492, 600.0), (
    164.8747969, 0.014854523, 600.0), (170.1488612, 0.019757397, 600.0), (
    190.1646616, 0.139721825, 600.0), (1.952501815, 0.0, 800.0), (26.49741639,
    0.004984972, 800.0), (34.36910219, 0.009945217, 800.0), (38.42375339,
    0.014880979, 800.0), (39.82293269, 0.019792499, 800.0), (44.50738463,
    0.139752959, 800.0), (0.35500006, 0.0, 1000.0), (9.525340641, 0.004986607,
    1000.0), (12.45412004, 0.009948471, 1000.0), (13.96190763, 0.014885837,
    1000.0), (14.48114736, 0.019798944, 1000.0), (16.18457528, 0.139758676,
    1000.0)), temperatureDependency=ON)
mod.HomogeneousSolidSection(material='S350', name='S350',
    thickness=None)
# Q550
mod.Material(name='Q550')
mod.materials['Q550'].Elastic(table=((210000.0,
    0.3, 20.0), (210000.0, 0.3, 100.0), (189000.0, 0.3, 200.0), (168000.0, 0.3,
    300.0), (147000.0, 0.3, 400.0), (126000.0, 0.3, 500.0), (65100.0, 0.3,
    600.0), (27300.0, 0.3, 700.0), (18900.0, 0.3, 800.0), (14175.0, 0.3,
    900.0), (9450.0, 0.3, 1000.0), (4725.0, 0.3, 1100.0)),
    temperatureDependency=ON)
mod.materials['Q550'].Plastic(table=((641.95, 0.0,
    20.0), (840.8, 0.04362, 20.0), (484.0180057, 0.0, 200.0), (561.5970425,
    0.004351749, 200.0), (588.7508359, 0.008684643, 200.0), (603.6768729,
    0.012998843, 200.0), (610.0999758, 0.017294511, 200.0), (681.9005789,
    0.137537668, 200.0), (208.526551, 0.0, 400.0), (389.6994594, 0.004634956,
    400.0), (457.6018199, 0.009248529, 400.0), (492.9908624, 0.013840914,
    400.0), (505.6153239, 0.018412306, 400.0), (565.1385236, 0.138528884,
    400.0), (126.7964434, 0.0, 500.0), (269.465182, 0.004737333, 500.0), (
    321.9127495, 0.009452329, 500.0), (349.1765722, 0.014145198, 500.0), (
    358.8316694, 0.018816146, 500.0), (401.0730478, 0.138887026, 500.0), (
    25.34705847, 0.0, 600.0), (98.42324981, 0.004890694, 600.0), (125.0296922,
    0.009757585, 600.0), (138.7831506, 0.014600905, 600.0), (143.5511245,
    0.019420879, 600.0), (160.4455888, 0.139423356, 600.0), (2.144021889, 0.0,
    800.0), (27.60637673, 0.004959322, 800.0), (37.13012554, 0.009894171,
    800.0), (42.04334869, 0.014804787, 800.0), (43.72479675, 0.019691406,
    800.0), (48.8691428, 0.139663295, 800.0), (0.792002987, 0.0, 900.0), (
    13.78412133, 0.004973643, 900.0), (18.36745701, 0.009922671, 900.0), (
    20.72788552, 0.014847326, 900.0), (21.53715265, 0.019747848, 900.0), (
    24.07081534, 0.139713356, 900.0)), temperatureDependency=ON)
mod.HomogeneousSolidSection(material='Q550', name='Q550',
    thickness=None)
# Experiment_70_7
mod.Material(name='Experiment_70_7')
mod.materials['Experiment_70_7'].Elastic(table=((210000.0, 0.3), ))
mod.materials['Experiment_70_7'].Plastic(table=((488.5897293, 0.0), (490.7344355, 0.004409953), (492.8697468,
    0.008800543), (494.9957451, 0.013171941), (497.1125114, 0.017524312), (
    555.587823, 0.137741437)))
mod.HomogeneousSolidSection(material='Experiment_70_7', name='Experiment_70_7',
    thickness=None)
## Assign property ##
mod.parts['Part-1'].SectionAssignment(offset=0.0,
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    cells=mod.parts['Part-1'].cells.findAt(((-1.949959,
    -2.537255, 0.6), ), ((2.450884, 2.057466, 0.6), ), ((-6.162443, 6.739719,
    0.9), ), ((-50.0, -5.0, 0.6), ), ((-2.537255, -1.949959, 0.3), ), ((
    26.666667, -26.666667, 0.0), ), ((38.333333, -5.0, 0.0), ), ((-26.666667,
    26.666667, 0.0), ), ((-5.0, 26.666667, 0.9), ), ((-5.0, -26.666667, 0.0),
    ), ((-38.333333, -26.666667, 0.0), ), ((38.333333, 26.666667, 0.0), ), )),
    sectionName='Q550', thicknessAssignment=FROM_SECTION)
mod.parts['Part-2'].SectionAssignment(offset=0.0,
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    cells=mod.parts['Part-2'].cells.findAt(((-1.949959,
    -2.537255, 0.5), ), ((2.450884, 2.057466, 0.5), ), ((-6.162443, 6.739719,
    0.9), ), ((-50.0, -5.0, 0.5), ), ((-2.537255, -1.949959, 0.25), ), ((
    26.666667, -26.666667, 0.0), ), ((38.333333, -5.0, 0.0), ), ((-26.666667,
    26.666667, 0.0), ), ((-5.0, 26.666667, 0.9), ), ((-5.0, -26.666667, 0.0),
    ), ((-38.333333, -26.666667, 0.0), ), ((38.333333, 26.666667, 0.0), ), )),
    sectionName='S350', thicknessAssignment=FROM_SECTION)
### Assembly ###
modRa.DatumCsysByDefault(CARTESIAN)
modRa.Instance(dependent=ON, name='Part-1-1',
    part=mod.parts['Part-1'])
modRa.Instance(dependent=ON, name='Part-2-1',
    part=mod.parts['Part-2'])
modRa.instances['Part-1-1'].translate(vector=(
    44.0, 0.0, 0.0))
modRa.translate(instanceList=('Part-1-1', ),
    vector=(-44.0, 0.0, 0.9))
### INTERACTION ###
## Create Spring ##
modRa.ReferencePoint(point=(0.0, 0.0, 0.0))
modRa.features.changeKey(fromName='RP-1', toName=
    'RP-2')
modRa.ReferencePoint(point=(0.0, 0.0, 1.8))
modRa.features.changeKey(fromName='RP-1', toName=
    'RP-3')
modRa.WirePolyLine(mergeType=IMPRINT, meshable=
    False, points=((modRa.referencePoints[6],
    modRa.referencePoints[7]), ))
modRa.features.changeKey(fromName='Wire-1',
    toName='Wire-1')
modRa.Set(edges=
    modRa.edges.findAt(((0.0, 0.0, 0.0), )),
    name='Wire-1-Set-1')
### Mesh ###
# mesh part-1 #
mod.parts['Part-1'].seedPart(deviationFactor=0.1,
    minSizeFactor=0.1, size=4.0)
mod.parts['Part-1'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Part-1'].edges.findAt(((50.0, -50.0,
    0.5), )), number=4)
mod.parts['Part-1'].seedEdgeByBias(biasMethod=SINGLE,
    constraint=FINER, end1Edges=
    mod.parts['Part-1'].edges.findAt(((-3.147792, -3.147792,
    0.0), ), ((3.147792, 3.147792, 0.9), ), ((-3.147792, 3.147792, 0.9), ), ((
    3.147792, -3.147792, 0.0), ), ), end2Edges=
    mod.parts['Part-1'].edges.findAt(((-6.049264, -6.049264,
    0.9), ), ((6.049264, 6.049264, 0.0), ), ((-6.049264, 6.049264, 0.0), ), ((
    6.049264, -6.049264, 0.9), ), ), number=9, ratio=5.0)
mod.parts['Part-1'].generateMesh()
# mesh part-2 #
mod.parts['Part-2'].seedPart(deviationFactor=0.1,
    minSizeFactor=0.1, size=4.0)
mod.parts['Part-2'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Part-2'].edges.findAt(((50.0, -50.0,
    0.5), )), number=4)
mod.parts['Part-2'].seedEdgeByBias(biasMethod=SINGLE,
    constraint=FINER, end1Edges=
    mod.parts['Part-2'].edges.findAt(((-3.147792, -3.147792,
    0.0), ), ((3.147792, 3.147792, 0.9), ), ((-3.147792, 3.147792, 0.9), ), ((
    3.147792, -3.147792, 0.0), ), ), end2Edges=
    mod.parts['Part-2'].edges.findAt(((-6.049264, -6.049264,
    0.9), ), ((6.049264, 6.049264, 0.0), ), ((-6.049264, 6.049264, 0.0), ), ((
    6.049264, -6.049264, 0.9), ), ), number=9, ratio=5.0)
mod.parts['Part-2'].generateMesh()
modRa.regenerate()
# Create coupling points #
modRa.Set(name='Set-RF-2_NODES', nodes=
    modRa.instances['Part-2-1'].nodes[42:45]+\
    modRa.instances['Part-2-1'].nodes[49:52]+\
    modRa.instances['Part-2-1'].nodes[102:105]+\
    modRa.instances['Part-2-1'].nodes[173:176]+\
    modRa.instances['Part-2-1'].nodes[516:528]+\
    modRa.instances['Part-2-1'].nodes[652:664]+\
    modRa.instances['Part-2-1'].nodes[840:852]+\
    modRa.instances['Part-2-1'].nodes[1012:1024])
modRa.Set(name='Set-RF-3_NODES', nodes=
    modRa.instances['Part-1-1'].nodes[1:3]+\
    modRa.instances['Part-1-1'].nodes[8:9]+\
    modRa.instances['Part-1-1'].nodes[11:12]+\
    modRa.instances['Part-1-1'].nodes[15:16]+\
    modRa.instances['Part-1-1'].nodes[45:49]+\
    modRa.instances['Part-1-1'].nodes[89:99]+\
    modRa.instances['Part-1-1'].nodes[108:111]+\
    modRa.instances['Part-1-1'].nodes[125:130]+\
    modRa.instances['Part-1-1'].nodes[141:150]+\
    modRa.instances['Part-1-1'].nodes[234:238]+\
    modRa.instances['Part-1-1'].nodes[572:592]+\
    modRa.instances['Part-1-1'].nodes[676:696]+\
    modRa.instances['Part-1-1'].nodes[767:772]+\
    modRa.instances['Part-1-1'].nodes[775:780]+\
    modRa.instances['Part-1-1'].nodes[783:788]+\
    modRa.instances['Part-1-1'].nodes[791:796]+\
    modRa.instances['Part-1-1'].nodes[1024:1044])
## Create moving edge for coupling ##
modRa.Set(faces=
    modRa.instances['Part-2-1'].faces.findAt(((
    50.0, -2.5, 0.25), ), ((-50.0, -21.666667, 0.25), ), ((-50.0, -2.5, 0.5),
    ), ((50.0, -21.666667, 0.5), ), ((21.666667, -50.0, 0.25), ), ((2.5, 50.0,
    0.25), ), ((21.666667, 50.0, 0.5), ), ((-21.666667, -50.0, 0.5), ), ((
    -50.0, 21.666667, 0.5), ), ((-21.666667, 50.0, 0.25), ), ((50.0, 21.666667,
    0.25), ), ((2.5, -50.0, 0.5), ), ), name='Set-constrain-edge')
# Coupling for the spring #
mod.Coupling(controlPoint=Region(referencePoints=(
    modRa.referencePoints[6], )), couplingType=
    DISTRIBUTING, influenceRadius=WHOLE_SURFACE, localCsys=None, name=
    'Constraint-2', surface=
    modRa.sets['Set-RF-2_NODES'], u1=ON, u2=ON,
    u3=ON, ur1=ON, ur2=ON, ur3=ON, weightingMethod=UNIFORM)
mod.Coupling(controlPoint=Region(referencePoints=(
    modRa.referencePoints[7], )), couplingType=
    DISTRIBUTING, influenceRadius=WHOLE_SURFACE, localCsys=None, name=
    'Constraint-3', surface=
    modRa.sets['Set-RF-3_NODES'], u1=ON, u2=ON,
    u3=ON, ur1=ON, ur2=ON, ur3=ON, weightingMethod=UNIFORM)
### Step ###
mod.StaticStep(initialInc=0.5, maxInc=1, minInc=5e-10,
    name='i0_SR-Step', nlgeom=ON, previous='Initial', timePeriod=1.0, solutionTechnique=
    QUASI_NEWTON)
### Improve convergence ##
mod.steps['i0_SR-Step'].setValues(adaptiveDampingRatio=0.05,
    continueDampingFactors=False, stabilizationMagnitude=0.0002,
    stabilizationMethod=DISSIPATED_ENERGY_FRACTION)
## Restart Request ##
mod.steps['i0_SR-Step'].Restart(frequency=0,
    numberIntervals=1, overlay=ON, timeMarks=OFF)
## Output Request ##
mod.fieldOutputRequests['F-Output-1'].setValues(variables=(
    'S', 'PE', 'PEEQ', 'PEMAG', 'LE', 'U', 'RF', 'CF', 'CSTRESS', 'CDISP',
    'NT'))
### BC ###
## Fixed plate 1 ##
# Reference point #
modRa.ReferencePoint(point=(0.0, 0.0, 5))
modRa.regenerate()
## Fixed plate 1 ##
mod.EncastreBC(createStepName='Initial', localCsys=None,
    name='BC-1', region=modRa.sets['Set-constrain-edge'])
## Coupling moving plate ##
modRa.Surface(name='Moving_surf', side1Faces=
    modRa.instances['Part-1-1'].faces.findAt(((
    50.0, -2.5, 1.2), ), ((-50.0, -21.666667, 1.2), ), ((-50.0, -2.5, 1.5), ),
    ((50.0, -21.666667, 1.5), ), ((21.666667, -50.0, 1.2), ), ((2.5, 50.0,
    1.2), ), ((21.666667, 50.0, 1.5), ), ((-21.666667, -50.0, 1.5), ), ((-50.0,
    21.666667, 1.5), ), ((-21.666667, 50.0, 1.2), ), ((50.0, 21.666667, 1.2),
    ), ((2.5, -50.0, 1.5), ), ))
modRa.Set(name='m_Set-9', referencePoints=(
    modRa.referencePoints[15], ))
mod.Coupling(controlPoint=
    modRa.sets['m_Set-9'], couplingType=DISTRIBUTING
    , influenceRadius=WHOLE_SURFACE, localCsys=None, name='Constraint-1',
    surface=modRa.surfaces['Moving_surf'], u1=ON,
    u2=ON, u3=ON, ur1=ON, ur2=ON, ur3=ON)
## Moving edge ##
modRa.Set(name='Set-10', referencePoints=(
    modRa.referencePoints[15], ))
mod.DisplacementBC(amplitude=UNSET, createStepName=
    'i0_SR-Step', distributionType=UNIFORM, fieldName='', fixed=OFF, localCsys=
    None, name='BC-2', region=
    modRa.sets['Set-10'], u1=0.112, u2=0.0, u3=
    0.03, ur1=0.0, ur2=0.0, ur3=0.0)
# Constraint the reference node #
mod.DisplacementBC(amplitude=UNSET, createStepName='Initial'
    , distributionType=UNIFORM, fieldName='', localCsys=None, name='BC-3',
    region=Region(referencePoints=(
    modRa.referencePoints[6],
    modRa.referencePoints[7], )), u1=UNSET, u2=
    UNSET, u3=UNSET, ur1=SET, ur2=SET, ur3=SET)
## Create Contact Property ##
mod.ContactProperty('IntProp-Contact')
mod.interactionProperties['IntProp-Contact'].ThermalConductance(
    clearanceDepTable=((100000.0, 0.0), (0.0, 0.015)), clearanceDependency=ON,
    definition=TABULAR, dependenciesC=0, massFlowRateDependencyC=OFF,
    pressureDependency=OFF, temperatureDependencyC=OFF)
## Assign contact surface ##
modRa.Surface(name='CP-1-Part-1-1', side1Faces=
    modRa.instances['Part-1-1'].faces.findAt(((
    -3.804789, -3.371832, 0.9), ), ((3.371832, 3.804789, 0.9), ), ((3.758506,
    3.465685, 0.9), ), ((35.833333, -2.5, 0.9), ), ((-3.371832, -3.804789,
    0.9), ), ((-21.666667, -2.5, 0.9), ), ((-35.833333, -21.666667, 0.9), ), ((
    35.833333, 21.666667, 0.9), ), ((-2.5, -21.666667, 0.9), ), ((21.666667,
    -21.666667, 0.9), ), ((-21.666667, 21.666667, 0.9), ), ((2.5, 21.666667,
    0.9), ), ))
modRa.Surface(name='CP-1-Part-2-1', side1Faces=
    modRa.instances['Part-2-1'].faces.findAt(((
    -3.804789, 3.371832, 0.9), ), ((3.758506, -3.465685, 0.9), ), ((3.371832,
    -3.804789, 0.9), ), ((35.833333, -21.666667, 0.9), ), ((2.5, -21.666667,
    0.9), ), ((-21.666667, -21.666667, 0.9), ), ((-35.833333, 21.666667,
    0.9), ), ((-2.5, 21.666667, 0.9), ), ((21.666667, -2.5, 0.9), ), ((
    -3.371832, 3.804789, 0.9), ), ((21.666667, 21.666667, 0.9), ), ((
    -35.833333, -2.5, 0.9), ), ))
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE,
    interactionProperty='IntProp-Contact', master=
    modRa.surfaces['CP-1-Part-1-1'], name=
    'CP-1-Part-1-1-Part-2-1', slave=
    modRa.surfaces['CP-1-Part-2-1'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
# Temp amplitude
mod.TabularAmplitude(data=((0.0, 0.0), (5.0, 800.0)), name=
    'Amp-Temp', smooth=SOLVER_DEFAULT, timeSpan=TOTAL)
modRa.Set(cells=
    modRa.instances['Part-1-1'].cells.findAt(((
    -1.949959, -2.537255, 1.5), ), ((2.450884, 2.057466, 1.5), ), ((-6.162443,
    6.739719, 1.8), ), ((-50.0, -5.0, 1.5), ), ((-2.537255, -1.949959, 1.2), ),
    ((26.666667, -26.666667, 0.9), ), ((38.333333, -5.0, 0.9), ), ((-26.666667,
    26.666667, 0.9), ), ((-5.0, 26.666667, 1.8), ), ((-5.0, -26.666667, 0.9),
    ), ((-38.333333, -26.666667, 0.9), ), ((38.333333, 26.666667, 0.9), ), )+\
    modRa.instances['Part-2-1'].cells.findAt(((
    -1.949959, -2.537255, 0.5), ), ((2.450884, 2.057466, 0.5), ), ((-6.162443,
    6.739719, 0.9), ), ((-50.0, -5.0, 0.5), ), ((-2.537255, -1.949959, 0.25),
    ), ((26.666667, -26.666667, 0.0), ), ((38.333333, -5.0, 0.0), ), ((
    -26.666667, 26.666667, 0.0), ), ((-5.0, 26.666667, 0.9), ), ((-5.0,
    -26.666667, 0.0), ), ((-38.333333, -26.666667, 0.0), ), ((38.333333,
    26.666667, 0.0), ), ), edges=
    modRa.edges.findAt(((0.0, 0.0, 0.45), )),
    name='Set-7')
# This script set a constant temperature #
mod.Temperature(createStepName='Initial',
    crossSectionDistribution=CONSTANT_THROUGH_THICKNESS, distributionType=
    UNIFORM, magnitudes=(600.0, ), name='Predefined Field-temp', region=
    modRa.sets['Set-7'])
# Temperature output Request ##
modRa.Set(name='Set-Temp_Ref', nodes=
    modRa.instances['Part-1-1'].nodes[1:2]+\
    modRa.instances['Part-2-1'].nodes[4:5])
mod.HistoryOutputRequest(createStepName='i0_SR-Step', name=
    'H-Output-2', rebar=EXCLUDE, region=
    modRa.sets['Set-Temp_Ref'], sectionPoints=
    DEFAULT, variables=('NT', ))
## Changing the plate thickness ##
modRa.regenerate()
mdb.models['Model-SR'].parts['Part-2'].features['Solid extrude-1'].setValues(
    depth=0.876)
mdb.models['Model-SR'].parts['Part-2'].regenerate()
mdb.models['Model-SR'].parts['Part-2'].regenerate()
mdb.models['Model-SR'].parts['Part-2'].generateMesh()
mod.materials['S350'].plastic.setValues(table=((355.6, 0.0,
    20.0), (534.0, 0.13, 20.0), (286.52408, 0.0, 200.0), (333.4481835,
    0.004949834, 200.0), (349.2655592, 0.009875289, 200.0), (358.0812921,
    0.014776602, 200.0), (362.0246571, 0.019654009, 200.0), (404.6108103,
    0.139630126, 200.0), (149.1105857, 0.0, 400.0), (286.2301475, 0.00496231,
    400.0), (330.4816972, 0.009900117, 400.0), (353.6011561, 0.014813662,
    400.0), (362.0193422, 0.019703183, 400.0), (404.6060963, 0.13967374,
    400.0), (99.68873174, 0.0, 500.0), (217.5611719, 0.004967861, 500.0), (
    255.5081348, 0.009911165, 500.0), (275.2677521, 0.014830152, 500.0), (
    282.3747565, 0.019725061, 500.0), (315.592462, 0.139693145, 500.0), (
    30.03342951, 0.0, 600.0), (120.6362475, 0.004976065, 600.0), (149.79964,
    0.009927492, 600.0), (164.8747969, 0.014854523, 600.0), (170.1488612,
    0.019757397, 600.0), (190.1646616, 0.139721825, 600.0), (1.952501815, 0.0,
    800.0), (26.49741639, 0.004984972, 800.0), (34.36910219, 0.009945217,
    800.0), (38.42375339, 0.014880979, 800.0), (39.82293269, 0.019792499,
    800.0), (44.50738463, 0.139752959, 800.0), (0.35500006, 0.0, 1000.0), (
    9.525340641, 0.004986607, 1000.0), (12.45412004, 0.009948471, 1000.0), (
    13.96190763, 0.014885837, 1000.0), (14.48114736, 0.019798944, 1000.0), (
    16.18457528, 0.139758676, 1000.0)))
modRa.regenerate()
modRa.Set(name='Set-RF-2_NODES', nodes=
    modRa.instances['Part-2-1'].nodes[42:45]+\
    modRa.instances['Part-2-1'].nodes[49:52]+\
    modRa.instances['Part-2-1'].nodes[102:105]+\
    modRa.instances['Part-2-1'].nodes[173:176]+\
    modRa.instances['Part-2-1'].nodes[516:528]+\
    modRa.instances['Part-2-1'].nodes[652:664]+\
    modRa.instances['Part-2-1'].nodes[840:852]+\
    modRa.instances['Part-2-1'].nodes[1012:1024])
modRa.Set(name='Set-Temp_Ref', nodes=
    modRa.instances['Part-1-1'].nodes[1:2]+\
    modRa.instances['Part-2-1'].nodes[0:1])
modRa.regenerate()
# Change plate thickness #
mdb.models['Model-SR'].materials['S350'].plastic.setValues(table=((277.0, 0.0,
    20.0), (336.0, 0.29, 20.0), (286.52408, 0.0, 200.0), (333.4481835,
    0.004949834, 200.0), (349.2655592, 0.009875289, 200.0), (358.0812921,
    0.014776602, 200.0), (362.0246571, 0.019654009, 200.0), (404.6108103,
    0.139630126, 200.0), (149.1105857, 0.0, 400.0), (286.2301475, 0.00496231,
    400.0), (330.4816972, 0.009900117, 400.0), (353.6011561, 0.014813662,
    400.0), (362.0193422, 0.019703183, 400.0), (404.6060963, 0.13967374,
    400.0), (99.68873174, 0.0, 500.0), (217.5611719, 0.004967861, 500.0), (
    255.5081348, 0.009911165, 500.0), (275.2677521, 0.014830152, 500.0), (
    282.3747565, 0.019725061, 500.0), (315.592462, 0.139693145, 500.0), (
    30.03342951, 0.0, 600.0), (120.6362475, 0.004976065, 600.0), (149.79964,
    0.009927492, 600.0), (164.8747969, 0.014854523, 600.0), (170.1488612,
    0.019757397, 600.0), (190.1646616, 0.139721825, 600.0), (1.952501815, 0.0,
    800.0), (26.49741639, 0.004984972, 800.0), (34.36910219, 0.009945217,
    800.0), (38.42375339, 0.014880979, 800.0), (39.82293269, 0.019792499,
    800.0), (44.50738463, 0.139752959, 800.0), (0.35500006, 0.0, 1000.0), (
    9.525340641, 0.004986607, 1000.0), (12.45412004, 0.009948471, 1000.0), (
    13.96190763, 0.014885837, 1000.0), (14.48114736, 0.019798944, 1000.0), (
    16.18457528, 0.139758676, 1000.0)))
mdb.models['Model-SR'].parts['Part-2'].features['Solid extrude-1'].setValues(
    depth=1.3)
mdb.models['Model-SR'].parts['Part-2'].regenerate()
mdb.models['Model-SR'].parts['Part-2'].regenerate()
mdb.models['Model-SR'].rootAssembly.regenerate()
mdb.models['Model-SR'].rootAssembly.translate(instanceList=('Part-2-1', ),
    vector=(0.0, 0.0, -0.424))
mdb.models['Model-SR'].parts['Part-2'].generateMesh()
mdb.models['Model-SR'].rootAssembly.regenerate()
mdb.models['Model-SR'].rootAssembly.Set(name='Set-RF-2_NODES', nodes=
    mdb.models['Model-SR'].rootAssembly.instances['Part-2-1'].nodes[42:45]+\
    mdb.models['Model-SR'].rootAssembly.instances['Part-2-1'].nodes[49:52]+\
    mdb.models['Model-SR'].rootAssembly.instances['Part-2-1'].nodes[102:105]+\
    mdb.models['Model-SR'].rootAssembly.instances['Part-2-1'].nodes[173:176]+\
    mdb.models['Model-SR'].rootAssembly.instances['Part-2-1'].nodes[516:528]+\
    mdb.models['Model-SR'].rootAssembly.instances['Part-2-1'].nodes[652:664]+\
    mdb.models['Model-SR'].rootAssembly.instances['Part-2-1'].nodes[840:852]+\
    mdb.models['Model-SR'].rootAssembly.instances['Part-2-1'].nodes[1012:1024])
# Temperature output Request ##
modRa.Set(name='Set-Temp_Ref', nodes=
    modRa.instances['Part-1-1'].nodes[1:2]+\
    modRa.instances['Part-2-1'].nodes[4:5])
modRa.regenerate()
## Job ##
modRa.regenerate()
