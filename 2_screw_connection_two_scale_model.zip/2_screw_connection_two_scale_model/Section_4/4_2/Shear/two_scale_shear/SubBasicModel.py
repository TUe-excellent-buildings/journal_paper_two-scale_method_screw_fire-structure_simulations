# -*- coding: mbcs -*-
from abaqus import *
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from abaqusConstants import *
cliCommand("""session.journalOptions.setValues(replayGeometry=COORDINATE,
	recoverGeometry=COORDINATE)""")
### use this lines for use in FDS-2-Abaqus (relative path)
currentPath = os.getcwd()
### Set directory to outputHT, if not exists, create the folder ##
if not os.path.exists(currentPath + '\\outputSR\\'):
    os.makedirs(currentPath + '\\outputSR\\')
os.chdir(currentPath + '\\outputSR\\')
## Name Model ##
mdb.models.changeKey(fromName='Model-1', toName='Submodel')
mod = mdb.models['Submodel']
### Create Parts ###
mod.ConstrainedSketch(name='__profile__', sheetSize=20.0)
mod.sketches['__profile__'].rectangle(point1=(-15.0, -15.0),
    point2=(15.0, 15.0))
mod.Part(dimensionality=THREE_D, name='Part-1', type=
    DEFORMABLE_BODY)
mod.parts['Part-1'].BaseSolidExtrude(depth=1.5, sketch=
    mod.sketches['__profile__'])
del mod.sketches['__profile__']
# Partition for screw hole #
mod.ConstrainedSketch(gridSpacing=2.12, name='__profile__',
    sheetSize=84.9, transform=
    mod.parts['Part-1'].MakeSketchTransform(
    sketchPlane=mod.parts['Part-1'].faces.findAt((-5.0,
    -5.0, 1.5), ), sketchPlaneSide=SIDE1,
    sketchUpEdge=mod.parts['Part-1'].edges.findAt((15.0,
    7.5, 1.5), ), sketchOrientation=RIGHT, origin=(0.0, 0.0, 1.5)))
mod.parts['Part-1'].projectReferencesOntoSketch(filter=
    COPLANAR_EDGES, sketch=mod.sketches['__profile__'])
mod.sketches['__profile__'].CircleByCenterPerimeter(center=(
    0.0, 0.0), point1=(3.2, 0.0))
mod.parts['Part-1'].CutExtrude(flipExtrudeDirection=OFF,
    sketch=mod.sketches['__profile__'], sketchOrientation=
    RIGHT, sketchPlane=mod.parts['Part-1'].faces.findAt((
    -5.0, -5.0, 1.5), ), sketchPlaneSide=SIDE1, sketchUpEdge=
    mod.parts['Part-1'].edges.findAt((15.0, 7.5, 1.5), ))
del mod.sketches['__profile__']
# Partition for mesh # Partition face
mod.parts['Part-1'].PartitionFaceByShortestPath(faces=
    mod.parts['Part-1'].faces.findAt(((6.539104, -5.306147,
    1.5), ), ), point1=mod.parts['Part-1'].vertices.findAt((
    -15.0, -15.0, 1.5), ), point2=
    mod.parts['Part-1'].vertices.findAt((15.0, 15.0, 1.5),
    ))
mod.parts['Part-1'].PartitionFaceByShortestPath(faces=
    mod.parts['Part-1'].faces.findAt(((5.871832, 6.304789,
    1.5), ), ((6.258506, 5.965685, 1.5), ), ), point1=
    mod.parts['Part-1'].vertices.findAt((-15.0, 15.0, 1.5),
    ), point2=mod.parts['Part-1'].vertices.findAt((15.0,
    -15.0, 1.5), ))
# Partition for mesh # Partition cell
mod.parts['Part-1'].PartitionCellByPlanePointNormal(cells=
    mod.parts['Part-1'].cells.findAt(((-6.739719, 6.162443,
    1.5), )), normal=mod.parts['Part-1'].edges.findAt((
    11.815685, -11.815685, 1.5), ), point=
    mod.parts['Part-1'].InterestingPoint(
    mod.parts['Part-1'].edges.findAt((-1.224587, 2.956415,
    1.5), ), CENTER))
mod.parts['Part-1'].PartitionCellByPlanePointNormal(cells=
    mod.parts['Part-1'].cells.findAt(((2.450884, 2.057466,
    0.5), ), ((-6.739719, 6.162443, 1.5), ), ), normal=
    mod.parts['Part-1'].edges.findAt((11.815685, 11.815685,
    1.5), ), point=mod.parts['Part-1'].InterestingPoint(
    mod.parts['Part-1'].edges.findAt((-1.224587, 2.956415,
    1.5), ), CENTER))
# Partition surface for thread contact #
mod.ConstrainedSketch(gridSpacing=1.67, name='__profile__',
    sheetSize=67.08, transform=
    mod.parts['Part-1'].MakeSketchTransform(
    sketchPlane=mod.parts['Part-1'].faces.findAt((-6.162443,
    6.739719, 1.5), ), sketchPlaneSide=SIDE1,
    sketchUpEdge=mod.parts['Part-1'].edges.findAt((15.0,
    7.5, 1.5), ), sketchOrientation=RIGHT, origin=(0.0, 10.299495, 1.5)))
mod.parts['Part-1'].projectReferencesOntoSketch(filter=
    COPLANAR_EDGES, sketch=mod.sketches['__profile__'])
mod.sketches['__profile__'].CircleByCenterPerimeter(center=(
    0.0, -10.299495), point1=(3.03665971755982, -13.3361547175598))
mod.sketches['__profile__'].vertices.findAt((3.03666,
    -13.336155))
mod.sketches['__profile__'].geometry.findAt((2.899605,
    -13.1991))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((
    3.03665971755982, -13.3361547175598), ), entity2=
    mod.sketches['__profile__'].geometry.findAt((2.899605,
    -13.1991), ))
mod.sketches['__profile__'].geometry.findAt((3.826414,
    -12.249151))
mod.sketches['__profile__'].RadialDimension(curve=
    mod.sketches['__profile__'].geometry.findAt((3.826414,
    -12.249151), ), radius=3.3, textPoint=(4.32360363006592,
    -14.6230986300659))
mod.parts['Part-1'].PartitionFaceBySketch(faces=
    mod.parts['Part-1'].faces.findAt(((-6.162443, 6.739719,
    1.5), ), ((6.678008, -6.287581, 1.5), ), ((-6.739719, 6.162443, 1.5), ), ((
    6.162443, -6.739719, 1.5), ), ), sketch=
    mod.sketches['__profile__'], sketchUpEdge=
    mod.parts['Part-1'].edges.findAt((15.0, 7.5, 1.5), ))
del mod.sketches['__profile__']
mod.parts['Part-1'].PartitionCellByExtrudeEdge(cells=
    mod.parts['Part-1'].cells.findAt(((-6.162443, 6.739719,
    0.0), ), ((6.198769, -6.794085, 1.5), ), ((6.678008, -6.287581, 0.0), ), ((
    -6.739719, 6.162443, 0.0), ), ), edges=(
    mod.parts['Part-1'].edges.findAt((-1.262855, -3.048802,
    1.5), ), mod.parts['Part-1'].edges.findAt((-3.048802,
    1.262855, 1.5), ), mod.parts['Part-1'].edges.findAt((
    3.048802, -1.262855, 1.5), ),
    mod.parts['Part-1'].edges.findAt((1.262855, 3.048802,
    1.5), )), line=mod.parts['Part-1'].edges.findAt((15.0,
    -15.0, 0.375), ), sense=REVERSE)
mod.parts['Part-1'].regenerate()
# Partition surface for wire connection #
mod.parts['Part-1'].PartitionFaceByShortestPath(faces=
    mod.parts['Part-1'].faces.findAt(((15.0, 5.0, 1.0), )),
    point1=mod.parts['Part-1'].InterestingPoint(
    mod.parts['Part-1'].edges.findAt((15.0, 7.5, 1.5), ),
    MIDDLE), point2=mod.parts['Part-1'].InterestingPoint(
    mod.parts['Part-1'].edges.findAt((15.0, 7.5, 0.0), ),
    MIDDLE))
mod.parts['Part-1'].PartitionFaceByShortestPath(faces=
    mod.parts['Part-1'].faces.findAt(((5.0, -15.0, 1.0), )),
    point1=mod.parts['Part-1'].InterestingPoint(
    mod.parts['Part-1'].edges.findAt((7.5, -15.0, 1.5), ),
    MIDDLE), point2=mod.parts['Part-1'].InterestingPoint(
    mod.parts['Part-1'].edges.findAt((7.5, -15.0, 0.0), ),
    MIDDLE))
mod.parts['Part-1'].PartitionFaceByShortestPath(faces=
    mod.parts['Part-1'].faces.findAt(((-15.0, -5.0, 1.0), ))
    , point1=mod.parts['Part-1'].InterestingPoint(
    mod.parts['Part-1'].edges.findAt((-15.0, -7.5, 1.5), ),
    MIDDLE), point2=mod.parts['Part-1'].InterestingPoint(
    mod.parts['Part-1'].edges.findAt((-15.0, -7.5, 0.0), ),
    MIDDLE))
mod.parts['Part-1'].PartitionFaceByShortestPath(faces=
    mod.parts['Part-1'].faces.findAt(((-5.0, 15.0, 1.0), )),
    point1=mod.parts['Part-1'].InterestingPoint(
    mod.parts['Part-1'].edges.findAt((-7.5, 15.0, 1.5), ),
    MIDDLE), point2=mod.parts['Part-1'].InterestingPoint(
    mod.parts['Part-1'].edges.findAt((-7.5, 15.0, 0.0), ),
    MIDDLE))
# Partition surface for adjustment #
mod.parts['Part-1'].features['Solid extrude-1'].setValues(
    depth=0.9)
mod.parts['Part-1'].regenerate()
mod.parts['Part-1'].regenerate()
### Copy plate-1 to plate-2 ###
mod.Part(name='Part-2', objectToCopy=
    mod.parts['Part-1'])
# mod.parts['Part-2'].features['Solid extrude-1'].setValues(
#     depth=0.9)
mod.parts['Part-2'].regenerate()
mod.parts['Part-2'].regenerate()
### Create Bolt ###
mod.ConstrainedSketch(name='__profile__', sheetSize=20.0)
mod.sketches['__profile__'].ConstructionLine(point1=(0.0,
    -10.0), point2=(0.0, 10.0))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.0))
mod.sketches['__profile__'].FixedConstraint(entity=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.0),
    ))
mod.sketches['__profile__'].Line(point1=(0.0, 5.0), point2=(
    9.5, 5.0))
mod.sketches['__profile__'].geometry.findAt((4.75, 5.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((4.75, 5.0),
    ))
mod.sketches['__profile__'].Line(point1=(9.5, 5.0), point2=(
    9.5, 0.0))
mod.sketches['__profile__'].geometry.findAt((9.5, 2.5))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((9.5, 2.5),
    ))
mod.sketches['__profile__'].geometry.findAt((4.75, 5.0))
mod.sketches['__profile__'].geometry.findAt((9.5, 2.5))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((4.75, 5.0),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    9.5, 2.5), ))
mod.sketches['__profile__'].Line(point1=(9.5, 0.0), point2=(
    3.2, 0.0))
mod.sketches['__profile__'].geometry.findAt((6.35, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((6.35, 0.0),
    ))
mod.sketches['__profile__'].geometry.findAt((9.5, 2.5))
mod.sketches['__profile__'].geometry.findAt((6.35, 0.0))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((9.5, 2.5),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    6.35, 0.0), ))
mod.sketches['__profile__'].Line(point1=(3.2, 0.0), point2=(
    3.2, -2.0))
mod.sketches['__profile__'].geometry.findAt((3.2, -1.0))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((3.2, -1.0),
    ))
mod.sketches['__profile__'].geometry.findAt((6.35, 0.0))
mod.sketches['__profile__'].geometry.findAt((3.2, -1.0))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((6.35, 0.0),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    3.2, -1.0), ))
mod.sketches['__profile__'].Line(point1=(3.2, -2.0), point2=
    (3.2, -4.0))
mod.sketches['__profile__'].geometry.findAt((3.2, -3.0))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((3.2, -3.0),
    ))
mod.sketches['__profile__'].geometry.findAt((3.2, -1.0))
mod.sketches['__profile__'].geometry.findAt((3.2, -3.0))
mod.sketches['__profile__'].ParallelConstraint(addUndoState=
    False, entity1=
    mod.sketches['__profile__'].geometry.findAt((3.2, -1.0),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    3.2, -3.0), ))
mod.sketches['__profile__'].Line(point1=(3.2, -4.0), point2=
    (3.2, -6.0))
mod.sketches['__profile__'].geometry.findAt((3.2, -5.0))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((3.2, -5.0),
    ))
mod.sketches['__profile__'].geometry.findAt((3.2, -3.0))
mod.sketches['__profile__'].geometry.findAt((3.2, -5.0))
mod.sketches['__profile__'].ParallelConstraint(addUndoState=
    False, entity1=
    mod.sketches['__profile__'].geometry.findAt((3.2, -3.0),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    3.2, -5.0), ))
mod.sketches['__profile__'].Line(point1=(3.2, -6.0), point2=
    (3.2, -8.0))
mod.sketches['__profile__'].geometry.findAt((3.2, -7.0))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((3.2, -7.0),
    ))
mod.sketches['__profile__'].geometry.findAt((3.2, -5.0))
mod.sketches['__profile__'].geometry.findAt((3.2, -7.0))
mod.sketches['__profile__'].ParallelConstraint(addUndoState=
    False, entity1=
    mod.sketches['__profile__'].geometry.findAt((3.2, -5.0),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    3.2, -7.0), ))
mod.sketches['__profile__'].Line(point1=(3.2, -8.0), point2=
    (0.0, -8.0))
mod.sketches['__profile__'].geometry.findAt((1.6, -8.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((1.6, -8.0),
    ))
mod.sketches['__profile__'].geometry.findAt((3.2, -7.0))
mod.sketches['__profile__'].geometry.findAt((1.6, -8.0))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((3.2, -7.0),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    1.6, -8.0), ))
mod.sketches['__profile__'].vertices.findAt((0.0, -8.0))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.0))
mod.sketches['__profile__'].CoincidentConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].vertices.findAt((0.0, -8.0),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    0.0, 0.0), ))
mod.sketches['__profile__'].Line(point1=(0.0, -8.0), point2=
    (0.0, 5.0))
mod.sketches['__profile__'].geometry.findAt((0.0, 4.35))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.0, 4.35),
    ))
mod.sketches['__profile__'].geometry.findAt((1.6, -8.0))
mod.sketches['__profile__'].geometry.findAt((0.0, 4.35))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((1.6, -8.0),
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    0.0, 4.35), ))
mod.Part(dimensionality=THREE_D, name='Part-Bolt', type=
    DEFORMABLE_BODY)
mod.parts['Part-Bolt'].BaseSolidRevolve(angle=360.0,
    flipRevolveDirection=OFF, sketch=
    mod.sketches['__profile__'])
del mod.sketches['__profile__']
# Create partition for bolt #
mod.parts['Part-Bolt'].DatumPlaneByPrincipalPlane(offset=0.0
    , principalPlane=XZPLANE)
mod.parts['Part-Bolt'].DatumPlaneByPrincipalPlane(offset=
    -0.9, principalPlane=XZPLANE)
mod.parts['Part-Bolt'].DatumPlaneByPrincipalPlane(offset=
    -1.8, principalPlane=XZPLANE)
mod.parts['Part-Bolt'].DatumPlaneByPrincipalPlane(offset=
    -2.7, principalPlane=XZPLANE)
mod.parts['Part-Bolt'].PartitionCellByPlanePointNormal(
    cells=mod.parts['Part-Bolt'].cells.findAt(((0.281967,
    -8.0, 3.042905), )), normal=
    mod.parts['Part-Bolt'].edges.findAt((7.925, 0.0, 0.0), )
    , point=mod.parts['Part-Bolt'].InterestingPoint(
    mod.parts['Part-Bolt'].edges.findAt((0.0, 5.0, 9.5), ),
    CENTER))
mod.parts['Part-Bolt'].PartitionCellByPlanePointNormal(
    cells=mod.parts['Part-Bolt'].cells.findAt(((-0.364821,
    -8.0, 1.002339), ), ((0.333263, -5.333333, 3.182599), ), ), normal=
    mod.parts['Part-Bolt'].edges.findAt((0.0, 5.0, 4.75), ),
    point=mod.parts['Part-Bolt'].InterestingPoint(
    mod.parts['Part-Bolt'].edges.findAt((8.776856, 5.0,
    3.635493), ), CENTER))
mod.parts['Part-Bolt'].PartitionCellByDatumPlane(cells=
    mod.parts['Part-Bolt'].cells.findAt(((2.081127, -8.0,
    -0.329618), ), ((-3.182599, -5.333333, 0.333263), ), ((-3.182599,
    -2.666667, -0.333263), ), ((2.081127, -8.0, 0.329618), ), ), datumPlane=
    mod.parts['Part-Bolt'].datums[2])
mod.parts['Part-Bolt'].PartitionCellByDatumPlane(cells=
    mod.parts['Part-Bolt'].cells.findAt(((2.081127, -8.0,
    -0.329618), ), ((-2.081127, -8.0, 0.329618), ), ((-3.182599, -2.666667,
    -0.333263), ), ((2.081127, -8.0, 0.329618), ), ), datumPlane=
    mod.parts['Part-Bolt'].datums[3])
mod.parts['Part-Bolt'].PartitionCellByDatumPlane(cells=
    mod.parts['Part-Bolt'].cells.findAt(((-3.182599, -4.0,
    -0.333263), ), ((2.081127, -8.0, -0.329618), ), ((-2.081127, -8.0,
    0.329618), ), ((2.081127, -8.0, 0.329618), ), ), datumPlane=
    mod.parts['Part-Bolt'].datums[4])
mod.parts['Part-Bolt'].PartitionCellByDatumPlane(cells=
    mod.parts['Part-Bolt'].cells.findAt(((-3.182599,
    -5.333333, -0.333263), ), ((2.081127, -8.0, -0.329618), ), ((-2.081127,
    -8.0, 0.329618), ), ((2.081127, -8.0, 0.329618), ), ), datumPlane=
    mod.parts['Part-Bolt'].datums[5])
# Material properties #
# Q550
mod.Material(name='Q550')
mod.materials['Q550'].Elastic(table=((210000.0,
    0.3, 20.0), (210000.0, 0.3, 100.0), (189000.0, 0.3, 200.0), (168000.0, 0.3,
    300.0), (147000.0, 0.3, 400.0), (126000.0, 0.3, 500.0), (65100.0, 0.3,
    600.0), (27300.0, 0.3, 700.0), (18900.0, 0.3, 800.0), (14175.0, 0.3,
    900.0), (9450.0, 0.3, 1000.0), (4725.0, 0.3, 1100.0)),
    temperatureDependency=ON)
mod.materials['Q550'].Plastic(table=((641.95, 0.0,
    20.0), (840.8, 0.04362, 20.0), (484.0180057, 0.0, 200.0), (561.5970425,
    0.004351749, 200.0), (588.7508359, 0.008684643, 200.0), (603.6768729,
    0.012998843, 200.0), (610.0999758, 0.017294511, 200.0), (681.9005789,
    0.137537668, 200.0), (208.526551, 0.0, 400.0), (389.6994594, 0.004634956,
    400.0), (457.6018199, 0.009248529, 400.0), (492.9908624, 0.013840914,
    400.0), (505.6153239, 0.018412306, 400.0), (565.1385236, 0.138528884,
    400.0), (126.7964434, 0.0, 500.0), (269.465182, 0.004737333, 500.0), (
    321.9127495, 0.009452329, 500.0), (349.1765722, 0.014145198, 500.0), (
    358.8316694, 0.018816146, 500.0), (401.0730478, 0.138887026, 500.0), (
    25.34705847, 0.0, 600.0), (98.42324981, 0.004890694, 600.0), (125.0296922,
    0.009757585, 600.0), (138.7831506, 0.014600905, 600.0), (143.5511245,
    0.019420879, 600.0), (160.4455888, 0.139423356, 600.0), (2.144021889, 0.0,
    800.0), (27.60637673, 0.004959322, 800.0), (37.13012554, 0.009894171,
    800.0), (42.04334869, 0.014804787, 800.0), (43.72479675, 0.019691406,
    800.0), (48.8691428, 0.139663295, 800.0), (0.792002987, 0.0, 900.0), (
    13.78412133, 0.004973643, 900.0), (18.36745701, 0.009922671, 900.0), (
    20.72788552, 0.014847326, 900.0), (21.53715265, 0.019747848, 900.0), (
    24.07081534, 0.139713356, 900.0)), temperatureDependency=ON)
mod.materials['Q550'].DuctileDamageInitiation(table=((0.15,
    0.0, 0.0), ))
mod.materials['Q550'].ductileDamageInitiation.DamageEvolution(
    table=((0.01, ), ), type=DISPLACEMENT)
mod.HomogeneousSolidSection(material='Q550', name='Q550',
    thickness=None)
# S350
mod.Material(name='S350')
mod.materials['S350'].Elastic(table=((
    209550.0, 0.3, 20.0), (209550.0, 0.3, 100.0), (188595.0, 0.3, 200.0), (
    167640.0, 0.3, 300.0), (146685.0, 0.3, 400.0), (125730.0, 0.3, 500.0), (
    64960.5, 0.3, 600.0), (27241.5, 0.3, 700.0), (18859.5, 0.3, 800.0), (
    14144.625, 0.3, 900.0), (9429.75, 0.3, 1000.0)), temperatureDependency=ON)
mod.materials['S350'].Plastic(table=((355.6,
    0.0, 20.0), (361.07, 0.01512, 20.0), (463.77, 0.05094, 20.0), (571.0,
    0.15129, 20.0), (286.52408, 0.0, 200.0), (333.4481835, 0.004949834, 200.0),
    (349.2655592, 0.009875289, 200.0), (358.0812921, 0.014776602, 200.0), (
    362.0246571, 0.019654009, 200.0), (404.6108103, 0.139630126, 200.0), (
    149.1105857, 0.0, 400.0), (286.2301475, 0.00496231, 400.0), (330.4816972,
    0.009900117, 400.0), (353.6011561, 0.014813662, 400.0), (362.0193422,
    0.019703183, 400.0), (404.6060963, 0.13967374, 400.0), (99.68873174, 0.0,
    500.0), (217.5611719, 0.004967861, 500.0), (255.5081348, 0.009911165,
    500.0), (275.2677521, 0.014830152, 500.0), (282.3747565, 0.019725061,
    500.0), (315.592462, 0.139693145, 500.0), (30.03342951, 0.0, 600.0), (
    120.6362475, 0.004976065, 600.0), (149.79964, 0.009927492, 600.0), (
    164.8747969, 0.014854523, 600.0), (170.1488612, 0.019757397, 600.0), (
    190.1646616, 0.139721825, 600.0), (1.952501815, 0.0, 800.0), (26.49741639,
    0.004984972, 800.0), (34.36910219, 0.009945217, 800.0), (38.42375339,
    0.014880979, 800.0), (39.82293269, 0.019792499, 800.0), (44.50738463,
    0.139752959, 800.0), (0.35500006, 0.0, 1000.0), (9.525340641, 0.004986607,
    1000.0), (12.45412004, 0.009948471, 1000.0), (13.96190763, 0.014885837,
    1000.0), (14.48114736, 0.019798944, 1000.0), (16.18457528, 0.139758676,
    1000.0)), temperatureDependency=ON)
mod.materials['S350'].DuctileDamageInitiation(table=((0.15,
    0.0, 0.0), ))
mod.materials['S350'].ductileDamageInitiation.DamageEvolution(
    table=((0.05, ), ), type=DISPLACEMENT)
mod.HomogeneousSolidSection(material='S350', name='S350',
    thickness=None)
# Experiment_70_7
mod.Material(name='Experiment_70_7')
mod.materials['Experiment_70_7'].Elastic(table=((210000.0, 0.3), ))
mod.materials['Experiment_70_7'].Plastic(table=((488.5897293, 0.0), (490.7344355, 0.004409953), (492.8697468,
    0.008800543), (494.9957451, 0.013171941), (497.1125114, 0.017524312), (
    555.587823, 0.137741437)))
mod.materials['Experiment_70_7'].DuctileDamageInitiation(table=((0.3,
    0.0, 0.0), ))
mod.materials['Experiment_70_7'].ductileDamageInitiation.DamageEvolution(
    table=((0.1, ), ), type=DISPLACEMENT)
mod.HomogeneousSolidSection(material='Experiment_70_7', name='Experiment_70_7',
    thickness=None)
# Assign section properties #
mod.parts['Part-1'].SectionAssignment(offset=0.0,
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    cells=mod.parts['Part-1'].cells.findAt(((-6.794085,
    6.198769, 0.0), ), ((2.455825, 2.065398, 0.0), ), ((-1.606965, -2.779556,
    0.9), ), ((6.198769, 6.794085, 0.0), ), ((-1.606965, 2.779556, 0.0), ), ((
    6.198769, -6.794085, 0.9), ), ((6.794085, 6.198769, 0.9), ), ((-2.548332,
    -1.953017, 0.0), ), )), sectionName='Q550', thicknessAssignment=
    FROM_SECTION)
mod.parts['Part-2'].SectionAssignment(offset=0.0,
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    cells=mod.parts['Part-2'].cells.findAt(((-6.794085,
    6.198769, 0.0), ), ((2.455825, 2.065398, 0.0), ), ((-1.606965, -2.779556,
    0.9), ), ((6.198769, 6.794085, 0.0), ), ((-1.606965, 2.779556, 0.0), ), ((
    6.198769, -6.794085, 0.9), ), ((6.794085, 6.198769, 0.9), ), ((-2.548332,
    -1.953017, 0.0), ), )), sectionName='Q550', thicknessAssignment=
    FROM_SECTION)
mod.parts['Part-Bolt'].SectionAssignment(offset=0.0,
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    cells=mod.parts['Part-Bolt'].cells.findAt(((0.333263,
    -2.4, 3.182599), ), ((-3.182599, -2.4, 0.333263), ), ((3.182599, -2.466667,
    -0.333263), ), ((-3.182599, -4.466667, -0.333263), ), ((0.333263, -1.5,
    3.182599), ), ((-3.182599, -1.5, 0.333263), ), ((3.182599, -1.5,
    -0.333263), ), ((-0.333263, -2.4, -3.182599), ), ((0.333263, -0.6,
    3.182599), ), ((-0.333263, -1.5, -3.182599), ), ((-3.182599, -0.6,
    0.333263), ), ((3.182599, -0.6, -0.333263), ), ((0.617786, 0.0, 7.339153),
    ), ((-7.339153, 0.0, -0.617786), ), ((-7.339153, 0.0, 0.617786), ), ((
    6.272487, 5.0, -0.617786), ), ((2.081127, -8.0, -0.329618), ), ((-2.081127,
    -8.0, 0.329618), ), ((-0.333263, -0.6, -3.182599), ), ((2.081127, -8.0,
    0.329618), ), )), sectionName='S350', thicknessAssignment=FROM_SECTION)
# Mesh #
# Mesh for bolt #
mod.parts['Part-Bolt'].seedPart(deviationFactor=0.1,
    minSizeFactor=0.1, size=1.0)
mod.parts['Part-Bolt'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Part-Bolt'].edges.findAt(((0.0, -2.475,
    3.2), ), ((0.0, -1.575, 3.2), ), ((0.0, -0.675, 3.2), ), ), number=2)
mod.parts['Part-Bolt'].setMeshControls(algorithm=MEDIAL_AXIS
    , regions=mod.parts['Part-Bolt'].cells.findAt(((
    0.617786, 0.0, 7.339153), ), ((-7.339153, 0.0, -0.617786), ), ((-7.339153,
    0.0, 0.617786), ), ((6.272487, 5.0, -0.617786), ), ))
mod.parts['Part-Bolt'].generateMesh()
# Mesh for plat-1 #
mod.parts['Part-1'].seedPart(deviationFactor=0.1,
    minSizeFactor=0.1, size=4.0)
mod.parts['Part-1'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Part-1'].edges.findAt(((15.0, -15.0,
    0.225), )), number=4)
mod.parts['Part-1'].seedEdgeByBias(biasMethod=SINGLE,
    constraint=FINER, end1Edges=
    mod.parts['Part-1'].edges.findAt(((5.500089, 5.500089,
    0.0), ), ((-5.500089, 5.500089, 0.9), ), ((-5.500089, -5.500089, 0.9), ), (
    (5.500089, -5.500089, 0.0), ), ), end2Edges=
    mod.parts['Part-1'].edges.findAt(((-11.833363,
    11.833363, 0.0), ), ((-11.833363, -11.833363, 0.0), ), ((11.833363,
    11.833363, 0.9), ), ((11.833363, -11.833363, 0.9), ), ), number=10, ratio=
    5.0)
mod.parts['Part-1'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Part-1'].edges.findAt(((2.660703,
    1.777825, 0.9), ), ((3.138513, -0.624289, 0.9), ), ), number=2)
mod.parts['Part-1'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Part-1'].edges.findAt(((2.660703,
    -1.777825, 0.0), ), ((3.138513, 0.624289, 0.0), ), ), number=2)
mod.parts['Part-1'].generateMesh()
# Mesh for plat-2 #
mod.parts['Part-2'].seedPart(deviationFactor=0.1,
    minSizeFactor=0.1, size=4.0)
mod.parts['Part-2'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Part-2'].edges.findAt(((-15.0, -15.0,
    0.1875), )), number=4)
mod.parts['Part-2'].seedEdgeByBias(biasMethod=SINGLE,
    constraint=FINER, end1Edges=
    mod.parts['Part-2'].edges.findAt(((5.500089, 5.500089,
    0.0), ), ((-5.500089, 5.500089, 0.9), ), ((-5.500089, -5.500089, 0.9), ),
    ((5.500089, -5.500089, 0.0), ), ), end2Edges=
    mod.parts['Part-2'].edges.findAt(((-11.833363,
    11.833363, 0.0), ), ((-11.833363, -11.833363, 0.0), ), ((11.833363,
    11.833363, 0.9), ), ((11.833363, -11.833363, 0.9), ), ), number=10,
    ratio=5.0)
mod.parts['Part-2'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Part-2'].edges.findAt(((2.660703,
    -1.777825, 0.0), ), ((3.138513, 0.624289, 0.0), ), ((2.660703, 1.777825,
    0.9), ), ((3.138513, -0.624289, 0.9), ), ), number=2)
mod.parts['Part-2'].generateMesh()
# Create node sets for plate 1 #
mod.parts['Part-1'].Set(name='Set-thread-nodes-1', nodes=
    mod.parts['Part-1'].nodes[0:2]+\
    mod.parts['Part-1'].nodes[4:5]+\
    mod.parts['Part-1'].nodes[7:10]+\
    mod.parts['Part-1'].nodes[12:14]+\
    mod.parts['Part-1'].nodes[26:28]+\
    mod.parts['Part-1'].nodes[48:50]+\
    mod.parts['Part-1'].nodes[73:76]+\
    mod.parts['Part-1'].nodes[79:85]+\
    mod.parts['Part-1'].nodes[88:91]+\
    mod.parts['Part-1'].nodes[98:103]+\
    mod.parts['Part-1'].nodes[107:115]+\
    mod.parts['Part-1'].nodes[118:121]+\
    mod.parts['Part-1'].nodes[127:130]+\
    mod.parts['Part-1'].nodes[142:145]+\
    mod.parts['Part-1'].nodes[300:306]+\
    mod.parts['Part-1'].nodes[312:327]+\
    mod.parts['Part-1'].nodes[342:351]+\
    mod.parts['Part-1'].nodes[441:450])
# Create node sets for plate 2 #
mod.parts['Part-2'].Set(name='Set-thread-nodes-2', nodes=
    mod.parts['Part-2'].nodes[0:2]+\
    mod.parts['Part-2'].nodes[4:5]+\
    mod.parts['Part-2'].nodes[7:10]+\
    mod.parts['Part-2'].nodes[12:14]+\
    mod.parts['Part-2'].nodes[26:28]+\
    mod.parts['Part-2'].nodes[48:50]+\
    mod.parts['Part-2'].nodes[73:76]+\
    mod.parts['Part-2'].nodes[79:85]+\
    mod.parts['Part-2'].nodes[88:91]+\
    mod.parts['Part-2'].nodes[98:103]+\
    mod.parts['Part-2'].nodes[107:115]+\
    mod.parts['Part-2'].nodes[118:121]+\
    mod.parts['Part-2'].nodes[127:130]+\
    mod.parts['Part-2'].nodes[142:145]+\
    mod.parts['Part-2'].nodes[300:306]+\
    mod.parts['Part-2'].nodes[312:327]+\
    mod.parts['Part-2'].nodes[342:351]+\
    mod.parts['Part-2'].nodes[441:450])
# Assembly #
mod.rootAssembly.DatumCsysByDefault(CARTESIAN)
mod.rootAssembly.Instance(dependent=ON, name='Part-2-1',
    part=mod.parts['Part-2'])
mod.rootAssembly.Instance(dependent=ON, name='Part-1-1',
    part=mod.parts['Part-1'])
mod.rootAssembly.instances['Part-1-1'].translate(vector=(
    33.0, 0.0, 0.0))
mod.rootAssembly.translate(instanceList=('Part-1-1', ),
    vector=(-33.0, 0.0, 0.9))
mod.rootAssembly.translate(instanceList=('Part-1-1', ),
    vector=(0.0, 0.0, 0.15))
mod.rootAssembly.Instance(dependent=ON, name='Part-Bolt-1',
    part=mod.parts['Part-Bolt'])
mod.rootAssembly.instances['Part-Bolt-1'].translate(vector=(
    27.54, 0.0, 0.0))
mod.rootAssembly.rotate(angle=90.0, axisDirection=(15.0,
    0.0, 0.0), axisPoint=(0.0, 0.0, 1.8), instanceList=('Part-Bolt-1', ))
mod.rootAssembly.translate(instanceList=('Part-Bolt-1', ),
    vector=(-27.54, -1.8, 0.0))
mod.rootAssembly.translate(instanceList=('Part-1-1', ),
    vector=(0.0, 0.0, -0.15))
### Step ###
### Create step ###
mod.StaticStep(initialInc=0.1, maxInc=1, minInc=5e-10, timePeriod=1.0, name='i0_Sub_step',
    nlgeom=ON, previous='Initial')
## Restart Request ##
mod.steps['i0_Sub_step'].Restart(frequency=1, numberIntervals=0,
    overlay=ON, timeMarks=OFF)
# Improve convergence #
mod.steps['i0_Sub_step'].setValues(adaptiveDampingRatio=0.05
    , continueDampingFactors=False, stabilizationMagnitude=0.0002,
    stabilizationMethod=DISSIPATED_ENERGY_FRACTION)
## Output Request ##
mod.fieldOutputRequests['F-Output-1'].setValues(variables=(
    'S', 'PE', 'PEEQ', 'U', 'RF', 'SDEG', 'NT', 'STATUS'))
mod.historyOutputRequests['H-Output-1'].setValues(variables=
    ('CFTM', 'CFT1', 'CFT2', 'CFT3'))
### Interaction ###
## Friction Interaction property ##
mod.ContactProperty('IntProp-1')
mod.interactionProperties['IntProp-1'].ThermalConductance(
    clearanceDepTable=((100000.0, 0.0), (0.0, 0.15)), clearanceDependency=ON,
    definition=TABULAR, dependenciesC=0, massFlowRateDependencyC=OFF,
    pressureDependency=OFF, temperatureDependencyC=OFF)
mod.interactionProperties['IntProp-1'].TangentialBehavior(
    dependencies=0, directionality=ISOTROPIC, elasticSlipStiffness=None,
    formulation=PENALTY, fraction=0.005, maximumElasticSlip=FRACTION,
    pressureDependency=OFF, shearStressLimit=None, slipRateDependency=OFF,
    table=((0.3, ), ), temperatureDependency=OFF)
## Interaction property frictionless ##
mod.ContactProperty('frictionless')
mod.interactionProperties['frictionless'].ThermalConductance(
    clearanceDepTable=((100000.0, 0.0), (0.0, 0.15)), clearanceDependency=ON,
    definition=TABULAR, dependenciesC=0, massFlowRateDependencyC=OFF,
    pressureDependency=OFF, temperatureDependencyC=OFF)
# Surface to surface contact #
mod.rootAssembly.Surface(name='CP-1-Part-2-1', side1Faces=
    mod.rootAssembly.instances['Part-2-1'].faces.findAt(((
    -1.606965, -2.779556, 0.9), ), ((-6.794085, -6.198769, 0.9), ), ((
    2.455825, -2.065398, 0.9), ), ((-6.198769, 6.794085, 0.9), ), ((1.606965,
    2.779556, 0.9), ), ((6.794085, 6.198769, 0.9), ), ((-2.548332, 1.953017,
    0.9), ), ((6.198769, -6.794085, 0.9), ), ))
mod.rootAssembly.Surface(name='CP-1-Part-1-1', side1Faces=
    mod.rootAssembly.instances['Part-1-1'].faces.findAt(((
    6.198769, 6.794085, 0.9), ), ((2.455825, 2.065398, 0.9), ), ((-6.794085,
    6.198769, 0.9), ), ((1.606965, -2.779556, 0.9), ), ((-2.548332, -1.953017,
    0.9), ), ((-6.198769, -6.794085, 0.9), ), ((6.794085, -6.198769, 0.9), ), (
    (-1.606965, 2.779556, 0.9), ), ))
mod.rootAssembly.Surface(name='CP-2-Part-Bolt-1',
    side1Faces=
    mod.rootAssembly.instances['Part-Bolt-1'].faces.findAt((
    (-3.182599, -0.333263, -0.6), ), ((-3.182599, 0.333263, -2.666667), ), ((
    0.333263, -3.182599, -0.6), ), ((3.182599, 0.333263, -0.666667), ), ((
    -0.333263, 3.182599, -0.6), ), ((-3.182599, -0.333263, 0.3), ), ((0.333263,
    -3.182599, 0.3), ), ((3.182599, 0.333263, 0.3), ), ((3.182599, -0.333263,
    -1.333333), ), ((3.182599, 0.333263, 1.2), ), ((-0.333263, 3.182599, 1.2),
    ), ((-0.333263, -3.182599, -2.666667), ), ((-3.182599, -0.333263, 1.2), ),
    ((0.333263, -3.182599, 1.2), ), ((0.333263, 3.182599, -2.666667), ), ((
    -0.333263, 3.182599, 0.3), ), ))
mod.rootAssembly.Surface(name='CP-2-Part-2-1', side1Faces=
    mod.rootAssembly.instances['Part-2-1'].faces.findAt(((
    -1.949959, 2.537255, 0.25), ), ((2.450884, -2.057466, 0.25), ), ((
    -2.537255, 1.949959, 0.5), ), ((1.949959, -2.537255, 0.25), ), ))
mod.rootAssembly.Surface(name='CP-3-Part-1-1', side1Faces=
    mod.rootAssembly.instances['Part-1-1'].faces.findAt(((
    -1.606965, -2.779556, 1.8), ), ((-6.794085, -6.198769, 1.8), ), ((2.455825,
    -2.065398, 1.8), ), ((-6.198769, 6.794085, 1.8), ), ((1.606965, 2.779556,
    1.8), ), ((6.794085, 6.198769, 1.8), ), ((-2.548332, 1.953017, 1.8), ), ((
    6.198769, -6.794085, 1.8), ), ))
mod.rootAssembly.Surface(name='CP-3-Part-Bolt-1',
    side1Faces=
    mod.rootAssembly.instances['Part-Bolt-1'].faces.findAt((
    (-7.339153, 0.617786, 1.8), ), ((0.617786, -7.339153, 1.8), ), ((0.617786,
    7.339153, 1.8), ), ((-7.339153, -0.617786, 1.8), ), ))
mod.rootAssembly.Surface(name='CP-4-Part-Bolt-1',
    side1Faces=
    mod.rootAssembly.instances['Part-Bolt-1'].faces.findAt((
    (-3.182599, -0.333263, -0.6), ), ((-3.182599, 0.333263, -2.666667), ), ((
    0.333263, -3.182599, -0.6), ), ((3.182599, 0.333263, -0.666667), ), ((
    -0.333263, 3.182599, -0.6), ), ((-3.182599, -0.333263, 0.3), ), ((0.333263,
    -3.182599, 0.3), ), ((3.182599, 0.333263, 0.3), ), ((3.182599, -0.333263,
    -1.333333), ), ((3.182599, 0.333263, 1.2), ), ((-0.333263, 3.182599, 1.2),
    ), ((-0.333263, -3.182599, -2.666667), ), ((-3.182599, -0.333263, 1.2), ),
    ((0.333263, -3.182599, 1.2), ), ((0.333263, 3.182599, -2.666667), ), ((
    -0.333263, 3.182599, 0.3), ), ))
mod.rootAssembly.Surface(name='CP-4-Part-1-1', side1Faces=
    mod.rootAssembly.instances['Part-1-1'].faces.findAt(((
    -1.949959, 2.537255, 1.2), ), ((2.450884, -2.057466, 1.2), ), ((-2.537255,
    1.949959, 1.5), ), ((1.949959, -2.537255, 1.2), ), ))
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE,
    interactionProperty='frictionless', slave=
    mod.rootAssembly.surfaces['CP-1-Part-2-1'], name=
    'CP-1-Part-2-1-Part-1-1', master=
    mod.rootAssembly.surfaces['CP-1-Part-1-1'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE,
    interactionProperty='frictionless', master=
    mod.rootAssembly.surfaces['CP-2-Part-Bolt-1'], name=
    'CP-2-Part-Bolt-1-Part-2-1', slave=
    mod.rootAssembly.surfaces['CP-2-Part-2-1'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE,
    interactionProperty='frictionless', master=
    mod.rootAssembly.surfaces['CP-3-Part-1-1'], name=
    'CP-3-Part-1-1-Part-Bolt-1', slave=
    mod.rootAssembly.surfaces['CP-3-Part-Bolt-1'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE,
    interactionProperty='IntProp-1', master=
    mod.rootAssembly.surfaces['CP-4-Part-Bolt-1'], name=
    'CP-4-Part-Bolt-1-Part-1-1', slave=
    mod.rootAssembly.surfaces['CP-4-Part-1-1'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
# Thread contact #
mod.rootAssembly.Surface(name='Plate_inner_surf',
    side1Faces=
    mod.rootAssembly.instances['Part-2-1'].faces.findAt(((
    -2.010895, -2.616544, 0.5), ), ((-2.616544, 2.010895, 0.5), ), ((-2.010895,
    2.616544, 0.25), ), ((2.616544, 2.010895, 0.25), ), ))
mod.rootAssembly.Set(faces=
    mod.rootAssembly.instances['Part-Bolt-1'].faces.findAt((
    (-3.182599, -0.333263, -0.6), ), ((0.333263, -3.182599, -0.6), ), ((
    3.182599, 0.333263, -0.666667), ), ((-0.333263, 3.182599, -0.6), ), ((
    -3.182599, -0.333263, 0.3), ), ((0.333263, -3.182599, 0.3), ), ((3.182599,
    0.333263, 0.3), ), ((-0.333263, 3.182599, 0.3), ), ), name=
    'Bolt_thread_surf')
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE,
    clearanceRegion=mod.rootAssembly.sets['Bolt_thread_surf'],
    createStepName='Initial', datumAxis=
    mod.rootAssembly.instances['Part-Bolt-1'].datums[1],
    enforcement=NODE_TO_SURFACE, halfThreadAngle=-30.0, initialClearance=0.0,
    interactionProperty='IntProp-1', majorBoltDiameter=4.8, master=
    mod.rootAssembly.surfaces['Plate_inner_surf'],
    meanBoltDiameter=COMPUTED, name='Thread_contact', pitch=2.0, slave=
    mod.rootAssembly.sets['Bolt_thread_surf'], sliding=SMALL
    , smooth=0.2, surfaceSmoothing=NONE, thickness=ON, useReverseDatumAxis=OFF)
### BC ###
## Submodel BC ##
mod.setValues(globalJob='i0_Sys_SR', shellToSolid=OFF)
mod.rootAssembly.Set(faces=
    mod.rootAssembly.instances['Part-2-1'].faces.findAt(((
    -5.0, 15.0, 0.25), ), ((-15.0, -5.0, 0.25), ), ((5.0, -15.0, 0.25), ), ((
    15.0, 5.0, 0.25), ), ((-15.0, 5.0, 0.5), ), ((5.0, 15.0, 0.5), ), ((15.0,
    -5.0, 0.5), ), ((-5.0, -15.0, 0.5), ), )+\
    mod.rootAssembly.instances['Part-1-1'].faces.findAt(((
    -5.0, 15.0, 1.2), ), ((-15.0, -5.0, 1.2), ), ((5.0, -15.0, 1.2), ), ((15.0,
    5.0, 1.2), ), ((-15.0, 5.0, 1.5), ), ((5.0, 15.0, 1.5), ), ((15.0, -5.0,
    1.5), ), ((-5.0, -15.0, 1.5), ), ), name='Set-Sub_BC', xEdges=
    mod.rootAssembly.instances['Part-2-1'].edges.findAt(((
    -11.25, 15.0, 0.9), ), ((-15.0, -11.25, 0.9), ), ((11.25, -15.0, 0.9),
    ), ((15.0, 11.25, 0.9), ), ((-15.0, 3.75, 0.9), ), ((3.75, 15.0, 0.9),
    ), ((15.0, -3.75, 0.9), ), ((-3.75, -15.0, 0.9), ), )+\
    mod.rootAssembly.instances['Part-1-1'].edges.findAt(((
    -11.25, 15.0, 0.9), ), ((-15.0, -11.25, 0.9), ), ((11.25, -15.0, 0.9), ), (
    (15.0, 11.25, 0.9), ), ((3.75, 15.0, 0.9), ), ((-15.0, 3.75, 0.9), ), ((
    -3.75, -15.0, 0.9), ), ((15.0, -3.75, 0.9), ), ))
mod.SubmodelBC(absoluteExteriorTolerance=None,
    createStepName='i0_Sub_step', exteriorTolerance=0, globalDrivingRegion='',
    globalIncrement=0, globalStep='1', name='SubBC', region=
    mod.rootAssembly.sets['Set-Sub_BC'], shellThickness=4.0,
    timeScale=OFF)
mod.boundaryConditions['SubBC'].setValues(
    absoluteExteriorTolerance=None, dof=(1, 2, 3, 4, 5, 6), exteriorTolerance=0,
    globalDrivingRegion='')
## Create wire for PULL##
mod.rootAssembly.WirePolyLine(mergeType=IMPRINT, meshable=
    OFF, points=((
    mod.rootAssembly.instances['Part-Bolt-1'].vertices.findAt(
    (9.5, 0.0, 6.8), ),
    mod.rootAssembly.instances['Part-Bolt-1'].vertices.findAt(
    (3.2, 0.0, -6.2), )), (
    mod.rootAssembly.instances['Part-Bolt-1'].vertices.findAt(
    (0.0, 9.5, 6.8), ),
    mod.rootAssembly.instances['Part-Bolt-1'].vertices.findAt(
    (0.0, 3.2, -6.2), )), (
    mod.rootAssembly.instances['Part-Bolt-1'].vertices.findAt(
    (-9.5, 0.0, 6.8), ),
    mod.rootAssembly.instances['Part-Bolt-1'].vertices.findAt(
    (-3.2, 0.0, -6.2), )), (
    mod.rootAssembly.instances['Part-Bolt-1'].vertices.findAt(
    (0.0, -9.5, 6.8), ),
    mod.rootAssembly.instances['Part-Bolt-1'].vertices.findAt(
    (0.0, -3.2, -6.2), ))))
mod.rootAssembly.Set(edges=
    mod.rootAssembly.edges.findAt(((0.0, -7.925, 3.55), ), (
    (-7.925, 0.0, 3.55), ), ((0.0, 7.925, 3.55), ), ((7.925, 0.0, 3.55), ), ),
    name='Wire-1-Set-1')
## Create wire for shearing ##
# For Y direction #
mod.rootAssembly.WirePolyLine(mergeType=IMPRINT, meshable=
    OFF, points=((
    mod.rootAssembly.instances['Part-1-1'].vertices.findAt((
    0.0, -15.0, 1.8), ),
    mod.rootAssembly.instances['Part-2-1'].vertices.findAt((
    0.0, -15.0, 0.0), )), (
    mod.rootAssembly.instances['Part-1-1'].vertices.findAt((
    0.0, 15.0, 1.8), ),
    mod.rootAssembly.instances['Part-2-1'].vertices.findAt((
    0.0, 15.0, 0.0), ))))
mod.rootAssembly.Set(edges=
    mod.rootAssembly.edges.findAt(((0.0, 15.0, 1.35), ), ((
    0.0, -15.0, 1.35), ), ), name='Wire-2-Set-1')
# For X direction #
mod.rootAssembly.WirePolyLine(mergeType=IMPRINT, meshable=
    OFF, points=((
    mod.rootAssembly.instances['Part-1-1'].vertices.findAt((
    -15.0, 0.0, 1.8), ),
    mod.rootAssembly.instances['Part-2-1'].vertices.findAt((
    -15.0, 0.0, 0.0), )), (
    mod.rootAssembly.instances['Part-1-1'].vertices.findAt((
    15.0, 0.0, 1.8), ),
    mod.rootAssembly.instances['Part-2-1'].vertices.findAt((
    15.0, 0.0, 0.0), ))))
mod.rootAssembly.Set(edges=
    mod.rootAssembly.edges.findAt(((15.0, 0.0, 1.35), ), ((
    -15.0, 0.0, 1.35), ), ), name='Wire-3-Set-1')
## Create set for temperature assignment ##
mod.rootAssembly.Set(cells=
    mod.rootAssembly.instances['Part-2-1'].cells.findAt(((
    -6.794085, -6.198769, 0.9), ), ((2.455825, 2.065398, 0.0), ), ((-1.606965,
    -2.779556, 0.9), ), ((-6.198769, 6.794085, 0.9), ), ((-1.606965,
    2.779556, 0.0), ), ((-6.198769, -6.794085, 0.0), ), ((15.0, -5.0, 0.5), ),
    ((-2.548332, -1.953017, 0.0), ), )+\
    mod.rootAssembly.instances['Part-1-1'].cells.findAt(((
    -6.794085, -6.198769, 1.8), ), ((2.455825, 2.065398, 0.9), ), ((-1.606965,
    -2.779556, 1.8), ), ((-6.198769, 6.794085, 1.8), ), ((-1.606965, 2.779556,
    0.9), ), ((-6.198769, -6.794085, 0.9), ), ((15.0, -5.0, 1.5), ), ((
    -2.548332, -1.953017, 0.9), ), )+\
    mod.rootAssembly.instances['Part-Bolt-1'].cells.findAt((
    (0.333263, -3.182599, -0.6), ), ((-3.182599, -0.333263, -0.6), ), ((
    3.182599, 0.333263, -0.666667), ), ((-3.182599, 0.333263, -2.666667), ), ((
    0.333263, -3.182599, 0.3), ), ((-3.182599, -0.333263, 0.3), ), ((3.182599,
    0.333263, 0.3), ), ((-0.333263, 3.182599, -0.6), ), ((0.333263, -3.182599,
    1.2), ), ((-0.333263, 3.182599, 0.3), ), ((-3.182599, -0.333263, 1.2), ), (
    (3.182599, 0.333263, 1.2), ), ((0.617786, -7.339153, 1.8), ), ((-7.339153,
    0.617786, 1.8), ), ((-7.339153, -0.617786, 1.8), ), ((6.272487, 0.617786,
    6.8), ), ((2.081127, 0.329618, -6.2), ), ((-2.081127, -0.329618, -6.2), ),
    ((-0.333263, 3.182599, 1.2), ), ((2.081127, -0.329618, -6.2), ), ), edges=
    mod.rootAssembly.edges.findAt(((15.0, 0.0, 1.35), ), ((
    -15.0, 0.0, 1.35), ), ((0.0, 15.0, 1.35), ), ((0.0, -15.0, 1.35), ), ((0.0,
    -7.925, 3.55), ), ((-7.925, 0.0, 3.55), ), ((0.0, 7.925, 3.55), ), ((7.925,
    0.0, 3.55), ), ), name='Set_temperature_surfaces')
## additional script for pull-out failure ##
mod.rootAssembly.regenerate()
## Change plate thickness ##
mod.parts['Part-1'].features['Solid extrude-1'].setValues(
    depth=4.0)
mod.parts['Part-1'].regenerate()
mod.parts['Part-1'].regenerate()
mod.parts['Part-2'].features['Solid extrude-1'].setValues(
    depth=4.0)
mod.parts['Part-2'].regenerate()
mod.parts['Part-2'].regenerate()
mod.rootAssembly.regenerate()
# Move the plates to the right place #
mod.rootAssembly.translate(instanceList=('Part-2-1', ),
    vector=(0.0, 0.0, -3.1))
mod.rootAssembly.translate(instanceList=('Part-2-1',
    'Part-1-1'), vector=(0.0, 0.0, -3.1))
# Change the mesh #
mod.parts['Part-2'].generateMesh()
mod.parts['Part-1'].generateMesh()
# Re-Create coupling points #
mod.rootAssembly.regenerate()
mod.rootAssembly.Set(faces=
    mod.rootAssembly.instances['Part-Bolt-1'].faces.findAt((
    (-3.182599, 0.333263, -2.666667), ), ((3.182599, -0.333263, -1.333333), ),
    ((-0.333263, -3.182599, -2.666667), ), ((0.333263, 3.182599, -2.666667), ),
    ), name='Bolt_thread_surf')
# Recreating monitor elements #
## Create sets for monitor ##
mod.rootAssembly.Set(elements=
    mod.rootAssembly.instances['Part-1-1'].elements[0:4]+\
    mod.rootAssembly.instances['Part-1-1'].elements[40:44]+\
    mod.rootAssembly.instances['Part-1-1'].elements[80:84]+\
    mod.rootAssembly.instances['Part-1-1'].elements[120:124]+\
    mod.rootAssembly.instances['Part-1-1'].elements[160:204]+\
    mod.rootAssembly.instances['Part-1-1'].elements[240:244]+\
    mod.rootAssembly.instances['Part-1-1'].elements[280:284]+\
    mod.rootAssembly.instances['Part-1-1'].elements[320:324]+\
    mod.rootAssembly.instances['Part-1-1'].elements[360:380]+\
    mod.rootAssembly.instances['Part-1-1'].elements[416:420]+\
    mod.rootAssembly.instances['Part-1-1'].elements[456:460]+\
    mod.rootAssembly.instances['Part-1-1'].elements[496:500]+\
    mod.rootAssembly.instances['Part-1-1'].elements[752:792]
    , name='Set-Plate1_edge_elements')
mod.rootAssembly.Set(elements=
    mod.rootAssembly.instances['Part-2-1'].elements[0:1]+\
    mod.rootAssembly.instances['Part-2-1'].elements[2:4]+\
    mod.rootAssembly.instances['Part-2-1'].elements[40:41]+\
    mod.rootAssembly.instances['Part-2-1'].elements[42:44]+\
    mod.rootAssembly.instances['Part-2-1'].elements[80:84]+\
    mod.rootAssembly.instances['Part-2-1'].elements[120:124]+\
    mod.rootAssembly.instances['Part-2-1'].elements[160:204]+\
    mod.rootAssembly.instances['Part-2-1'].elements[240:244]+\
    mod.rootAssembly.instances['Part-2-1'].elements[280:284]+\
    mod.rootAssembly.instances['Part-2-1'].elements[320:324]+\
    mod.rootAssembly.instances['Part-2-1'].elements[360:380]+\
    mod.rootAssembly.instances['Part-2-1'].elements[416:420]+\
    mod.rootAssembly.instances['Part-2-1'].elements[456:460]+\
    mod.rootAssembly.instances['Part-2-1'].elements[496:500]+\
    mod.rootAssembly.instances['Part-2-1'].elements[752:792]
    , name='Set-Plate2_edge_elements')
mod.rootAssembly.Set(elements=
    mod.rootAssembly.instances['Part-Bolt-1'].elements[0:1056]
    , name='Set-Bolt_edge_elements')
mod.parts['Part-Bolt'].deleteMesh(regions=
    mod.parts['Part-Bolt'].cells.findAt(((-2.081127, -8.0,
    0.329618), ), ((2.081127, -8.0, 0.329618), ), ))
mod.parts['Part-Bolt'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Part-Bolt'].edges.findAt(((0.0, -6.675,
    3.2), )), number=10)
mod.parts['Part-Bolt'].generateMesh()
mod.rootAssembly.regenerate()
mod.rootAssembly.Set(elements=
    mod.rootAssembly.instances['Part-Bolt-1'].elements[0:1536]
    , name='Set-Bolt_edge_elements')
# Finer mesh #
mod.parts['Part-Bolt'].deleteMesh(regions=
    mod.parts['Part-Bolt'].cells.findAt(((-2.081127, -8.0,
    0.329618), ), ((2.081127, -8.0, 0.329618), ), ))
mod.parts['Part-Bolt'].seedEdgeByNumber(constraint=FINER,
    edges=mod.parts['Part-Bolt'].edges.findAt(((0.0, -6.675,
    3.2), )), number=10)
mod.parts['Part-Bolt'].generateMesh()
mod.rootAssembly.regenerate()
mod.rootAssembly.Set(elements=
    mod.rootAssembly.instances['Part-Bolt-1'].elements[0:1536]
    , name='Set-Bolt_edge_elements')
## Job ##
mod.rootAssembly.regenerate()