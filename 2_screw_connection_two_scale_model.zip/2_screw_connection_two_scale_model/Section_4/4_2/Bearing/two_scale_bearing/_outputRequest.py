import os
from sys import exit
from abaqus import *
from odbAccess import *
from abaqusConstants import *
import visualization


def ContactForce(odbPath, iteraiterationNum):
    o1 = session.openOdb(odbPath)
    session.viewports['Viewport: 1'].setValues(displayedObject=o1)
    odb = session.odbs[odbPath]
    session.XYDataFromHistory(name='XYData-1', odb=odb,
                              outputVariableName='CFT1: CFT1     ASSEMBLY_CP-4-PART-1-1/ASSEMBLY_CP-4-PART-BOLT-1',
                              steps=('i%s_Sub_step'%iteraiterationNum,), )
    session.XYDataFromHistory(name='XYData-2', odb=odb,
                              outputVariableName='CFT2: CFT2     ASSEMBLY_CP-4-PART-1-1/ASSEMBLY_CP-4-PART-BOLT-1',
                              steps=('i%s_Sub_step'%iteraiterationNum,), )
    session.XYDataFromHistory(name='XYData-3', odb=odb,
                              outputVariableName='CFT3: CFT3     ASSEMBLY_CP-3-PART-BOLT-1/ASSEMBLY_CP-3-PART-1-1',
                              steps=('i%s_Sub_step'%iteraiterationNum,), )
    x0 = session.xyDataObjects['XYData-1']
    x1 = session.xyDataObjects['XYData-2']
    x2 = session.xyDataObjects['XYData-3']
    CF1 = x0[-1][1]
    CF2 = x1[-1][1]
    CF3 = x2[-1][1]
    del session.xyDataObjects['XYData-1']
    del session.xyDataObjects['XYData-2']
    del session.xyDataObjects['XYData-3']
    session.odbs[odbPath].close()
    return CF1, CF2, CF3


def Displacement(odbPath):
    o1 = session.openOdb(name=odbPath)
    session.viewports['Viewport: 1'].setValues(displayedObject=o1)
    odb = session.odbs[odbPath]
    session.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=(('U', NODAL, ((COMPONENT, 'U1'),)),),
                                nodeSets=('WIRE-3-SET-1',))
    x1_0 = session.xyDataObjects['U:U1 PI: PART-1-1 N: 3']
    x1_1 = session.xyDataObjects['U:U1 PI: PART-1-1 N: 34']
    x1_2 = session.xyDataObjects['U:U1 PI: PART-2-1 N: 9']
    x1_3 = session.xyDataObjects['U:U1 PI: PART-2-1 N: 33']
    x1 = (abs(x1_3[-1][1] - x1_1[-1][1]) + abs(x1_2[-1][1] - x1_0[-1][1]))/2
    session.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=(('U', NODAL, ((COMPONENT, 'U2'),)),),
                                nodeSets=('WIRE-2-SET-1',))
    x2_0 = session.xyDataObjects['U:U2 PI: PART-1-1 N: 23']
    x2_1 = session.xyDataObjects['U:U2 PI: PART-1-1 N: 32']
    x2_2 = session.xyDataObjects['U:U2 PI: PART-2-1 N: 26']
    x2_3 = session.xyDataObjects['U:U2 PI: PART-2-1 N: 29']
    x2 = (abs(x2_3[-1][1] - x2_1[-1][1]) + abs(x2_2[-1][1] - x2_0[-1][1]))/2
    session.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=(('U', NODAL, ((COMPONENT, 'U3'),)),),
                                nodeSets=('WIRE-1-SET-1',))
    x3_0 = session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 12']
    x3_1 = session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 13']
    x3_2 = session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 25']
    x3_3 = session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 28']
    x3_4 = session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 31']
    x3_5 = session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 36']
    x3_6 = session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 33']
    x3_7 = session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 37']
    x3 = (abs(x3_6[-1][1] - x3_0[-1][1]) + abs(x3_7[-1][1] - x3_1[-1][1]) +
          abs(x3_4[-1][1] - x3_2[-1][1]) + abs(x3_5[-1][1] - x3_3[-1][1]))/4
    del session.xyDataObjects['U:U1 PI: PART-1-1 N: 3']
    del session.xyDataObjects['U:U1 PI: PART-1-1 N: 34']
    del session.xyDataObjects['U:U1 PI: PART-2-1 N: 9']
    del session.xyDataObjects['U:U1 PI: PART-2-1 N: 33']
    del session.xyDataObjects['U:U2 PI: PART-1-1 N: 23']
    del session.xyDataObjects['U:U2 PI: PART-1-1 N: 32']
    del session.xyDataObjects['U:U2 PI: PART-2-1 N: 26']
    del session.xyDataObjects['U:U2 PI: PART-2-1 N: 29']
    del session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 12']
    del session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 13']
    del session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 25']
    del session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 28']
    del session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 31']
    del session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 36']
    del session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 33']
    del session.xyDataObjects['U:U3 PI: PART-BOLT-1 N: 37']
    session.odbs[odbPath].close()
    return x1, x2, x3


def Monitor(odbPath):
    odb = openOdb(odbPath)
    ### Find last step and last frame ###
    last_step = odb.steps.values()[-1]
    last_frame = last_step.frames[-1]
    ## Check the element status ##
    status = last_frame.fieldOutputs['STATUS']
    element_sets = odb.rootAssembly.elementSets
    bolt_region = element_sets['SET-BOLT_EDGE_ELEMENTS']
    plate1_region = element_sets['SET-PLATE1_EDGE_ELEMENTS']
    plate2_region = element_sets['SET-PLATE2_EDGE_ELEMENTS']
    ## check the bolt failed or not ##
    bolt_status = status.getSubset(region=bolt_region).values
    bolt_failed_element_number = 0
    for i in range(len(bolt_status)):
        if bolt_status[i].data == 0.0:
            bolt_failed_element_number += 1
        else:
            pass
    ## check plate1 failed or not ##
    plate1_status = status.getSubset(region=plate1_region).values
    plate1_failed_element_number = 0
    for i in range(len(plate1_status)):
        if plate1_status[i].data == 0:
            plate1_failed_element_number += 1
        else:
            pass
    ## check plate2 failed or not ##
    plate2_status = status.getSubset(region=plate2_region).values
    plate2_failed_element_number = 0
    for i in range(len(plate2_status)):
        if plate2_status[i].data == 0:
            plate2_failed_element_number += 1
        else:
            pass
    # output element status, '1' for not failed, '0' for failed ##
    element_monitor = open('Element_Monitor.txt', 'w')
    if bolt_failed_element_number or plate1_failed_element_number or plate2_failed_element_number == 0:
        element_monitor.writelines('1\n')
        element_monitor.writelines('Still going strong')
    else:
        element_monitor.writelines('0\n')
        element_monitor.writelines('Bolt failed')
        dict = {'bolt_failed': bolt_failed_element_number,
                'plate1_failed': plate1_failed_element_number,
                'plate2_failed': plate2_failed_element_number}
        # first make keys and values in the dictionary as two lists, then using index to find the keys #
        for a in range(len(dict.values())):
            if list(dict.values())[a] != 0:
                failed_part = list(dict.keys())[a]
        element_monitor.writelines(failed_part)
    element_monitor.close()
    # close odb file and exit the code #
    odb.close()

### Open Odb file ###
currentPath=os.getcwd()
iteraiterationNum=open('_iteration.log','r').readlines()[0]
submodel_odbPath = currentPath + '\\outputSR\\i%s_Sub.odb'%iteraiterationNum
probmodel_odbPath = currentPath + '\\outputSR\\i%s_Prob.odb'%iteraiterationNum
### Monitor for element deletion ###
if os.path.exists(currentPath + '\\Element_Monitor.txt'):
    Element_monitor = open('Element_Monitor.txt', 'r')
    Element_status = Element_monitor.readlines()
    Element_monitor.close()
    Element_status_switch = Element_status[0].split()
    # Make it float #
    Element_status_switch = float(Element_status_switch[0])
else:
    Element_status_switch = 1
##### If element not deleted in this step, then calculate the stiffness ####
if Element_status_switch == 1:
    SOF1_previous, SOF2_previous, SOF3_previous = ContactForce(submodel_odbPath, iteraiterationNum)
    SOF1_final, SOF2_final, SOF3_final = ContactForce(probmodel_odbPath, iteraiterationNum)
    length1_previous, length2_previous, length3_previous  = Displacement(submodel_odbPath)
    length1_final, length2_final, length3_final = Displacement(probmodel_odbPath)
    length1 = length1_final - length1_previous
    length2 = length2_final - length2_previous
    length3 = length3_final - length3_previous
    Monitor(submodel_odbPath)
else: ##### If element deleted in this step, then:
    ## For the shearing case, the stiffness ##
    SOF1_previous = SOF2_previous = SOF3_previous = 200
    SOF1_final = SOF2_final = SOF3_final = 200
    length1 = length2 = length3 = 1
#############################################################
# Find Contact pair force #
outputfile = open('stiffness.log', 'w')
stiffness_data = '%s %s %s\n 0 0 0\n %s %s %s\n %s %s %s\n' % (abs(SOF1_previous), abs(SOF2_previous), abs(SOF3_previous),
                                                              abs(SOF1_final), abs(SOF2_final), abs(SOF3_final),
                                                              length1, length2, abs(length3))
outputfile.writelines(stiffness_data)
outputfile.close()
exit(0)