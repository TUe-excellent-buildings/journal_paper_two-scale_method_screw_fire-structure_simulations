from abaqus import *
from abaqusConstants import *
from odbAccess import *
from caeModules import *
from driverUtils import executeOnCaeStartup
def FOR_DISP():
    if counting == 0:
        o1 = session.openOdb(name=newOdb)
        session.viewports['Viewport: 1'].setValues(displayedObject=o1)
        odb = session.odbs[newOdb]
        session.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=(('RF', NODAL), (
            'U', NODAL, ((COMPONENT, 'U1'), (COMPONENT, 'U2'), (COMPONENT, 'U3'), )),
            ), nodeSets=('M_SET-9', ))
        x0 = session.xyDataObjects['RF:Magnitude PI: ASSEMBLY N: 3']
        x1 = session.xyDataObjects['RF:RF1 PI: ASSEMBLY N: 3']
        x2 = session.xyDataObjects['RF:RF2 PI: ASSEMBLY N: 3']
        x3 = session.xyDataObjects['RF:RF3 PI: ASSEMBLY N: 3']
        x4 = session.xyDataObjects['U:U1 PI: ASSEMBLY N: 3']
        x5 = session.xyDataObjects['U:U2 PI: ASSEMBLY N: 3']
        x6 = session.xyDataObjects['U:U3 PI: ASSEMBLY N: 3']
        session.writeXYReport(fileName=force_disp_name, xyData=(x0, x1, x2, x3, x4, x5, x6), appendMode=OFF)
        o1.close()
    else:
        o1 = session.openOdb(name=newOdb)
        session.viewports['Viewport: 1'].setValues(displayedObject=o1)
        odb = session.odbs[newOdb]
        session.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=(('RF', NODAL), (
            'U', NODAL, ((COMPONENT, 'U1'), (COMPONENT, 'U2'), (COMPONENT, 'U3'), )),
            ), nodeSets=('M_SET-9', ))
        x0 = session.xyDataObjects['RF:Magnitude PI: ASSEMBLY N: 3_%s'%counting]
        x1 = session.xyDataObjects['RF:RF1 PI: ASSEMBLY N: 3_%s'%counting]
        x2 = session.xyDataObjects['RF:RF2 PI: ASSEMBLY N: 3_%s'%counting]
        x3 = session.xyDataObjects['RF:RF3 PI: ASSEMBLY N: 3_%s'%counting]
        x4 = session.xyDataObjects['U:U1 PI: ASSEMBLY N: 3_%s'%counting]
        x5 = session.xyDataObjects['U:U2 PI: ASSEMBLY N: 3_%s'%counting]
        x6 = session.xyDataObjects['U:U3 PI: ASSEMBLY N: 3_%s'%counting]
        session.writeXYReport(fileName=force_disp_name, xyData=(x0, x1, x2, x3, x4, x5, x6), appendMode=OFF)
        o1.close()
### Copy .odb file in order not to influence the following step ###
####### Find force_vs. Displacement from global model ####
iterationNum=open('_iteration.log','r').readlines()[0]
currentPath=os.getcwd()
os.chdir(currentPath + '\\outputSR\\')
counting=0
while counting<= (int(iterationNum)-1):
    force_disp_name = 'i%s_displacement.txt' % counting
    odb_data_name = 'i' + str(counting) + '_Sys_SR.odb'
    newOdb = currentPath + '\\outputSR\\' + odb_data_name
    FOR_DISP()
    counting += 1
