## Temp Data Processing, output _temp.py ###
from abaqus import *
from odbAccess import *
from abaqusConstants import *
import os, shutil

def Stiffness():
    if os.path.exists(currentPath + '\\Element_Monitor.txt'):
        Element_monitor = open('Element_Monitor.txt', 'r')
        Element_status = Element_monitor.readlines()
        Element_monitor.close()
        Element_status_switch = Element_status[4].split()
        # Make it float #
        Element_status_switch = float(Element_status_switch[2])
        if Element_status_switch == 0:
            SOF1_previous = 1000
            SOF2_previous = 1000
            SOF3_previous = 1000
            stiffness = '%s %s %s\n 0 0 0\n %s %s %s\n %s %s %s\n' % (
            abs(SOF1_previous), abs(SOF2_previous), abs(SOF3_previous), abs(SOF1_previous), abs(SOF2_previous),
            abs(SOF3_previous), 0.02, 0.02, 0.02)
            # write stiffness to a file #
            f = open('stiffness.log', 'w')
            f.writelines(stiffness)
            f.close()
        else:
            pass
    else:
        pass




### Change work directory to find _iteration.log and output temp.py for submodel ###
currentPath=os.getcwd()
iteraiterationNum=open('_iteration.log','r').readlines()[0]
### Copy .odb file in order not to influence the following step ###
oldOdb=currentPath+'/outputSR/i'+iteraiterationNum+'_Sys_SR.odb'
newOdb=currentPath+'/outputSR/i'+iteraiterationNum+'_Sys_SR_copy.odb'
shutil.copyfile(oldOdb,newOdb)
### Import iterationNum ###
iteraiterationNum=open('_iteration.log','r').readlines()[0]
odb=openOdb(path=newOdb)
### Create two steps ###
step=odb.steps['i0_SR-Step']
### Find the region ###
region1=step.historyRegions['Node PART-1-1.2']
region2=step.historyRegions['Node PART-2-1.5']
### Find Nodal Temperature data ###
NT1data=region1.historyOutputs['NT11'].data
NT2data=region2.historyOutputs['NT11'].data
odb.close()
### Calculate the average of the NT ###
averagelist = []
timelist = []
for i in range(len(NT1data)):
    averagelist.append((NT1data[i][1] + NT2data[i][1]) / 2)    ## calculate the average temperature in a list##
    timelist.append(NT1data[i][0])                             ## put time into a list ##
    temptuple = tuple(zip(timelist, averagelist))              ## zip two list into a tuple, abaqus formate ##
_tempfile = open('_temp.py', 'w')                    ## create file to store data
content1="mdb.models['Submodel'].TabularAmplitude(timeSpan=STEP, name='i"+iteraiterationNum+"_Temp', data=("
_tempfile.write(content1)        ## create necessary words for Amplitude data
a=str(temptuple)[1:-1]+",))"    ## again, necessary words for Amplitude data formate
_tempfile.write(a)
_tempfile.close()
### In case element failed in the last step ###
Stiffness()